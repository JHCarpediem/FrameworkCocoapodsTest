

import 'package:flutter_elm/modules/Model/device_model.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as path;

class DatabaseManager {
  // 私有构造函数
  DatabaseManager._internal();

  // 静态变量，用于存储单例实例
  static final DatabaseManager _instance = DatabaseManager._internal();
  static Database? _database;

  // 工厂构造函数，返回单例实例
  factory DatabaseManager() {
    return _instance;
  }

  // 获取数据库实例
  Future<Database?> get database async {
    return await initDatabase();
  }

  Future<Database?> initDatabase() async {
    var databasePath = await getDatabasesPath();
    String dbPath = path.join(databasePath, "Battery.db");
    _database = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) {
        print('------version: $version');
        db.execute(
            'create table if not EXISTS user (userId INTEGER NOT NULL PRIMARY KEY, topdonId TEXT, token TEXT, refreshToken TEXT, userName TEXT, email TEXT, avatar BLOB, phone TEXT)');
        db.execute(
            'create table if not EXISTS device (userId INTEGER, name TEXT, mac TEXT, uuid TEXT, sn TEXT, random TEXT, softCode TEXT, version TEXT, type INTEGER)');
      },
      onUpgrade: (db, oldVersion, newVersion) {
        print('------old: $oldVersion new:$newVersion');
        if (oldVersion < 2) {
          db.execute(
              'create table if not EXISTS device (userId INTEGER NOT NULL PRIMARY KEY, name TEXT, mac TEXT, uuid TEXT, sn TEXT, random TEXT, softCode TEXT, version TEXT, type INTEGER)');
        }
      },
    );
    return _database;
  }

  /// ---------------  用户模型操作方法
  /// 将用户数据插入数据库
  Future<void> saveUser(UserModel model) async {
    var db = await database;
    UserModel? existingRecords = await fetchUser();
    // 如果
    if (existingRecords != null) {
      // 如果存在则替换旧记录
      print('------更新数据库: ${model.toMap()}');
      await db?.update('user', model.toMap());
    } else {
      // 如果不存在相则插入新记录
      print('------插入数据库: ${model.toMap()}');
      await db?.insert('user', model.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
  }

  /// 从数据库中查询用户数据
  Future<UserModel?> fetchUser() async {
    var db = await database;
    List<Map<String, Object?>>? list = await db?.query('user');
    if (list != null && list.isNotEmpty) {
      Map<String, Object?> first = list.first;
      return UserModel.fromJson(first);
    }
    return null;
  }

  /// 删除UserModel
  Future<void> deleteUser() async {
    var db = await database;
    await db?.delete(
      'user',
    );
  }

  /// ---------------  设备模型操作方法
  /// 将用户数据插入数据库
  saveDevice(DeviceModel model) async {
    var db = await database;
    List<DeviceModel> list = await fetchDevices();
    var isExist = list.where((d) => d.sn == model.sn).toList().isNotEmpty;
    if (isExist) {
      print('------更新数据库: ${model.toMap()}');
      await db?.update('device', model.toMap());
    } else {
      print('------插入数据库: ${model.toMap()}');
      await db?.insert('device', model.toMap());
    }
  }

  /// 从数据库中查询用户数据
  Future<List<DeviceModel>> fetchDevices() async {
    var db = await database;
    List<Map<String, Object?>>? list = await db?.query('device');
    print('------fetchDevices: ${list?.length}');
    List<DeviceModel> devices = [];
    if (list != null && list.isNotEmpty) {
      for (var map in list) {
        devices.add(DeviceModel.fromJson(map));
      }
    }
    return devices;
  }

  /// 删除DeviceModel
  Future<bool> deleteDevice(DeviceModel model) async {
    var db = await database;
    int? rows =
        await db?.delete('device', where: 'uuid = ?', whereArgs: [model.sn]);
    return rows != 0;
  }
}
