import 'package:flutter/material.dart';
import 'package:flutter_elm/modules/Page/feedback_list_page.dart';
import 'package:flutter_elm/modules/Page/feedback_page.dart';
import 'package:flutter_elm/modules/Page/home_page.dart';
import 'package:flutter_elm/modules/Page/login_page.dart';
import 'package:flutter_elm/modules/Page/setting_page.dart';
import 'package:flutter_elm/tools/l10n.dart';
import 'package:flutter_elm/tools/language_provider.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:oktoast/oktoast.dart';
import 'package:provider/provider.dart';

final RouteObserver<PageRoute> routeObserver = RouteObserver<PageRoute>();

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    var app = MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) {
            return language_provider();
          },
        ),
      ],
      builder: (context, child) {
        LanguageCode code = context.watch<language_provider>().languageCode;
        return MaterialApp(
          locale: Locale.fromSubtags(languageCode: code.name),
          supportedLocales: S.delegate.supportedLocales,
          localizationsDelegates: const [
            S.delegate,
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          localeResolutionCallback: (locale, supportedLocales) {
            Locale currentLocale = Locale.fromSubtags(
              languageCode: locale?.languageCode ?? 'en',
            );
            print('------切换了语言${locale?.languageCode}');
            return supportedLocales.contains(currentLocale)
                ? currentLocale
                : const Locale.fromSubtags(languageCode: 'en');
          },
          title: 'elm327',
          navigatorObservers: [routeObserver],
          initialRoute: "/",
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
            useMaterial3: true,
            // 全局设置 AppBar 样式
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.blue, // 设置背景颜色
              foregroundColor: Colors.white, // 设置前景色（文字和图标颜色）
              titleTextStyle: TextStyle(fontSize: 20),
              elevation: 4, // 设置阴影
              centerTitle: true, // 设置标题居中
            ),
          ),
          routes: {
            '/home': (context) => DashboardPage(),
            '/setting': (context) => SettingPage(),
            '/login': (context) => LoginPage(),
            '/feedback': (context) => FeedbackPage(),
            '/feedbackList': (context) => FeedbackListPage(),
          },
          onUnknownRoute: (settings) {
            return MaterialPageRoute(builder: (context) => DashboardPage());
          },
        );
      },
    );
    return OKToast(child: app);
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('You have pushed the button this many times:'),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}
