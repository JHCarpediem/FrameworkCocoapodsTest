import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:flutter_elm/tools/common_extension.dart';

extension UrlEncoding on String {
  /// 字符串转为 UTF-8 编码的字节数组
  List<int> get dataUtf8 {
    return utf8.encode(this);
  }

  /// 字符串URL 编码
  String get encoded {
    final List<String> temp = codeUnits.map((c) {
      if ((c >= 48 && c <= 57) || // 0-9
          (c >= 97 && c <= 122) || // a-z
          (c >= 65 && c <= 90) || // A-Z
          (c == 45) || // '-'
          (c == 95)) {
        // '_'
        return String.fromCharCode(c);
      } else {
        return '%${c.toRadixString(16).padLeft(2, '0').toUpperCase()}';
      }
    }).toList();
    return temp.join('');
  }

  /// 字符串URL 解码
  String get decoded {
    return Uri.decodeComponent(this);
  }

  /// 字符串 MD5 加密
  String get md5String {
    var bytes = utf8.encode(this); // 将字符串转换为 UTF-8 字节
    var digest = md5.convert(bytes); // 计算 MD5
    // 返回大写格式的十六进制字符串
    return digest.toString().toUpperCase();
  }

  /// 对参数进行签名，返回签名之后的 URL 路径
  /// parameters 需要参与签名的参数
  String sign({Map<String, dynamic>? parameters}) {
    // var queryDic = parameters.networkSigned;
    parameters ??= {};
    var queryDic = parameters.networkSigned;
    print('------ 签名后参数: $queryDic');
    // 如果是 GET 请求，筛选 queryDic 与原有参数重复的 key-value
    // if (method == 'get') {
    //   queryDic = queryDic.entries
    //       .where((entry) => parameters!.keys.any((key) => key.toLowerCase() == entry.key.toLowerCase()))
    //       .fold<Map<String, dynamic>>({}, (map, entry) {
    //     map[entry.key] = entry.value;
    //     return map;
    //   });
    //   print('------ queryDic after: ${queryDic}');
    // }

    // 将参数拼接到连接上
    var result = this;
    var queryString = queryDic.entries
        .map(
          (entry) =>
              '${entry.key}=${Uri.encodeComponent(entry.value.toString())}',
        )
        .join('&');

    if (!result.contains("?")) {
      result += '?$queryString';
    } else {
      result += '&$queryString';
    }

    result = result.replaceAll('//', '/');
    return result;
  }

  /// 邮箱验证
  bool get isValidateEmail {
    final emailRegex = RegExp(
      r'[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}',
    );
    final result = emailRegex.hasMatch(this);
    return result;
  }
}

/// 蓝牙
extension BluetoothString on String {
  String clip() {
    // String result = this
    // .replaceAll(">", "")
    // .replaceAll("\r", "")
    // .replaceAll("\n", "")
    // .replaceAll(" ", "");
    String result = replaceAll(RegExp(r'[>\r\n ]'), '');
    return result;
  }

  int extractNumbers() {
    final RegExp regExp = RegExp(r'\d+'); // 匹配数字的正则表达式
    final match = regExp.firstMatch(this); // 找到第一个匹配的数字

    if (match != null) {
      return int.parse(match.group(0) ?? '0'); // 返回匹配的数字，或 0
    }

    return 0; // 如果没有找到数字，返回 0
  }

  // 将十六进制字符串转换为 UTF-8 字符串
  String? hexToAscii() {
    // 将十六进制字符串转换为字节数据
    List<int> data = hexToBytes();
    // 将字节数据转换为 UTF-8 编码的字符串
    try {
      return String.fromCharCodes(data);
    } catch (e) {
      print("Failed to decode to UTF-8: $e");
      return null;
    }
  }

  // 将十六进制字符串转换为字节数组 List<int>
  List<int> hexToBytes() {
    List<int> bytes = [];
    for (int i = 0; i < length; i += 2) {
      // 每两位字符表示一个字节，转换为 int
      bytes.add(int.parse(substring(i, i + 2), radix: 16));
    }
    return bytes;
  }

  // 使用 RegExp 替换每两个字符之间插入冒号 例如：001A2B3C4D5E => 00:1A:2B:3C:4D:5E
  String insertColons() {
    return replaceAllMapped(
      RegExp(r'(\w{2})(?=\w)'),
      (match) => '${match.group(0)}:',
    );
  }

  /// 将十六进制字符串转换为字节数据
  Uint8List convertHexStrToData() {
    if (isEmpty) {
      return Uint8List(0); // 返回空的 Uint8List
    }

    Uint8List hexData = Uint8List((length + 1) ~/ 2); // 确定字节数组的大小
    int index = 0;

    for (int i = 0; i < length; i += 2) {
      String hexCharStr;

      // 处理单个字符的情况
      if (i + 1 < length) {
        hexCharStr = substring(i, i + 2); // 获取两个字符
      } else {
        hexCharStr = substring(i, i + 1); // 处理最后一个字符
      }

      // 将十六进制字符串转换为整数
      int byteValue = int.parse(hexCharStr, radix: 16);
      hexData[index++] = byteValue; // 将字节值添加到 Uint8List
    }

    return hexData;
  }

  /// 取反
  String negation() {
    final data = convertHexStrToData();
    final bytes = Uint8List.fromList(data);

    Uint8List oppoData = Uint8List(data.length);

    for (int i = 0; i < data.length; i++) {
      oppoData[i] = ~bytes[i]; // 取反操作
    }

    return convertDataToHexStr(oppoData);
  }

  /// 将字节数据转换为十六进制字符串
  // String convertDataToHexStr(Uint8List data) {
  //   return data.map((byte) => byte.toRadixString(16).padLeft(2, '0')).join().toUpperCase();
  // }
  String convertDataToHexStr(Uint8List data) {
    if (isEmpty) {
      return '';
    }

    StringBuffer hexString = StringBuffer();

    for (int byte in data) {
      // 将每个字节转换为两位十六进制字符串
      String hex = byte.toRadixString(16).padLeft(2, '0');
      hexString.write(hex);
    }

    return hexString.toString().toUpperCase(); // 转为大写
  }

  /// 将十六进制字符串转换为整数
  int hexToInt() {
    return int.parse(this, radix: 16);
  }

  /// 将十六进制字符串转换为double
  double hexToDouble() {
    return int.parse(this, radix: 16).toDouble();
  }

  /// 将一个由十六进制两位字符串组成的字符串（如 "414243"），每两位解析为一个 ASCII 字符，返回拼接后的字符串。
  /// 如果任何一组不是合法的 2 位十六进制，则返回 null。
  String? hexStringToASCII() {
    if (isEmpty || length % 2 != 0) return null;

    StringBuffer asciiString = StringBuffer();
    int i = 0;

    while (i < length) {
      if (i + 2 > length) return null;

      String hexSubstring = substring(i, i + 2);

      try {
        int asciiValue = int.parse(hexSubstring, radix: 16);
        asciiString.writeCharCode(asciiValue);
        i += 2;
      } catch (e) {
        return null;
      }
    }

    return asciiString.toString();
  }
}

/// 密码校验
extension PasswordValidation on String {
  /// 检查密码是否包含至少两种字符类型（大小写字母、数字、特殊字符）且不包含无效字符
  bool get isValidCasePassword {
    const specialCharacters = '@\$!%*#_~?&.-';
    
    final uppercaseRegex = RegExp(r'[A-Z]');
    final lowercaseRegex = RegExp(r'[a-z]');
    final digitRegex = RegExp(r'\d');
    final specialCharRegex = RegExp('[$specialCharacters]');
    final invalidCharRegex = RegExp('[^A-Za-z0-9$specialCharacters]');
    
    // 1. 检查是否包含无效字符
    if (invalidCharRegex.hasMatch(this)) {
      return false;
    }
    
    // 2. 检查至少两种字符类型
    final patterns = [uppercaseRegex, lowercaseRegex, digitRegex, specialCharRegex];
    
    // 统计匹配到的字符类别数量
    final matchedCategories = patterns.where((pattern) => pattern.hasMatch(this)).length;
    
    return matchedCategories >= 2;
  }
  
  /// 检查密码长度是否在8-30位之间
  bool get isValidLengthPassword {
    return length >= 8 && length <= 30;
  }
}
