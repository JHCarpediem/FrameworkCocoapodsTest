
import 'package:flutter_elm/tools/configration.dart';
import 'package:flutter_elm/tools/string_extension.dart';

extension NetworkBasis on Map<String, dynamic> {
  /// 参数签名
  Map<String, dynamic> get networkSigned {
    var mDic = Map<String, dynamic>.from(this);
    var timeStamp = DateTime.now().millisecondsSinceEpoch.toString();

    mDic['appkey'] = TDConfig.appKey;
    mDic['nonceStr'] = TDConfig.nonceStr;
    mDic['timestamp'] = timeStamp;

    // 生成签名
    var sign = mDic.entries.toList()..sort((a, b) => a.key.compareTo(b.key));
    var signString =
        sign.map((entry) => '${entry.key}=${entry.value}').join('&');
    signString += '&appSecret=${TDConfig.appSecret}';

    var hashedSign = signString.md5String;
    mDic['sign'] = hashedSign;

    return mDic;
  }
}


extension BluetoothList on List<int> {
  // String toHexString() {
  //   StringBuffer hexString = StringBuffer();
  //   for (int byte in this) {
  //     hexString.write(byte.toRadixString(16).padLeft(2, '0'));
  //   }
  //   return hexString.toString();
  // }

  String toHexString() {
    return map((e) => e.toRadixString(16).padLeft(2, '0')).join();
  }

  // 将 List<int> 转换为十六进制字符串
  String bytesToHex() {
    return map((byte) => byte.toRadixString(16).padLeft(2, '0')).join();
  }
}


extension IntHexString on int {
  /// 将整数转换为十六进制字符串，格式为两位数
  String get hexString {
    return toRadixString(16).padLeft(2, '0').toUpperCase(); // 转为大写
  }
}