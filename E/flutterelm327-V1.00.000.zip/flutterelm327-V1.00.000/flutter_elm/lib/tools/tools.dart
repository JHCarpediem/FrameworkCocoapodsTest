import 'package:flutter_elm/tools/common_extension.dart';

class Tools {
  static String format(String cmd) {
    String command;
    if (cmd.endsWith("\r")) {
      command = cmd;
    } else {
      command = "${cmd}\r";
    }

    String resultCMD = command.replaceAll(" ", "");

    return resultCMD;
  }

  /// 10进制转16进制不足补零
  static String getHexByDecimal(int decimal, int length) {
    // 将十进制转换为十六进制字符串
    String hexStr = decimal.hexString; // 转为大写

    // 不足补零
    if (hexStr.length < length) {
      hexStr = hexStr.padLeft(length, '0'); // 使用 padLeft 补零
    } else if (hexStr.length > length) {
      hexStr = hexStr.substring(0, length); // 超过长度则截断
    }

    return hexStr;
  }
}
