import 'package:flutter/material.dart';

enum LanguageCode { en, pt, zh, zh_cn, cs, de, es, fr, it, ja, ko, ru }

class language_provider extends ChangeNotifier {
  LanguageCode languageCode = LanguageCode.zh;

  changeLanguage(LanguageCode newLanguageCode) {
    if (languageCode != newLanguageCode) {
      languageCode = newLanguageCode;
      notifyListeners();
    }
  }
}