
class TDConfig {

  /// appKey
  static String get appKey => '0F3B8F3924774D4990255D8256FE40CE';
  /// appSecret
  static String get appSecret => '3BF3E2D6BFD340E58BFA0E4826663963';
  /// nonceStr
  static String get nonceStr => '9331864F-6836-4C39-8AE6-AD64FEE4C70C';
  /// AES加密key
  static String get aesKey => 'thanks,lenkor123';
  /// token
  static String get token => 'token';
  /// currentLanguage
  static String get currentLanguage => 'currentLanguage';

  /// 当前连接的蓝牙设备ID
  static String get connectedID => 'connectedID';

  /// 特征值 NexLink设备
  static String get nexLinkNotifyCharUUID => 'FFF1';
  static String get nexLinkwriteCharUUID => 'FFF2';

  /// 特征值 vLinker设备,vGate设备
  static String get vLinkerNotifyCharUUID => '2AF0';
  static String get vLinkerWriteCharUUID => '2AF1';

}