
class NetworkModel {
  String? msg;
  int? code;
  dynamic data;

  NetworkModel({this.msg, this.code, this.data});

  factory NetworkModel.fromJson(Map<String, dynamic> json) {
    return NetworkModel(
      msg: json['msg'] as String?,
      code: json['code'] as int?,
      data: json['data'] as dynamic,
    );
  }
}
