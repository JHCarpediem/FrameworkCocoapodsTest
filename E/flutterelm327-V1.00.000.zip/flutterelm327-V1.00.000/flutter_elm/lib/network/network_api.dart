import 'dart:io';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_elm/manager/database_manager.dart';
import 'package:flutter_elm/modules/Model/feedback_list_model.dart';
import 'package:flutter_elm/modules/Model/feedback_model.dart';
import 'package:flutter_elm/modules/Model/feedback_detail_model.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:flutter_elm/tools/configration.dart';
import 'package:flutter_elm/tools/string_extension.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:encrypt/encrypt.dart';
import 'package:intl/intl.dart';

class DioConfig {
  /// 正式环境 https://api.topdon.com   测试环境 http://api.topdon.top:8022
  static const baseUrl = 'http://api.topdon.top:8022';
  static const timeout = Duration(seconds: 15); // 超时时间

  /// 车辆区域列表
  static const findCarType = "/api/v1/baseinfo/outCarApi/findCarType";

  /// 车辆品牌列表
  static const findCarBrand = "/api/v1/baseinfo/outCarApi/findCarBrand";

  /// 车辆车型列表
  static const findCarModel = "/api/v1/baseinfo/outCarApi/findCarModel";

  /// 车辆年份列表
  static const findCarYeas = "/api/v1/baseinfo/outCarApi/findCarYeas";

  /// 获取车辆关联的电池
  static const carListGroupBy = "/api/v1/baseinfo/outCar/carListGroupBy";

  /// 登录
  static const login = "/api/v1/user/platUserPro/login";

  /// 注册 或 忘记密码
  static const register = "/api/v1/user/platUserPro/register";

  /// 修改登录密码
  static const updatePassword = "/api/v1/user/platUserPro/updatePassword";

  /// 发送验证码
  static const sendCaptcha = "/api/v1/user/platUserPro/sendCaptcha";

  /// 查询反馈问题类型列表
  static const feedbackType = "/api/v1/user/questionType/getPlatQuestionType";

  /// 上传文件
  static const uploadFile = "/api/v1/oss/file/uploadFile";

  /// 提交反馈
  static const feedback = "/api/v1/user/feedBack/addFeedback";

  /// 获取反馈列表
  static const feedbackList = "/api/v1/user/feedBack/listFeedBack";

  /// 获取反馈详情
  static const feedbackDetail = "/api/v1/user/feedBack/feedbackDetail";
}

class DioRequest {
  late Dio dio;
  static DioRequest? _instance;

  static DioRequest share() {
    return _instance ??= DioRequest();
  }

  /// 构造函数
  DioRequest() {
    dio = Dio();
    dio.options = BaseOptions(
      baseUrl: DioConfig.baseUrl,
      connectTimeout: DioConfig.timeout,
      sendTimeout: DioConfig.timeout,
      receiveTimeout: DioConfig.timeout,
      contentType: 'application/json; charset=utf-8',
      headers: {},
    );

    /// 请求拦截器 and 响应拦截机 and 错误处理
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          print("\n================== 请求数据 ==========================");
          print("url = ${options.uri.toString()}");
          print("headers = ${options.headers}");
          // JSON格式化打印（带缩进和换行）
          try {
            if (options.data != null) {
              JsonEncoder encoder = const JsonEncoder.withIndent('  ');
              String prettyJson = encoder.convert(options.data);
              print("params = $prettyJson");
            } else {
              print("params = null");
            }
          } catch (e) {
            print("params = ${options.data}");
            print("JSON格式化失败: $e");
          }
          return handler.next(options);
        },
        onResponse: (response, handler) {
          print("\n================== 响应数据 ==========================");
          print("code = ${response.statusCode}");
          try {
            if (response.data != null) {
              JsonEncoder encoder = const JsonEncoder.withIndent('  ');
              String prettyJson = encoder.convert(response.data);
              print("data = $prettyJson");
            } else {
              print("data = null");
            }
          } catch (e) {
            print("data = ${response.data}");
            print("JSON格式化失败: $e");
          }
          print("\n");
          handler.next(response);
        },
        onError: (DioException e, handler) {
          print("\n================== 错误响应数据 ======================");
          print("type = ${e.type}");
          print("message = ${e.message}");
          print("\n");
          return handler.next(e);
        },
      ),
    );
  }
}

class BatteryInfoApi {
  static Dio dio = Dio(BaseOptions(baseUrl: DioConfig.baseUrl));

  /// 网络请求头部
  static Future<Options> getHeaders() async {
    var prefs = await SharedPreferences.getInstance();
    var token = prefs.getString(TDConfig.token);
    var model = await DatabaseManager().fetchUser();

    Options options = Options(
      headers: {
        "version": "v1.0",
        "clientType": "1",
        "Authorization": "Bearer $token",
        "isUpload": "0",
        "timezone": "UTC+8",
        "deviceId": "78c09ba919ef42b3ab59f96092b4e552",
        "languageId": "1",
        "shouldToken": "1",
        "isSignParameter": "1",
        "clientVersion": "3.01.000",
        "Content-Type": "application/json;charset=UTF-8",
        "topdonId": "${model?.topdonId}",
      },
    );
    return options;
  }

  /// 网络请求头部通用
  static Options getCommonHeaders() {
    Options options = Options(
      headers: {
        "version": "1.0",
        "clientType": "1",
        "Authorization": "Basic bGVua29yOmxlbmtvcg==",
        "isUpload": "0",
        "timezone": "UTC+8",
        "deviceId": "78c09ba919ef42b3ab59f96092b4e552",
        "languageId": "1",
        "shouldToken": "0",
        "isSignParameter": "0",
        "clientVersion": "3.01.000",
        "Content-Type": "application/json;charset=UTF-8",
      },
    );
    return options;
  }

  /// 登录请求
  static Future<NetworkModel> login(Map<String, dynamic> param) async {
    print("------ 登录请求参数: $param");
    String password = param['password'];

    Encrypter encrypter = encrypt.Encrypter(
      encrypt.AES(
        encrypt.Key.fromUtf8(TDConfig.aesKey),
        mode: encrypt.AESMode.cbc,
      ),
    );
    Encrypted encrypted = encrypter.encrypt(
      password,
      iv: encrypt.IV.fromUtf8(TDConfig.aesKey),
    );
    param['password'] = encrypted.base64.encoded;

    var url = DioConfig.login.sign();

    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: getCommonHeaders(),
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.data != null) {
      model.data = UserModel.fromJson(model.data);
    }
    return model;
  }

  /// 注册请求
  static Future<NetworkModel> registerOrForgetPassword(
    Map<String, dynamic> param,
  ) async {
    print("------ 注册请求参数: $param");
    String password = param['password'];

    Encrypter encrypter = encrypt.Encrypter(
      encrypt.AES(
        encrypt.Key.fromUtf8(TDConfig.aesKey),
        mode: encrypt.AESMode.cbc,
      ),
    );
    Encrypted encrypted = encrypter.encrypt(
      password,
      iv: encrypt.IV.fromUtf8(TDConfig.aesKey),
    );
    // 解密
    // String decrypted = encrypter.decrypt(encrypted, iv: encrypt.IV.fromUtf8(AESKey));

    param['password'] = encrypted.base64.encoded;
    param['confirmPassword'] = encrypted.base64.encoded;

    var url = DioConfig.register.sign();

    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: getCommonHeaders(),
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.data != null) {
      model.data = UserModel.fromJson(model.data);
    }
    return model;
  }

  /// 修改登录密码
  static Future<NetworkModel> updatePassword(
    Map<String, dynamic> param,
  ) async {
    print("------ 修改密码请求参数: $param");
    String password = param['password'];

    Encrypter encrypter = encrypt.Encrypter(
      encrypt.AES(
        encrypt.Key.fromUtf8(TDConfig.aesKey),
        mode: encrypt.AESMode.cbc,
      ),
    );
    Encrypted encrypted = encrypter.encrypt(
      password,
      iv: encrypt.IV.fromUtf8(TDConfig.aesKey),
    );
    param['password'] = encrypted.base64.encoded;
    param['confirmPassword'] = encrypted.base64.encoded;

    var url = DioConfig.updatePassword.sign();

    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: await getHeaders(),
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.data != null) {
      model.data = model.data as String;
    }
    return model;
  }

  /// 发送验证码请求
  static Future<NetworkModel> sendCaptch(Map<String, dynamic> param) async {
    print("------ 发送验证码请求参数: $param");
    var url = DioConfig.sendCaptcha.sign();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: getCommonHeaders(),
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.data != null) {
      model.data = response.data ?? false;
    }
    return model;
  }

  /// 反馈类型列表
  static Future<NetworkModel> feedbackTypeList() async {
    print("------ 反馈类型列表");
    var param = {
      "systemName": "topdonelm",
      "languageId": 1,
      "feedbackType": 1,
      "softCode": "TopScan_DisplaySW_iOS",
      "configClass": 1,
    };
    var url = DioConfig.feedbackType.sign();
    var options = await getHeaders();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: options,
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.code == 401) {
      // token失效，跳转到登录页面
      // Navigator.pushReplacementNamed(context as BuildContext, '/login');
      Navigator.pushNamed(context as BuildContext, '/login');
      return model;
    }
    if (model.data != null) {
      model.data = (model.data as List)
          .map((e) => FeedbackTypeValueModel.fromJson(e))
          .toList();
    }
    return model;
  }

  /// 上传单个文件
  static Future<NetworkModel> uploadSingleFile(File file, int index, {bool isVideo = false}) async {
    // 准备文件上传表单数据
    FormData formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(
        file.path,
        filename: file.path.split('/').last,
      ),
      'businessId': 0,
      'businessType': isVideo ? 80 : 13, // 视频为80，图片为13
      'productType': 20,
    });
    var url = DioConfig.uploadFile.sign();
    var options = await getHeaders();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: formData,
      options: options,
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    if (model.data != null) {
      model.data = model.data['fileSecret'] as String? ?? '';
    }
    return model;
  }

  /// 提交反馈
  static Future<NetworkModel> uploadFeedback(
    int feedbackType,
    String title,
    String description,
    String fileSecret,
  ) async {
    // 创建包含当前时间的map
    DateTime now = DateTime.now();
    String formattedTime = DateFormat('yyyy-MM-dd HH:mm:ss').format(now);
    Map<String, dynamic> deviceInfoMap = {'currentTime': formattedTime};
    // 将map转换为字符串
    String deviceInfoString = deviceInfoMap.toString();
    UserModel? userModel = await DatabaseManager().fetchUser();

    var param = {
      'systemName': 'topdonelm', // 系统名称，根据实际情况修改 topdonelm
      'questionTypeId': feedbackType,
      'title': title,
      'reason': description,
      'titleType': '个人中心反馈', // 标题类型，根据实际情况修改
      'sourceType': '0', // 来源类型，根据实际情况修改
      'fromSystem': 1, // 1表示用户
      'configClass': 1, // 配置分类，根据实际情况修改
      'appDeviceInfo': deviceInfoString, // 包含当前时间的map字符串
      'languageId': 1,
      'softCode': 'TopScan_DisplaySW_iOS',
      'createTime': formattedTime,

      // 'vin': '123456',
      'feedbackType': 1,
    };
    if (fileSecret.isNotEmpty) {
      param['enclosure'] = fileSecret; // 文件附件
    }
    if (userModel != null) {
      param['feedbackUserId'] = userModel.userId.toString();
      param['feedbackUserName'] = userModel.userName ?? '';
      param['feedbackUserEmail'] = userModel.email ?? '';
    }

    var url = DioConfig.feedback.sign();
    var options = await BatteryInfoApi.getHeaders();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: options,
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    return model;
  }

  /// 获取反馈列表  status: 0表示进行中，1表示已完成，不传值查询全部
  static Future<NetworkModel> getFeedbackList({int status = 0}) async {
    
    var param = {'feedbackStatus': status, 'feedbackType': 1, 'systemName': 'topdonelm', 'searchRange': 2};
    var url = DioConfig.feedbackList.sign();
    var options = await getHeaders();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: options,
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    // 根据服务器返回的数据格式，data直接是反馈列表数组
    if (model.data != null && model.data is List) {
      model.data = (model.data as List)
          .map((e) => FeedbackItemModel.fromJson(e))
          .toList();
    }
    return model;
  }
  
  /// 获取反馈详情
  static Future<NetworkModel> getFeedbackDetail(int feedbackId) async {
    var param = {'feedbackId': feedbackId};
    var url = DioConfig.feedbackDetail.sign();
    var options = await getHeaders();
    Response<dynamic> response = await DioRequest.share().dio.post(
      url,
      data: param,
      options: options,
    );
    NetworkModel model = NetworkModel.fromJson(response.data);
    // 根据服务器返回的数据格式，data是反馈详情对象
    if (model.data != null && model.data is Map<String, dynamic>) {
      model.data = FeedbackDetailModel.fromJson(model.data as Map<String, dynamic>);
    }
    return model;
  }
}
