import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
// import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_elm/tools/common_extension.dart';
import 'package:flutter_elm/tools/configration.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum TDBleState { disconnected, findCharacteristic, connected }

class BLEManager {
  BLEManager._privateConstructor();

  static final BLEManager _instance = BLEManager._privateConstructor();

  static List<BluetoothDevice> devicesList = [];

  factory BLEManager() {
    return _instance;
  }

  static BLEManager get instance => _instance;

  static FlutterBluePlus blue = FlutterBluePlus();

  /// 手动断开连接
  var manualDisconnect = false;

  BluetoothCharacteristic? readCharacteristic;
  BluetoothCharacteristic? writeCharacteristic;
  bool _isDiscovering = false;

  BluetoothDevice? selDevice;
  // 当前蓝牙状态
  var status = TDBleState.disconnected.obs;

  void stopScan() {
    FlutterBluePlus.stopScan();
    devicesList = [];
  }

  /// 循环监听
  Future<void> bluetoothLoop() async {
    // 如果当前不是断开状态或者是手动断开连接，则不启动蓝牙循环
    if (status.value != TDBleState.disconnected || manualDisconnect) {
      print(
        '------蓝牙状态不是断开状态或者是手动断开连接，无需启动蓝牙循环。当前状态: ${status.value}, manualDisconnect: $manualDisconnect',
      );
      return;
    }
    manualDisconnect = false;

    var prefs = await SharedPreferences.getInstance();
    var connectedID = prefs.getString(TDConfig.connectedID);
    if (connectedID == null) return;

    FlutterBluePlus.scanResults.listen((scanResult) async {
      for (var result in scanResult) {
        // 检查设备的 UUID 是否匹配目标 UUID
        if (result.device.remoteId.toString().toUpperCase() ==
            connectedID.toUpperCase()) {
          BLEManager.instance.stopScan();
          // 连接设备前先断开可能存在的连接
          if (selDevice != null) {
            await selDevice!.disconnect().catchError(
              (e) => print('------断开旧连接失败: $e'),
            );
            var prefs = await SharedPreferences.getInstance();
            var connectedID = prefs.getString(TDConfig.connectedID);
            if (connectedID == null) {
              prefs.remove(TDConfig.connectedID);
            }
          }
          await result.device.connect();
          selDevice = result.device;
          listenDevice();
          discoverServices(result.device);
        }
      }
    });
  }

  /// 监听设备的蓝牙状态
  void listenDevice() {
    print('-------开始监听设备');
    selDevice?.connectionState.listen((state) async {
      // print('------监听设备: ${selDevice?.platformName} - state: ${state}');
      if (state == BluetoothConnectionState.connected) {
        status.value = TDBleState.connected;
      } else if (state == BluetoothConnectionState.disconnected) {
        status.value = TDBleState.disconnected;
      }

      if (state == BluetoothConnectionState.disconnected) {
        BLEManager.instance.writeCharacteristic = null;
        selDevice = null;
        bluetoothLoop();
      }
    });
  }

  /// 是否有已经连上的设备
  bool isConnectedDevice() {
    var devices = FlutterBluePlus.connectedDevices;
    var list = devices.map((d) {
      return d.platformName.isEmpty;
    }).toList();
    return list.isNotEmpty;
  }

  /// 检查是否已发现特征值
  bool _hasDiscoveredCharacteristics() {
    return readCharacteristic != null && writeCharacteristic != null;
  }

  /// 已经连上的设备
  Future<BluetoothDevice> currentConnectDevice() async {
    var prefs = await SharedPreferences.getInstance();
    var connectedID = prefs.getString(TDConfig.connectedID);

    var devices = await FlutterBluePlus.connectedDevices;
    var device = devices.where((d) => d.remoteId.str == connectedID).first;
    return device;
  }

  /// 查找指定设备并连接
  Future<BluetoothDevice?> connectDevice(String id) async {
    var device = devicesList.where((d) => d.remoteId.str == id).first;
    print('------连接设备: ${device.toString()}');
    await device.connect();
    bool findCharacteristic = await discoverServices(device);
    if (!findCharacteristic) {
      await disconnectAll();
      return null;
    }
    selDevice = device;
    print('------连接设备名字: ${device.platformName}, 地址: ${device.remoteId}');
    var prefs = await SharedPreferences.getInstance();
    prefs.setString(TDConfig.connectedID, device.remoteId.toString());
    listenDevice();
    return device;
  }

  /// 发现服务值和特征值
  Future<bool> discoverServices(BluetoothDevice device) async {
    // 如果已经发现特征值或正在发现中，则不再重复发现
    if (_isDiscovering || _hasDiscoveredCharacteristics()) {
      print('------特征值已发现或正在发现中，无需重复处理');
      return false;
    }

    _isDiscovering = true;
    print('------开发搜索特征值');
    bool isFoundReadCharacteristics = false;
    bool isFoundWriteCharacteristics = false;
    try {
      if (kDebugMode) {
        print('------discoverServices: ${device.discoverServices()}');
      }
      var services = await device.discoverServices();
      for (BluetoothService service in services) {
        print('------发现服务: ${service.uuid}');
        for (var characteristic in service.characteristics) {
          var charUUID = characteristic.uuid.toString().toUpperCase();
          print('------发现特征值: $charUUID');
          var isNotifyChar = charUUID.contains(TDConfig.nexLinkNotifyCharUUID);
          if (charUUID.contains(TDConfig.vLinkerNotifyCharUUID)) {
            isNotifyChar = true;
          }
          if (isNotifyChar &&
              !isFoundReadCharacteristics) {
            print(
              '------找到特征值read: $charUUID',
            );
            readCharacteristic = characteristic;
            characteristic.setNotifyValue(true);
            isFoundReadCharacteristics = true;
            // BLEManager.instance.subscribeToCharacteristic(characteristic);
          }

          var isWriteChar = charUUID.contains(TDConfig.nexLinkwriteCharUUID);
          if (charUUID.contains(TDConfig.vLinkerWriteCharUUID)) {
            isWriteChar = true;
          }
          if (isWriteChar &&
              !isFoundWriteCharacteristics) {
            print(
              '------找到特征值write: $charUUID',
            );
            writeCharacteristic = characteristic;

            isFoundWriteCharacteristics = true;
          }
        }
      }

      if (isFoundReadCharacteristics && isFoundWriteCharacteristics) {
        // 读写特征都找到了发送通知
        status.value = TDBleState.findCharacteristic;
        BLEManager.instance.stopScan();
        print('------服务和特征值发现完成');
        return true;
      } else {
        return false;
      }
    } finally {
      _isDiscovering = false;
      if (isFoundReadCharacteristics && isFoundWriteCharacteristics) {
        print('------发现了服务和特征值');
        return true;
      } else {
        print('------没有发现服务和特征值');
        return false;
      }
    }
  }

  /// 断开蓝牙
  Future<void> disconnect({bool manual = false}) async {
    manualDisconnect = manual;
    var list = FlutterBluePlus.connectedDevices;
    var prefs = await SharedPreferences.getInstance();
    var connectedID = prefs.getString(TDConfig.connectedID);

    /// 只有是正在连接的设备被删除才走下面的逻辑
    if (list.isNotEmpty && connectedID != null && connectedID.isNotEmpty) {
      var model = list.where((d) => d.remoteId.str == connectedID).first;
      if (kDebugMode) {
        print('------model: ${model.remoteId.str}');
      }
      await model.disconnect();
      stopScan();
      prefs.remove(TDConfig.connectedID);
      if (kDebugMode) {
        print(
          '------connectedId:$connectedID - model.id: ${model.remoteId.str}',
        );
      }
      if (model.remoteId.str == connectedID) {
        selDevice = null;
        readCharacteristic = null;
        writeCharacteristic = null;
      }
      if (kDebugMode) {
        print('------断开连接: ${model.toString()}, connectedID: ${prefs.getString(TDConfig.connectedID)}');
      }
    } else {
      prefs.remove(TDConfig.connectedID);
      print(
        '------没有正在连接的设备, connectedID: ${prefs.getString(TDConfig.connectedID)}',
      );
    }
  }

  /// 断开所有蓝牙
  Future<void> disconnectAll() async {
    var list = FlutterBluePlus.connectedDevices;
    for (var device in list) {
      await Future.delayed(const Duration(seconds: 1));
      await device.disconnect();
      if (kDebugMode) {
        print('------断开连接disconnectAll: ${device.toString()}');
      }
    }

    selDevice = null;
    readCharacteristic = null;
    writeCharacteristic = null;
  }

  /// 监听蓝牙通知
  void subscribeToCharacteristic(BluetoothCharacteristic characteristic) async {
    try {
      print('------已启用特征值通知: ${characteristic.uuid}');
      characteristic.setNotifyValue(true);
      // 可以在这里添加全局监听，用于调试
      // characteristic.value.listen((value) {
      //   if (kDebugMode) {
      //     print('------收到特征值通知: $value');
      //   }
      // });
    } catch (e) {
      if (kDebugMode) {
        print('------启用特征值通知失败: $e');
      }
    }
  }

  /// 读取
  void read() async {
    List<int>? value = await readCharacteristic?.read();
    if (kDebugMode) {
      print('------Characteristic value: $value');
    }
  }

  /// 写入数据到蓝牙特征
  /// 增加错误处理和重试机制
  Future<bool> write(List<int> value, {int maxRetries = 2}) async {
    if (writeCharacteristic == null) {
      if (kDebugMode) {
        print('------写入失败: 写入特征不可用');
      }
      return false;
    }

    int retryCount = 0;
    while (retryCount <= maxRetries) {
      try {
        // 5. 检查是否支持无响应写入（writeWithoutResponse）
        var canWriteWithoutResponse =
            writeCharacteristic?.properties.writeWithoutResponse;
        if (canWriteWithoutResponse != null &&
            canWriteWithoutResponse == true) {
          // 无响应方式发送
          await writeCharacteristic!.write(value, withoutResponse: true);
        } else {
          // 有响应方式发送
          await writeCharacteristic!.write(value, withoutResponse: false);
        }
        // await writeCharacteristic!.write(value, withoutResponse: true);
        print('------写入成功value: ${value.toHexString()}');
        return true;
      } catch (e) {
        retryCount++;
        if (kDebugMode) {
          print('------写入失败 (尝试 $retryCount/$maxRetries): $e');
        }

        if (retryCount > maxRetries) {
          if (kDebugMode) {
            print('------写入最终失败，已达到最大重试次数');
          }
          return false;
        }

        // 重试前等待一段时间
        await Future.delayed(Duration(milliseconds: 200 * retryCount));
      }
    }

    return false;
  }
}
