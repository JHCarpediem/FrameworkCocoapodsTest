import 'dart:async';
import 'dart:convert';
import 'package:flutter_elm/command/bluetooth_manager.dart';
import 'package:flutter_elm/command/elm_237.dart';
import 'package:flutter_elm/command/parse.dart';
import 'package:flutter_elm/tools/common_extension.dart';
import 'package:flutter_elm/tools/string_extension.dart';
import 'package:flutter_elm/tools/tools.dart';
import 'package:get/get.dart';
// import 'dart:developer' as developer;

enum ELM327State {
  idle,
  timeout,
  unableToConnect,
  noData,
  stopped,
  generalError,
  msgRXD,
  success,
}

class Sender {
  bool debugMode = false;
  var state = ELM327State.idle;
  String currentCommand = "";
  bool connected = false;
  // 记录返回的数据
  var internalPayload = [];
  var stringFromData = "".obs;

  /// 初始化第一步
  static String get initFirst => Tools.format(ATCommands.SET_ALL_TO_DEFAULTS);

  /// 初始化第二步
  static String get initSecond => Tools.format(ATCommands.RESET_ALL);

  /// 初始化第三步
  static String get initThird => Tools.format(ATCommands.ECHO_OFF);

  /// 初始化第四步
  static String get initForth => Tools.format(ATCommands.LINEFEEDS_OFF);

  /// 初始化第五步
  static String get initFifth => Tools.format(ATCommands.PRINTING_SPACES_OFF);

  /// 初始化第六步
  static String get initSixth => Tools.format(ATCommands.HEADERS_OFF);

  /// 初始化第七步
  static String get initSeventh =>
      Tools.format(ATCommands.SET_PROTOCOL_TO_AUTO_SAVE);

  /// 初始化第八步
  static String get initEighth => Tools.format(ATCommands.DISP_ID);

  /// 初始化第九步
  static String get initNinth => Tools.format("0100");

  /// 协议类型
  Future<String> sendProtocolType() async {
    var value = await sendCommand(Tools.format(ATCommands.DISP_CURRENT_PROTOCOL));
    var parseValue = ObdDataParser.parseProtocolType(value);
    return Future.value(parseValue);
  }

  /// ECU信息
  Future<String> sendECUInfo() async {
    var value = await sendCommand(Tools.format("0904"));
    var parseValue = ObdDataParser.parseECUInfo(value);
    return Future.value(parseValue);
  }

  /// VIN码
  Future<String> sendVinCode() async {
    var value = await sendCommand(Tools.format("0902"));
    var parseValue = ObdDataParser.parseVIN(value);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 监控自 DTCs 清除后的状态（包括故障指示灯（MIL）、状态和 DTC 数量、部件测试、DTC 就绪检查）
  Future<int> sendMonitorStatus({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.MONITOR_STATUS_SINCE_DTC_CLEARED
      ),
    );
    var parseValue = ObdDataParser.parseMonitorStatus(value);
    return Future.value(parseValue);
  }

  /// 显示诊断故障代码(当前故障码)
  Future<List<OBDIIDTC>> sendCurrentDTC() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_03));
    var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_03);
    return Future.value(parseValue);
  }

  /// 显示“待定”的故障码(未解决故障码)
  Future<List<OBDIIDTC>> sendPendingDTC() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_07));
    var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_07);
    return Future.value(parseValue);
  }

  /// 获取永久性故障码(历史故障码)
  Future<List<OBDIIDTC>> sendPermanentDTC() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_0A));
    var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_0A);
    return Future.value(parseValue);
  }

  /// 清空故障码
  Future<String> sendClearDTC() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_04));
    // var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_04);
    print("------sendClearDTC: $value");
    return Future.value(value);
  }

  /// 获取当前故障码指令是否有冻结帧
  Future<String> sendFreezeFrameWithDTC() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_02));
    var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_02);
    print("------sendFreezeFrameWithDTC: $parseValue, value: $value");
    return Future.value(value);
  }

  /// 冻结帧
  Future<List<OBDIIDTC>> sendFreezeFrame() async {
    var value = await sendCommand(Tools.format(OBDIIPID.SERVICE_0A));
    var parseValue = ObdDataParser.parseDTC(value, OBDIIPID.SERVICE_0A);
    return Future.value(parseValue);
  }

  /// 发动机负载 %
  Future<double> sendCalculatedEngineLoad({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ENGINE_LOAD),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.ENGINE_LOAD, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 冷却液温度 °C
  Future<int> sendEngineCoolantTemp({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ENGINE_COOLANT_TEMP),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ENGINE_COOLANT_TEMP, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 短期燃油修正1号气缸组 - 单元1
  Future<double> sendShortTermFuelTrim1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_1),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_1, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 长期燃油修正1号气缸组 - 单元1
  Future<double> sendLongTermFuelTrim1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_1),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_1, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 短期燃油修正2号气缸组 - 单元2
  Future<double> sendShortTermFuelTrim2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_2),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_2, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 长期燃油修正2号气缸组 - 单元
  Future<double> sendLongTermFuelTrim2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_2),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_2, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 燃油压力 kPa
  Future<int> sendFuelPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.FUEL_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 进气歧管绝对压力 kPa
  Future<int> sendIntakManifoldABSPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.INTAKE_MANIFOLD_ABS_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.INTAKE_MANIFOLD_ABS_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 发动机转速 rpm
  Future<int> sendEngineRPM({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ENGINE_RPM),
    );
    print("sendEngineRPM: $value");
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.ENGINE_RPM, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 车速 km/h
  Future<int> sendVehicleSpeed({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.VEHICLE_SPEED),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.VEHICLE_SPEED, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 正时提前 °
  Future<int> sendTimingAdvance({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.TIMING_ADVANCE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.TIMING_ADVANCE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 进气温度 °C
  Future<int> sendIntakeAirTemp({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.INTAKE_AIR_TEMP),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.INTAKE_AIR_TEMP, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// MAF空气流量 g/s
  Future<int> sendMAFFlowRate({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.MAF_FLOW_RATE),
    );
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.MAF_FLOW_RATE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 节气门位置 %
  Future<double> sendThrottlePosition({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.THROTTLE_POSITION),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(value, OBDIIPID.THROTTLE_POSITION, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 指令二次空气状态
  Future<int> sendSecondaryAirStatus({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.COMMANDED_SECONDARY_AIR_STATUS,
      ),
    );
    var parseValue = ObdDataParser.parseSecondaryAirStatus(value);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 氧传感器存在（2 组）
  Future<int> sendOxygenSensorPresent({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.OXYGEN_SENSORS_PRESENT_2_BANKS,
      ),
    );
    var parseValue = ObdDataParser.parseOxygenSensorPresent(value);
    return Future.value(parseValue);
  }

  /// 氧传感器1 单元1 V %
  Future<(double, double)> sendOxygenSensor1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_1_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_1_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器2 单元1 V %
  Future<(double, double)> sendOxygenSensor2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_2_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_2_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器3 单元1 V %
  Future<(double, double)> sendOxygenSensor3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_3_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_3_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器4 单元1 V %
  Future<(double, double)> sendOxygenSensor4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_4_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_4_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器5 单元2 V %
  Future<(double, double)> sendOxygenSensor5({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_5_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_5_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器6 单元2 V %
  Future<(double, double)> sendOxygenSensor6({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_6_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_6_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器7 单元2 V %
  Future<(double, double)> sendOxygenSensor7({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_7_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_7_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器8 单元2 V %
  Future<(double, double)> sendOxygenSensor8({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_8_A),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_8_A, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 该车辆符合的 OBD 标准
  Future<int> sendOBDStandard({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OBD_STANDARDS),
    );
    var parseValue = ObdDataParser.parseOBDStandard(value);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 氧传感器存在（分为 4 组）
  Future<int> sendOxygenSensorPresent4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.OXYGEN_SENSORS_PRESENT_4_BANKS,
      ),
    );
    var parseValue = ObdDataParser.parseOxygenSensorPresent4(value);
    return Future.value(parseValue);
  }

  /// (未完)
  /// 辅助输入状态
  Future<int> sendAuxiliaryInputStatus({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.AUX_INPUT_STATUS),
    );
    var parseValue = ObdDataParser.parseAuxiliaryInputStatus(value);
    return Future.value(parseValue);
  }

  /// 发动机当前运行时间 s
  Future<int> sendRunTimeSinceEnginStart({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.RUN_TIME_SINCE_ENGINE_START),
    );
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.RUN_TIME_SINCE_ENGINE_START, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 故障灯亮时行驶的距离(MIL) km
  Future<int> sendDistanceTraveledWithMilOn({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.DISTANCE_TRAVELED_WITH_MIL_ON,
      ),
    );
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.DISTANCE_TRAVELED_WITH_MIL_ON, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 燃油轨压力（相对于歧管真空）kPa
  Future<double> sendFuelRailPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_RAIL_PRESSURE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(value, OBDIIPID.FUEL_RAIL_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 燃油轨压力 kPa
  Future<int> sendFuelGaugePressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_RAIL_GUAGE_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.FUEL_RAIL_GUAGE_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器1 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_1_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_1_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器2 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_2_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_2_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器3 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_3_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_3_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器4 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_4_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_4_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器5 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage5({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_5_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_5_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器6 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage6({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_6_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_6_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器7 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage7({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_7_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_7_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器8 等价比 电压
  Future<(double, double)> sendOxygenSensorVoltage8({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_8_B),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_8_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 命令EGR任务 %
  Future<int> sendCommandEGR({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.COMMANDED_EGR),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.COMMANDED_EGR, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// EGR错误 %
  Future<int> sendErrorEGR({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.EGR_ERROR),
    );
    var parseValue = ObdDataParser.parseIntCommon(value, OBDIIPID.EGR_ERROR, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 命令蒸发排放清除 %
  Future<int> sendCommandEvaporativePurge({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.COMMANDED_EVAPORATIVE_PURGE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.COMMANDED_EVAPORATIVE_PURGE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 油箱液位输入 %
  Future<int> sendFuelTankLevelInput({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_TANK_LEVEL_INPUT),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.FUEL_TANK_LEVEL_INPUT, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 代码清除后的预热
  Future<int> sendWarmUpsSinceCodesCleared({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.WARM_UPS_SINCE_CODES_CLEARED),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.WARM_UPS_SINCE_CODES_CLEARED, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 代码清除后的行驶距离 km
  Future<int> sendDistanceTraveledSinceCodesCleared({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.DIST_TRAV_SINCE_CODES_CLEARED,
      ),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.DIST_TRAV_SINCE_CODES_CLEARED, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 蒸发系统蒸汽压力 Pa
  Future<int> sendSystemVaporPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.EVAP_SYSTEM_VAPOR_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.EVAP_SYSTEM_VAPOR_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 气压 kPa
  Future<int> sendABSBarometricPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_BAROMETRIC_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_BAROMETRIC_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器1 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_1_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_1_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器2 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_2_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_2_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器3 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_3_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_3_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器4 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_4_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_4_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器5 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent5({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_5_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_5_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器6 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent6({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_6_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_6_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器7 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent7({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_7_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_7_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 氧传感器8 电流 mA
  Future<(double, double)> sendOxygenSensorCurrent8({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.OXYGEN_SENSOR_8_C),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.OXYGEN_SENSOR_8_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 催化器温度传感器1 °C
  Future<double> sendCatalystTempBankSensor1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_1,
      ),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_1, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 催化器温度传感器2 °C
  Future<double> sendCatalystTempBankSensor2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_1,
      ),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_1, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 催化器温度传感器3 °C
  Future<double> sendCatalystTempBankSensor3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_2,
      ),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_2, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 催化器温度传感器4 °C
  Future<double> sendCatalystTempBankSensor4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_2,
      ),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_2, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 未完
  /// 本次行驶的监控状态
  Future<double> sendSupportedPID({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.SUPPORTED_PIDS_41_60),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.SUPPORTED_PIDS_41_60, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 控制模块电压 V
  Future<double> sendControlModuleVoltage({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.CONTROL_MODULE_VOLTAGE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.CONTROL_MODULE_VOLTAGE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 绝对负载值 %
  Future<double> sendAbsoluteLoadValue({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_LOAD_VALUE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.ABS_LOAD_VALUE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 指令空燃比
  Future<double> sendFuelEquivalenceRatio({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(
        command + OBDIIPID.FUEL_AIR_COMMANDED_EQUIV_RATIO,
      ),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.FUEL_AIR_COMMANDED_EQUIV_RATIO, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 相对节气门位置 %
  Future<int> sendRelativeThrottlePostion({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.RELATIVE_THROTTLE_POSITION),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.RELATIVE_THROTTLE_POSITION, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 环境温度 °C
  Future<int> sendAmbientAirTemp({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.AMBIENT_AIR_TEMP),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.AMBIENT_AIR_TEMP, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 绝对油门位置B %
  Future<int> sendAbsoluteThrottlePostion1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_THROTTLE_POSITION_B),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_THROTTLE_POSITION_B, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 绝对油门位置C %
  Future<int> sendABSThrottlePostion2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_THROTTLE_POSITION_C),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_THROTTLE_POSITION_C, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 油门踏板位置D %
  Future<int> sendABSThrottlePostion3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_THROTTLE_POSITION_D),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_THROTTLE_POSITION_D, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 油门踏板位置E %
  Future<int> sendABSThrottlePostion4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_THROTTLE_POSITION_E),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_THROTTLE_POSITION_E, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 油门踏板位置F %
  Future<int> sendABSThrottlePostion5({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_THROTTLE_POSITION_F),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ABS_THROTTLE_POSITION_F, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 指令油门执行器 %
  Future<int> sendABSThrottlePostion6({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.COMMANDED_THROTTLE_ACTUATOR),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.COMMANDED_THROTTLE_ACTUATOR, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// MIL运行时间 min
  Future<int> sendTimeRunWithMilOn({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.TIME_RUN_WITH_MIL_ON),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.TIME_RUN_WITH_MIL_ON, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 故障码清除后运行时间 min
  Future<int> sendTimeSinceCodesCleared({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.TIME_SINCE_CODES_CLEARED),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.TIME_SINCE_CODES_CLEARED, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 空流计的最大流量值 g/s
  Future<int> sendMaxMAFRate({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.MAX_MAF_RATE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.MAX_MAF_RATE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 乙醇燃油比例 %
  Future<double> sendEthanolFuelPercent({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ETHANOL_FUEL_PERCENT),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.ETHANOL_FUEL_PERCENT, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// EVAP系统绝对蒸气压 kPa
  Future<double> sendAbsoluteEvapSystemVaporPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ABS_EVAP_SYS_VAPOR_PRESSURE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.ABS_EVAP_SYS_VAPOR_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// EVAP系统蒸气压 Pa
  Future<int> sendEvapSystemVaporPressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.EVAP_SYS_VAPOR_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.EVAP_SYS_VAPOR_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 短期二次氧传感修正 Bank1 Bank3 %
  Future<(double, double)> sendShortTermSecondOxygenBank1({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_1_3),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_1_3, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 长期二次氧传感修正 Bank1 Bank3 %
  Future<(double, double)> sendLongTermSecondOxygenBank2({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_1_3),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_1_3, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 短期二次氧传感器修正 Bank2 Bank4 %
  Future<(double, double)> sendShortTermSecondOxygenBank3({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_2_4),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_2_4, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 长期二次氧传感器修正 Bank2 Bank4 %
  Future<(double, double)> sendLongTermSecondOxygenBank4({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_2_4),
    );
    var parseValue = ObdDataParser.parseDoubleTwoCommon(
      value,
      OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_2_4, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 燃油轨绝对压力值 kPa
  Future<int> sendFuelRailAbsolutePressure({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_RAIL_ABS_PRESSURE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.FUEL_RAIL_ABS_PRESSURE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 相对油门位置 %
  Future<double> sendRelativeAcceleratorPedalPosition({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.RELATIVE_ACCELERATOR_PEDAL_POS),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.RELATIVE_ACCELERATOR_PEDAL_POS, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 混动/纯电 电池组剩余电量 %
  Future<double> sendHybridBatteryRemaingLift({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.HYBRID_BATTERY_REMAINING_LIFE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.HYBRID_BATTERY_REMAINING_LIFE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 发动机油温 °C
  Future<int> sendEngineOilTemperature({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ENGINE_OIL_TEMP),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.ENGINE_OIL_TEMP, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 燃油喷射正时 °
  Future<double> sendFuelInjectionTiming({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.FUEL_INJECTION_TIMING),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.FUEL_INJECTION_TIMING, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 发动机燃油率 L/h
  Future<double> sendEngineFuelRate({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.ENGINE_FUEL_RATE),
    );
    var parseValue = ObdDataParser.parseDoubleCommon(
      value,
      OBDIIPID.ENGINE_FUEL_RATE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 驾驶员的动力请求 - 扭矩百分比 %
  Future<int> sendDemandEnginePercentTorque({bool isFreeze = false}) async {
    var command = isFreeze ? OBDIIPID.SERVICE_02 : OBDIIPID.SERVICE_01;
    var value = await sendCommand(
      Tools.format(command + OBDIIPID.DEMANDED_ENGINE_PERCENT_TORQUE),
    );
    var parseValue = ObdDataParser.parseIntCommon(
      value,
      OBDIIPID.DEMANDED_ENGINE_PERCENT_TORQUE, isFreeze: isFreeze);
    return Future.value(parseValue);
  }

  /// 发送指令
  Future<String> sendCommand(String command) async {
    Completer<String> completer = Completer<String>();

    // 清空之前的数据和缓冲区
    internalPayload.clear();
    stringFromData.value = "";
    currentCommand = command;
    state = ELM327State.idle;
    // 清除当前命令的历史缓冲区数据
    _clearData(command);
    // 清理所有过期数据包
    _cleanupDataPackets();

    // 先设置监听，确保不会丢失任何数据包
    StreamSubscription? subscription;
    subscription = BLEManager.instance.readCharacteristic?.lastValueStream.listen((
      value,
    ) {
      // print("------接收数据通知: ${value.toHexString()}");
      if (!completer.isCompleted && value.isNotEmpty) {
        onReceived(value);
      }
    });

    // 设置超时处理
    Timer? timeoutTimer = Timer(const Duration(seconds: 5), () {
      if (!completer.isCompleted) {
        print("------命令执行超时: $command");
        state = ELM327State.timeout;
        completer.completeError("Command timeout");
        if (subscription != null) {
          subscription.cancel();
        }
      }
    });

    // 监听数据变化（使用一次性订阅避免多个监听器并存）
    StreamSubscription? dataSubscription;
    dataSubscription = stringFromData.stream.listen((value) {
      if (!completer.isCompleted) {
        if (state == ELM327State.msgRXD) {
          var receivedString = value.clip();
          print("------监听数据:$stringFromData, 解析后: $receivedString");
          timeoutTimer.cancel();
          completer.complete(receivedString);
          dataSubscription?.cancel();
          if (subscription != null) {
            subscription.cancel();
          }
        } else if ([ELM327State.timeout, ELM327State.unableToConnect, ELM327State.generalError, ELM327State.noData, ELM327State.stopped].contains(state)) {
          timeoutTimer.cancel();
          completer.completeError(state.toString());
          dataSubscription?.cancel();
          if (subscription != null) {
            subscription.cancel();
          }
        }
      }
    });
    // 确保在完成时取消订阅
    completer.future.whenComplete(() {
      dataSubscription?.cancel();
    });

    List<int> data = utf8.encode(command);
    print("------发送指令: $command, 原始数据:${data.toHexString()}");
    // 发送数据
    bool writeSuccess = await BLEManager.instance.write(data, maxRetries: 3);

    if (!writeSuccess) {
      print("写入数据失败");
      timeoutTimer.cancel();
      completer.completeError("Failed to write command");
      if (subscription != null) {
        subscription.cancel();
      }
      return completer.future;
    }

    return completer.future;
  }

  /// 数据包缓冲区管理 - 用于处理分段接收的数据
  final Map<String, List<String>> _dataPacketBuffer = {};
  final Map<String, DateTime> _dataPacketTimestamps = {};

  /// 添加数据包到缓冲区并检查是否完成
  bool _addDataPacket(String command, String packet) {
    // 初始化缓冲区
    if (!_dataPacketBuffer.containsKey(command)) {
      _dataPacketBuffer[command] = [];
      _dataPacketTimestamps[command] = DateTime.now();
    }
    // 添加数据包
    _dataPacketBuffer[command]!.add(packet);
    // 更新时间戳
    _dataPacketTimestamps[command] = DateTime.now();

    String originalString = _getCompleteData(command);
    // 去掉最后的 ">"，再检查剩余部分是否为空或仅含空白符
    String result = originalString.replaceAll('>', '').trim();
    // print("------接受数据: $originalString, 解析后数据: $result, 当前包数据: $packet");
    if (result.isNotEmpty && packet.endsWith(">")) {
      return true;
    } else {
      return false;
    }
  }

  /// 获取完整的数据并清除缓冲区
  String _getCompleteData(String command) {
    if (!_dataPacketBuffer.containsKey(command)) {
      return "";
    }
    // 合并所有数据包
    String completeData = _dataPacketBuffer[command]!.join("");
    // // 清除缓冲区
    // _dataPacketBuffer.remove(command);
    // _dataPacketTimestamps.remove(command);
    return completeData;
  }

  void _clearData(String command) {
    // 清除缓冲区
    _dataPacketBuffer.remove(command);
    _dataPacketTimestamps.remove(command);
  }

  /// 清理过期的数据包缓冲区
  void _cleanupDataPackets() {
    final now = DateTime.now();
    final expiredCommands = _dataPacketTimestamps.entries
        .where((entry) => now.difference(entry.value).inSeconds > 10)
        .map((entry) => entry.key)
        .toList();

    for (var command in expiredCommands) {
      _dataPacketBuffer.remove(command);
      _dataPacketTimestamps.remove(command);
      print('清理过期数据包: $command');
    }
  }

  /// 公共解析方法 - 处理接收到的数据包
  void onReceived(List<int> value) {
    // 定期清理过期的数据包
    _cleanupDataPackets();
    // 避免数据重复添加
    var tempPayload = List<int>.from(value);
    // 解码数据
    String strFromData;
    try {
      strFromData = utf8.decode(value);
    } catch (e) {
      print("数据解码异常: $e, 原始数据: $value");
      strFromData = String.fromCharCodes(value);
    }
    // print("------接收到数据包内容: $strFromData, 指令: $currentCommand");
    // 如果已经超时，不再处理数据
    if (state == ELM327State.timeout) {
      print("已超时，忽略数据: $strFromData");
      return;
    }
    // 添加数据包到缓冲区
    bool isComplete = _addDataPacket(currentCommand, strFromData);
    // 检测异常数据
    if (strFromData.contains("UNABLETOCONNECT")) {
      state = ELM327State.unableToConnect;
      print("------无法连接: $strFromData");
    } else if (strFromData.contains("NODATA")) {
      state = ELM327State.noData;
      print("------无数据: $strFromData");
    } else if (strFromData.contains("STOPPED")) {
      state = ELM327State.stopped;
      print("------已停止: $strFromData");
    } else if (strFromData.contains("ERROR")) {
      state = ELM327State.generalError;
      print("------错误: $strFromData");
    } else if (isComplete) {
      // 数据接收完成，以 > 结尾
      String completeData = _getCompleteData(currentCommand);
      // print("------数据接收完成: $completeData");
      state = ELM327State.msgRXD;
      // 设置完整的数据
      stringFromData.value = completeData;
      _clearData(currentCommand);
    } else {
      // 正常数据包，继续等待更多数据
      state = ELM327State.success;
      // 特殊处理初始化命令
      if (value.isNotEmpty &&
          stringFromData.isEmpty &&
          currentCommand.contains(ATCommands.SET_ALL_TO_DEFAULTS)) {
        print("初始化命令成功: $strFromData");
        state = ELM327State.msgRXD;
      }
      // 更新当前累积的数据
      stringFromData.value = _dataPacketBuffer[currentCommand]?.join("") ?? "";
    }

    // 特殊处理连接状态检查
    if (currentCommand.startsWith("0100") && state == ELM327State.success) {
      var result = strFromData.clip();
      print("连接状态检查结果: $result");
      if (result.contains("4100")) {
        connected = true;
        print("ELM327 已连接");
      }
    }

    // 累加原始数据到内部缓冲区
    internalPayload.addAll(tempPayload);
  }
}
