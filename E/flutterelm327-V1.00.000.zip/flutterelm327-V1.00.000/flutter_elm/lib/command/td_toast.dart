import 'package:flutter/material.dart';
import 'package:oktoast/oktoast.dart';

class ToastAlert {

  static void show(String? msg,
      {int duration = 2000, ToastPosition position = ToastPosition.center}) {
    if (msg == null) {
      return;
    }
    showToast(msg,
        duration: Duration(milliseconds: duration),
        dismissOtherToast: true,
        position: position,
        radius: 3,
        textPadding: const EdgeInsets.all(10));
  }

  static void cancelToast() {
    dismissAllToast();
  }

  static void showAlert(BuildContext context,
      {String title = '',
      String content = '',
      void Function()? ok,
      void Function()? cancel}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(''),
          content: Text(content),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // 关闭弹框
                if (ok != null) {
                  ok();
                }
              },
              child: Text('确定'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // 关闭弹框
                if (cancel != null) {
                  cancel();
                }
              },
              child: Text('取消'),
            ),
          ],
        );
      },
    );
  }
}
