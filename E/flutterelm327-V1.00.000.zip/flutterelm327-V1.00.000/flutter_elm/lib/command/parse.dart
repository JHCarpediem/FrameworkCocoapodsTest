// 数据流

import 'package:flutter_elm/command/elm_237.dart';
import 'package:flutter_elm/tools/string_extension.dart';

class ObdDataParser {
  /// 解析协议类型
  static String parseProtocolType(String response) {
    // 如果响应直接包含协议名称，则直接返回
    if (response.contains(RegExp(r'ISO|SAE'))) {
      return response.trim();
    }

    // 获取协议代码（取响应的第一个字符）
    String code = response.trim().isNotEmpty ? response.trim().substring(0, 1) : '';

    // 根据协议代码查找对应的协议名称
    for (var protocol in ProtocolID.values) {
      if (protocol.value == code) {
        switch (protocol) {
          case ProtocolID.ISO_9141_5_BAUD_INIT:
            return 'ISO 9141-2';
          case ProtocolID.ISO_14230_5_BAUD_INIT:
            return 'ISO 14230-4';
          case ProtocolID.SAE_J1850_PWM_41_KBAUD:
          case ProtocolID.SAE_J1850_PWM_10_KBAUD:
            return 'SAE J1850';
          default:
            return protocol.name.replaceAll('_', ' ');
        }
      }
    }

    return 'Unknown Protocol';
  }

  /// 解析ECU信息
  static String parseECUInfo(String response) {
    // 0904响应格式: 49 04 [数量] [ECU1] [ECU2] ...
    const header = '4904';
    if (!response.contains(header)) return 'No ECU data';

    final startIndex = response.indexOf(header) + header.length;
    if (startIndex >= response.length) return 'Invalid ECU response';

    // 获取ECU数量 (一个字节)
    String countHex = response.substring(startIndex, startIndex + 2);
    int count = countHex.hexToInt();

    List<String> ecus = [];
    int currentIndex = startIndex + 2;

    // 每个ECU信息占4个字节 (模式+ID+描述符)
    for (int i = 0; i < count; i++) {
      if (currentIndex + 6 > response.length) break;

      String ecuHex = response.substring(currentIndex, currentIndex + 6);
      currentIndex +=6;

      // ECU类型解析 (简化版)
      String ecuType = _getEcuType(ecuHex.substring(0,2));
      ecus.add('ECU ${i+1}: $ecuType (0x${ecuHex.substring(2)})');
    }

    return ecus.isNotEmpty ? ecus.join('\n') : 'No ECUs detected';
  }

  /// 获取ECU类型描述
  static String _getEcuType(String typeHex) {
    switch(typeHex) {
      case '01': return 'Engine Control Module (ECM)';
      case '02': return 'Transmission Control Module (TCM)';
      case '03': return 'Brake Control Module (BCM)';
      case '04': return 'Body Control Module';
      case '05': return 'Instrument Cluster';
      default: return 'Unknown ECU (0x$typeHex)';
    }
  }

  /// 解析VIN码
  static String parseVIN(String response) {
    const header = "490201";
    final headerIndex = response.indexOf(header);

    if (headerIndex == -1) return ""; // 没有找到 header

    // Swift 中是 headerRange.upperBound，即 header 后面的第一个字符位置
    var idx = headerIndex + header.length; // Dart 中对应 upperBound

    StringBuffer vin = StringBuffer(); // 用于拼接最终的 VIN 码
    const totalPairs = 19; // 17 VIN digits + 2 skipped line numbers

    for (int i = 0; i < totalPairs * 2; i += 2) {
      if (idx + 1 >= response.length) break; // 防止越界，至少要有两个字符组成一对

      final char1 = response[idx];
      final char2 = response[idx + 1];
      final temp = '$char1$char2'; // 两位的十六进制字符串，比如 "30", "41"

      if (temp.contains(':')) {
        idx += 2; // 跳过这一对（比如 "1:" 或 "2:"）
        continue;
      }

      // 将十六进制字符串 temp 转为 ASCII 字符
      final asciiChar = temp.hexStringToASCII();
      if (asciiChar != null) {
        vin.write(asciiChar); // 拼接到 VIN
      }

      idx += 2; // 移动到下一对
    }

    return vin.toString(); // 返回完整的 VIN 字符串
  }

  /// 解析故障码
  static List<OBDIIDTC> parseDTC(String response, String service) {
    return DTC.parseDTCs(response, service);
  }

  /// (未完)
  /// 解析监控自 DTCs 清除后的状态（包括故障指示灯（MIL）、状态和 DTC 数量、部件测试、DTC 就绪检查）
  static int parseMonitorStatus(String response) {
    const target = "4100";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// (未完)
  /// 指令二次空气状态
  static int parseSecondaryAirStatus(String response) {
    const target = "4112";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// (未完)
  /// 氧传感器存在（2 组）
  static int parseOxygenSensorPresent(String response) {
    const target = "4113";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// (未完)
  /// 该车辆符合的 OBD 标准
  static int parseOBDStandard(String response) {
    const target = "411C";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// (未完)
  /// 氧传感器存在（分为 4 组）
  static int parseOxygenSensorPresent4(String response) {
    const target = "411D";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// (未完)
  /// 辅助输入状态
  static int parseAuxiliaryInputStatus(String response) {
    const target = "411E";
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(target));
    final A = valueText.substring(4, 6);

    if (A.length != 2) return 0;
    return A.hexToInt();
  }

  /// 公共解析 int
  static int parseIntCommon(
    String response,
    String pid, {
    bool isFreeze = false,
  }) {
    final target = pid;
    var header = "41$pid";
    if (isFreeze) {
      header = "42$pid";
    }
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(header));
    // print("------数据长度： ${valueText.length} valueText: $valueText");
    var A = valueText.substring(4, 6);
    if (isFreeze) {
      A = valueText.substring(6, 8);
    }
    if (A.length != 2) return 0;

    if (target == OBDIIPID.FUEL_PRESSURE) {
      // 燃油压力

      return 3 * A.hexToInt();
    } else if (target == OBDIIPID.ENGINE_RPM ||
        target == OBDIIPID.EVAP_SYSTEM_VAPOR_PRESSURE) {
      // 发动机转速,蒸发系统蒸汽压力

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0;

      var value = ((256 * A.hexToInt() + B.hexToInt()) / 4).round();
      print('------$target 转速数据: $value');
      return value;
    } else if (target == OBDIIPID.INTAKE_MANIFOLD_ABS_PRESSURE ||
        target == OBDIIPID.WARM_UPS_SINCE_CODES_CLEARED ||
        target == OBDIIPID.VEHICLE_SPEED ||
        target == OBDIIPID.FUEL_TANK_LEVEL_INPUT) {
      // 进气歧管绝对压力,车速,自代码清除后的预热,油箱液位输入
      print('------$target 车速数据: ${A.hexToInt()}');
      return A.hexToInt();
    } else if (target == OBDIIPID.TIMING_ADVANCE) {
      // 正时提前

      return (A.hexToInt() / 2 - 64).round();
    } else if (target == OBDIIPID.DIST_TRAV_SINCE_CODES_CLEARED ||
        target == OBDIIPID.TIME_RUN_WITH_MIL_ON ||
        target == OBDIIPID.TIME_SINCE_CODES_CLEARED ||
        target == OBDIIPID.RUN_TIME_SINCE_ENGINE_START ||
        target == OBDIIPID.DISTANCE_TRAVELED_WITH_MIL_ON ||
        target == OBDIIPID.EVAP_SYS_VAPOR_PRESSURE) {
      // 自代码清除后的行驶距离, MIL运行时间,故障码清除后运行时间,发动机当前运行时间,故障灯亮时行驶的距离(MIL),EVAP系统蒸气压

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      return 256 * A.hexToInt() + B.hexToInt();
    } else if (target == OBDIIPID.MAF_FLOW_RATE) {
      // MAF空气流量

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0;
      return ((A.hexToInt() * 256 + B.hexToInt()) / 100).round();
    } else if (target == OBDIIPID.ABS_BAROMETRIC_PRESSURE) {
      // 绝对大气压力

      return A.hexToInt();
    } else if (target == OBDIIPID.RELATIVE_THROTTLE_POSITION ||
        target == OBDIIPID.ABS_THROTTLE_POSITION_B ||
        target == OBDIIPID.ABS_THROTTLE_POSITION_C ||
        target == OBDIIPID.ABS_THROTTLE_POSITION_D ||
        target == OBDIIPID.ABS_THROTTLE_POSITION_E ||
        target == OBDIIPID.ABS_THROTTLE_POSITION_F ||
        target == OBDIIPID.COMMANDED_THROTTLE_ACTUATOR ||
        target == OBDIIPID.COMMANDED_EGR ||
        target == OBDIIPID.COMMANDED_EVAPORATIVE_PURGE) {
      // 相对节气门位置,环境温度B~F,指令油门执行器,命令EGR任务,命令蒸发排放清除

      return (100 / 255 * A.hexToInt()).round();
    } else if (target == OBDIIPID.ENGINE_COOLANT_TEMP ||
        target == OBDIIPID.INTAKE_AIR_TEMP ||
        target == OBDIIPID.AMBIENT_AIR_TEMP ||
        target == OBDIIPID.ENGINE_OIL_TEMP) {
      // 冷却液温度,进气温度,环境温度,发动机油温

      return A.hexToInt() - 40;
    } else if (target == OBDIIPID.EGR_ERROR) {
      // EGR错误

      return (100 / 128 * A.hexToInt() - 100).round();
    } else if (target == OBDIIPID.FUEL_RAIL_GUAGE_PRESSURE ||
        target == OBDIIPID.FUEL_RAIL_ABS_PRESSURE) {
      // 燃油轨压力

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0;
      return 10 * (256 * A.hexToInt() + B.hexToInt());
    } else if (target == OBDIIPID.MAX_MAF_RATE) {
      // 空流计的最大流量值

      return A.hexToInt() * 10;
    } else if (target == OBDIIPID.DEMANDED_ENGINE_PERCENT_TORQUE) {
      // 驾驶员的动力请求

      return A.hexToInt() - 125;
    } else {
      return 0;
    }
  }

  /// 公共解析 double
  static double parseDoubleCommon(
    String response,
    String pid, {
    bool isFreeze = false,
  }) {
    final target = pid;
    var header = "41$pid";
    if (isFreeze) {
      header = "42$pid";
    }
    if (!response.contains(target)) return 0;

    final valueText = response.substring(response.indexOf(header));
    var A = valueText.substring(4, 6);
    if (isFreeze) {
      A = valueText.substring(6, 8);
    }

    if (target == OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_1 ||
        target == OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_1 ||
        target == OBDIIPID.SHORT_TERM_FUEL_TRIM_BANK_2 ||
        target == OBDIIPID.LONG_TERM_FUEL_TRIM_BANK_2) {
      // 短期燃油修正1号气缸组1~4

      return 100.0 / 128.0 * A.hexToInt() - 100.0;
    } else if (target == OBDIIPID.ENGINE_LOAD ||
        target == OBDIIPID.THROTTLE_POSITION ||
        target == OBDIIPID.RELATIVE_ACCELERATOR_PEDAL_POS ||
        target == OBDIIPID.HYBRID_BATTERY_REMAINING_LIFE ||
        target == OBDIIPID.ETHANOL_FUEL_PERCENT) {
      // 发动机负载,节气门位置,相对油门位置,混动/纯电 电池组剩余电量,乙醇燃油比例

      return 100.0 / 255.0 * A.hexToInt();
    } else if (target == OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_1 ||
        target == OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_1 ||
        target == OBDIIPID.CATALYST_TEMP_BANK_1_SENSOR_2 ||
        target == OBDIIPID.CATALYST_TEMP_BANK_2_SENSOR_2) {
      // 催化器温度传感器1~4

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return (256.0 * A.hexToInt() + B.hexToInt()) / 10.0 - 40.0;
    } else if (target == OBDIIPID.CONTROL_MODULE_VOLTAGE) {
      // 控制模块电压

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return (256.0 * A.hexToInt() + B.hexToInt()) / 1000.0;
    } else if (target == OBDIIPID.ABS_LOAD_VALUE) {
      // 绝对负载值

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return 100.0 / 255.0 * (256.0 * A.hexToInt() + B.hexToInt());
    } else if (target == OBDIIPID.FUEL_AIR_COMMANDED_EQUIV_RATIO) {
      // 指令空燃比

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return 2 / 65536.0 * (256.0 * A.hexToInt() + B.hexToInt());
    } else if (target == OBDIIPID.FUEL_RAIL_PRESSURE) {
      // 燃油轨压力（相对于歧管真空）

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return 0.079 * (256.0 * A.hexToInt() + B.hexToInt());
    } else if (target == OBDIIPID.ABS_EVAP_SYS_VAPOR_PRESSURE) {
      // EVAP系统绝对蒸气压

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return (256.0 * A.hexToInt() + B.hexToInt()) / 200.0;
    } else if (target == OBDIIPID.FUEL_INJECTION_TIMING) {
      // 燃油喷射正时

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return (256.0 * A.hexToInt() + B.hexToInt()) / 128.0 - 210.0;
    } else if (target == OBDIIPID.ENGINE_FUEL_RATE) {
      // 发动机燃油率

      var B = valueText.substring(6, 8);
      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (B.length != 2) return 0.0;
      return (256.0 * A.hexToInt() + B.hexToInt()) / 20.0;
    } else {
      return 0;
    }
  }

  /// 公共解析 (double, double)
  static (double, double) parseDoubleTwoCommon(
    String response,
    String pid, {
    bool isFreeze = false,
  }) {
    final target = pid;
    var header = "41$pid";
    if (isFreeze) {
      header = "42$pid";
    }
    if (!response.contains(target)) return (0.0, 0.0);

    final valueText = response.substring(response.indexOf(header));
    var A = valueText.substring(4, 6);
    if (isFreeze) {
      A = valueText.substring(6, 8);
    }

    if (A.length != 2) return (0.0, 0.0);

    if (target == OBDIIPID.OXYGEN_SENSOR_1_C ||
        target == OBDIIPID.OXYGEN_SENSOR_2_C ||
        target == OBDIIPID.OXYGEN_SENSOR_3_C ||
        target == OBDIIPID.OXYGEN_SENSOR_4_C ||
        target == OBDIIPID.OXYGEN_SENSOR_5_C ||
        target == OBDIIPID.OXYGEN_SENSOR_6_C ||
        target == OBDIIPID.OXYGEN_SENSOR_7_C ||
        target == OBDIIPID.OXYGEN_SENSOR_8_C) {
      var B = valueText.substring(6, 8);
      var C = valueText.substring(8, 10);
      var D = valueText.substring(10, 12);

      if (isFreeze) {
        B = valueText.substring(8, 10);
        C = valueText.substring(10, 12);
        D = valueText.substring(12, 14);
      }
      // 氧传感器1~8 电流
      if (B.length != 2 || C.length != 2 || D.length != 2) return (0.0, 0.0);
      var value1 = 2 / 65536.0 * (256 * A.hexToInt() + B.hexToInt());
      var value2 = (256 * C.hexToInt() + D.hexToInt()) / 256.0 - 128.0;
      return (value1, value2);
    } else if (target == OBDIIPID.OXYGEN_SENSOR_1_B ||
        target == OBDIIPID.OXYGEN_SENSOR_2_B ||
        target == OBDIIPID.OXYGEN_SENSOR_3_B ||
        target == OBDIIPID.OXYGEN_SENSOR_4_B ||
        target == OBDIIPID.OXYGEN_SENSOR_5_B ||
        target == OBDIIPID.OXYGEN_SENSOR_6_B ||
        target == OBDIIPID.OXYGEN_SENSOR_7_B ||
        target == OBDIIPID.OXYGEN_SENSOR_8_B) {
      // 氧传感器B~F 电压

      var B = valueText.substring(6, 8);
      var C = valueText.substring(8, 10);
      var D = valueText.substring(10, 12);

      if (isFreeze) {
        B = valueText.substring(8, 10);
        C = valueText.substring(10, 12);
        D = valueText.substring(12, 14);
      }
      if (A.length != 2 || B.length != 2 || C.length != 2 || D.length != 2) {
        return (0.0, 0.0);
      }
      return (
        2 / 65536 * (256 * A.hexToInt() + B.hexToInt()),
        8 / 65536 * (256 * C.hexToInt() + D.hexToInt()),
      );
    } else if (target == OBDIIPID.OXYGEN_SENSOR_1_A ||
        target == OBDIIPID.OXYGEN_SENSOR_2_A ||
        target == OBDIIPID.OXYGEN_SENSOR_3_A ||
        target == OBDIIPID.OXYGEN_SENSOR_4_A ||
        target == OBDIIPID.OXYGEN_SENSOR_5_A ||
        target == OBDIIPID.OXYGEN_SENSOR_6_A ||
        target == OBDIIPID.OXYGEN_SENSOR_7_A ||
        target == OBDIIPID.OXYGEN_SENSOR_8_A) {
      // 氧传感器1~8 电压

      var B = valueText.substring(6, 8);

      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (A.length != 2 || B.length != 2) return (0.0, 0.0);
      var value1 = A.hexToInt() / 200.0;
      var value2 = 100.0 * B.hexToInt() / 128.0 - 100.0;
      return (value1, value2);
    } else if (target == OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_1_3 ||
        target == OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_1_3 ||
        target == OBDIIPID.SHORT_TERM_SEC_OXY_SENS_TRIM_2_4 ||
        target == OBDIIPID.LONG_TERM_SEC_OXY_SENS_TRIM_2_4) {
      // 短期二次氧传感器修正1~3, 长期二次氧传感器修正1~3, 短期二次氧传感器修正2~4, 长期二次氧传感器修正2~4
      var B = valueText.substring(6, 8);

      if (isFreeze) {
        B = valueText.substring(8, 10);
      }
      if (A.length != 2 || B.length != 2) return (0.0, 0.0);
      var value1 = 100.0 / 128.0 * A.hexToInt() - 100.0;
      var value2 = 100.0 / 128.0 * B.hexToInt() - 100.0;
      return (value1, value2);
    } else {
      return (0.0, 0.0);
    }
  }
}

extension DTC on ObdDataParser {
  /// 解析故障码
  static List<OBDIIDTC> parseDTCs(String message, String service) {
    List<OBDIIDTC> dtcCodes = [];

    if (message.isEmpty) return dtcCodes;

    String newService = service;
    final startIndexPattern =
        '4${newService.substring(1, 2)}'; // "4" + service 的第2个字符
    final range = message.indexOf(startIndexPattern);
    if (range == -1) return dtcCodes;

    final infoSubstring = message.substring(range);
    final components = infoSubstring.split(':');

    String fullString = '';
    if (components.length > 1) {
      for (final component in components) {
        if (component.length > 1) {
          fullString += component.substring(0, component.length - 1);
        }
      }
    } else {
      fullString = infoSubstring;
    }

    if (fullString.length < 4) return dtcCodes;

    int allCodeNumber = 0;

    // if (service == '0A') {
    //   if (!fullString.contains('4A')) return dtcCodes;

    //   final indexRange = fullString.indexOf('4A');
    //   if (indexRange == -1) return dtcCodes;

    //   final startIndex = fullString.indexOf('4A') + 4;
    //   final leftValue = fullString.substring(startIndex);

    //   print("------ startIndex: $startIndex, leftValue: $leftValue");
    //   if (leftValue.length <= 4) return dtcCodes;

    //   for (int i = 0; i < leftValue.length ~/ 4; i++) {
    //     int number = 4;
    //     if (i * 4 + number > leftValue.length) {
    //       number = leftValue.length - i * 4;
    //     }

    //     final startIndex = leftValue.indexOf(
    //       leftValue.substring(i * 4, i * 4 + number),
    //     );
    //     final endIndex = startIndex + number;
    //     final codeString = leftValue.substring(startIndex, endIndex);
    //     print(
    //       "------ startIndex: $startIndex, endIndex: $endIndex, codeString: $codeString, number: $number",
    //     );
    //     if (number == 4) {
    //       if (codeString == '0000') continue;

    //       final code = getCodeModelWithCodeStr(codeString);
    //       final dtcCode = OBDIIDTC(
    //         code: code,
    //         category: Category.fromRawValue(service),
    //       );
    //       if (dtcCodes.contains(dtcCode)) continue;

    //       dtcCodes.add(dtcCode);
    //       print("......");
    //       print(code);
    //     }
    //   }

    //   print("DTCodes For service $service: $dtcCodes");

    //   return dtcCodes;
    // }

    for (int i = 0; i < fullString.length ~/ 4; i++) {
      int number = 4;
      if (i * 4 + number > fullString.length) {
        number = fullString.length - i * 4;
      }

      final startIndex = fullString.indexOf(
        fullString.substring(i * 4, i * 4 + number),
      );
      final endIndex = startIndex + number;
      final codeString = fullString.substring(startIndex, endIndex);

      if (i == 0) {
        final allCodeNumberString = codeString.substring(2);
        allCodeNumber = int.parse(allCodeNumberString, radix: 16);
      } else if (i <= allCodeNumber && number == 4) {
        if (codeString == '0000') continue;

        final code = getCodeModelWithCodeStr(codeString);
        final dtcCode = OBDIIDTC(
          code: code,
          category: Category.fromRawValue(service), 
          troubleCode: '',
        );
        if (dtcCodes.contains(dtcCode)) continue;

        dtcCodes.add(dtcCode);
        print(code);
      }
    }

    return dtcCodes;
  }

  /// 根据故障码字符串获取对应的OBDIIDTC模型
  /// 将原始 DTC 编码字符串（如 "0123"）转换为标准格式（如 "P0123"）
  static String getCodeModelWithCodeStr(String codeString) {
    final codeCategories = ['P', 'C', 'B', 'U'];

    // 取第一个字符（十六进制数字，如 "0", "1", "2", "3"）
    final codeBigStr = codeString.substring(0, 1); // 第1个字符
    final codeSmallStr = codeString.substring(1); // 剩余部分

    // 将第一个字符作为十六进制字符串解析为整数
    final codeNum = int.parse(codeBigStr, radix: 16);

    // 计算分类索引和子编号
    final codeBigNub = codeNum ~/ 4; // 整除，得到分类索引 0~3
    final codeSmallNub = codeNum % 4; // 取余，得到子编号 0~3

    // 从 codeCategories 列表中取出分类前缀，如 P, C, B, U
    final categoryPrefix = codeCategories[codeBigNub];

    // 拼接成标准 DTC 格式，如 P0123
    final code = '$categoryPrefix$codeSmallNub$codeSmallStr';

    return code;
  }
}
