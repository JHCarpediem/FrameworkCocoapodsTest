

import 'package:flutter_elm/command/elm_237.dart';
import 'package:flutter_elm/tools/tools.dart';

class DTCParser {
  bool debugMode = false;

  /// 获取监控状态
  String sendMonitorStatus() {
    return Tools.format(OBDIIPID.SERVICE_01+OBDIIPID.MONITOR_STATUS_SINCE_DTC_CLEARED);
  }
  /// 解析监控状态
  int parseMonitorStatus(String response) {
    const target = "4101";
    if (!response.contains(target)) return 0;
    
    final valueText = response.substring(response.indexOf(target));
    final value = valueText.substring(4, 12);
    
    if (value.length != 8) return 0;
    return int.parse(value, radix: 16);
  }

  /// 获取DTC码
  String sendCurrentDTs() {
    return Tools.format(OBDIIPID.SERVICE_03);
  }
  /// 解析DTC码
  List<DTCCode> parseCurrentDT(String message, String service) {
    List<DTCCode> dtcCodes = [];
    if (message.isEmpty) return dtcCodes;

    final servicePrefix = '4${service.substring(1, 2)}';
    if (!message.contains(servicePrefix)) return dtcCodes;

    var infoSubstring = message.substring(message.indexOf(servicePrefix));
    final components = infoSubstring.split(':');
    
    var fullString = '';
    if (components.length > 1) {
      for (var component in components) {
        if (component.length > 1) {
          fullString += component.substring(0, component.length - 1);
        }
      }
    } else {
      fullString = infoSubstring;
    }

    if (fullString.length < 4) return dtcCodes;

    // 处理永久性DTC
    if (service == "0A") {
      return _parsePermanentDTC(fullString, service, dtcCodes);
    }

    return _parseRegularDTC(fullString, service, dtcCodes);
  }

  /// 获取DTC码
  String sendPendingDTC() {
    return Tools.format(OBDIIPID.SERVICE_03);
  }

  // List<DTCCode> sendPendingDTC() {
  //   return Tools.format(OBDIIPID.SERVICE_03);
  // }


  List<DTCCode> _parsePermanentDTC(String fullString, String service, List<DTCCode> dtcCodes) {
    if (!fullString.contains("4A")) return dtcCodes;
    
    final startIndex = fullString.indexOf("4A") + 4;
    final leftValue = fullString.substring(startIndex);
    
    if (leftValue.length < 4) return dtcCodes;

    for (var i = 0; i < leftValue.length ~/ 4; i++) {
      final endPos = (i + 1) * 4;
      if (endPos > leftValue.length) break;
      
      final codeString = leftValue.substring(i * 4, endPos);
      if (codeString == "0000") continue;

      final code = _getCodeFromString(codeString);
      final dtcCode = DTCCode(code: code, category: service);
      
      if (!dtcCodes.contains(dtcCode)) {
        dtcCodes.add(dtcCode);
        if (debugMode) {
          print("......");
          print(code);
        }
      }
    }
    
    if (debugMode) {
      print("DTCodes For service$service: $dtcCodes");
    }
    return dtcCodes;
  }

  List<DTCCode> _parseRegularDTC(String fullString, String service, List<DTCCode> dtcCodes) {
    for (var i = 0; i < fullString.length ~/ 4; i++) {
      final endPos = (i + 1) * 4;
      if (endPos > fullString.length) break;
      
      final codeString = fullString.substring(i * 4, endPos);
      
      if (i == 0) {
        final allCodeNumberString = codeString.substring(2);
        final allCodeNumber = int.parse(allCodeNumberString, radix: 16);
        continue;
      }
      
      if (codeString == "0000") continue;

      final code = _getCodeFromString(codeString);
      final dtcCode = DTCCode(code: code, category: service);
      
      if (!dtcCodes.contains(dtcCode)) {
        dtcCodes.add(dtcCode);
        if (debugMode) {
          print("......");
          print(code);
        }
      }
    }
    
    if (debugMode) {
      print("DTCodes For service$service: $dtcCodes");
    }
    return dtcCodes;
  }

  String _getCodeFromString(String codeString) {
    const codeCategories = ["P", "C", "B", "U"];
    
    final codeBigStr = codeString.substring(0, 1);
    final codeSmallStr = codeString.substring(1);
    
    final codeNum = int.parse(codeBigStr, radix: 16);
    final codeBigNum = codeNum ~/ 4;
    final codeSmallNum = codeNum % 4;
    
    return "${codeCategories[codeBigNum]}$codeSmallNum$codeSmallStr";
  }
}

class DTCCode {
  final String code;
  final String category;

  DTCCode({required this.code, required this.category});

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DTCCode &&
          runtimeType == other.runtimeType &&
          code == other.code &&
          category == other.category;

  @override
  int get hashCode => code.hashCode ^ category.hashCode;
}