
// MARK: - ProtocolID
enum ProtocolID {
  AUTOMATIC("0"),
  SAE_J1850_PWM_41_KBAUD("1"),
  SAE_J1850_PWM_10_KBAUD("2"),
  ISO_9141_5_BAUD_INIT("3"),
  ISO_14230_5_BAUD_INIT("4"),
  ISO_14230_FAST_INIT("5"),
  ISO_15765_11_BIT_500_KBAUD("6"),
  ISO_15765_29_BIT_500_KBAUD("7"),
  ISO_15765_11_BIT_250_KBAUD("8"),
  ISO_15765_29_BIT_250_KBAUD("9"),
  SAE_J1939_29_BIT_250_KBAUD("A"),
  USER_1_CAN("B"),
  USER_2_CAN("C");

  final String value;
  const ProtocolID(this.value);
}

// MARK: - OBDII PIDs
class OBDIIPID {
  static const String SERVICE_01 = "01";

  // Service 01 PIDs (0x00-0x20)
  static const String SUPPORTED_PIDS_1_20 = "00";               // 0x00 - bit encoded
  static const String MONITOR_STATUS_SINCE_DTC_CLEARED = "01";  // 0x01 - bit encoded
  static const String FREEZE_DTC = "02";                        // 0x02 -
  static const String FUEL_SYSTEM_STATUS = "03";                // 0x03 - bit encoded
  static const String ENGINE_LOAD = "04";                       // 0x04 - %
  static const String ENGINE_COOLANT_TEMP = "05";               // 0x05 - °C
  static const String SHORT_TERM_FUEL_TRIM_BANK_1 = "06";       // 0x06 - %
  static const String LONG_TERM_FUEL_TRIM_BANK_1 = "07";        // 0x07 - %
  static const String SHORT_TERM_FUEL_TRIM_BANK_2 = "08";       // 0x08 - %
  static const String LONG_TERM_FUEL_TRIM_BANK_2 = "09";        // 0x09 - %
  static const String FUEL_PRESSURE = "0A";                     // 0x0A - kPa
  static const String INTAKE_MANIFOLD_ABS_PRESSURE = "0B";       // 0x0B - kPa
  static const String ENGINE_RPM = "0C";                        // 0x0C - rpm
  static const String VEHICLE_SPEED = "0D";                     // 0x0D - km/h
  static const String TIMING_ADVANCE = "0E";                    // 0x0E - ° before TDC
  static const String INTAKE_AIR_TEMP = "0F";                   // 0x0F - °C
  static const String MAF_FLOW_RATE = "10";                     // 0x10 - g/s
  static const String THROTTLE_POSITION = "11";                 // 0x11 - %
  static const String COMMANDED_SECONDARY_AIR_STATUS = "12";    // 0x12 - bit encoded
  static const String OXYGEN_SENSORS_PRESENT_2_BANKS = "13";    // 0x13 - bit encoded
  static const String OXYGEN_SENSOR_1_A = "14";                 // 0x14 - V %
  static const String OXYGEN_SENSOR_2_A = "15";                 // 0x15 - V %
  static const String OXYGEN_SENSOR_3_A = "16";                 // 0x16 - V %
  static const String OXYGEN_SENSOR_4_A = "17";                 // 0x17 - V %
  static const String OXYGEN_SENSOR_5_A = "18";                 // 0x18 - V %
  static const String OXYGEN_SENSOR_6_A = "19";                 // 0x19 - V %
  static const String OXYGEN_SENSOR_7_A = "1A";                 // 0x1A - V %
  static const String OXYGEN_SENSOR_8_A = "1B";                 // 0x1B - V %
  static const String OBD_STANDARDS = "1C";                     // 0x1C - bit encoded
  static const String OXYGEN_SENSORS_PRESENT_4_BANKS = "1D";    // 0x1D - bit encoded
  static const String AUX_INPUT_STATUS = "1E";                  // 0x1E - bit encoded
  static const String RUN_TIME_SINCE_ENGINE_START = "1F";       // 0x1F - sec

  // Service 01 PIDs (0x20-0x40)
  static const String SUPPORTED_PIDS_21_40 = "20";              // 0x20 - bit encoded
  static const String DISTANCE_TRAVELED_WITH_MIL_ON = "21";     // 0x21 - km
  static const String FUEL_RAIL_PRESSURE = "22";                // 0x22 - kPa
  static const String FUEL_RAIL_GUAGE_PRESSURE = "23";          // 0x23 - kPa
  static const String OXYGEN_SENSOR_1_B = "24";                 // 0x24 - ratio V
  static const String OXYGEN_SENSOR_2_B = "25";                 // 0x25 - ratio V
  static const String OXYGEN_SENSOR_3_B = "26";                 // 0x26 - ratio V
  static const String OXYGEN_SENSOR_4_B = "27";                 // 0x27 - ratio V
  static const String OXYGEN_SENSOR_5_B = "28";                 // 0x28 - ratio V
  static const String OXYGEN_SENSOR_6_B = "29";                 // 0x29 - ratio V
  static const String OXYGEN_SENSOR_7_B = "2A";                 // 0x2A - ratio V
  static const String OXYGEN_SENSOR_8_B = "2B";                 // 0x2B - ratio V
  static const String COMMANDED_EGR = "2C";                     // 0x2C - %
  static const String EGR_ERROR = "2D";                         // 0x2D - %
  static const String COMMANDED_EVAPORATIVE_PURGE = "2E";       // 0x2E - %
  static const String FUEL_TANK_LEVEL_INPUT = "2F";             // 0x2F - %
  static const String WARM_UPS_SINCE_CODES_CLEARED = "30";      // 0x30 - count
  static const String DIST_TRAV_SINCE_CODES_CLEARED = "31";     // 0x31 - km
  static const String EVAP_SYSTEM_VAPOR_PRESSURE = "32";        // 0x32 - Pa
  static const String ABS_BAROMETRIC_PRESSURE = "33";           // 0x33 - kPa
  static const String OXYGEN_SENSOR_1_C = "34";                 // 0x34 - ratio mA
  static const String OXYGEN_SENSOR_2_C = "35";                 // 0x35 - ratio mA
  static const String OXYGEN_SENSOR_3_C = "36";                 // 0x36 - ratio mA
  static const String OXYGEN_SENSOR_4_C = "37";                 // 0x37 - ratio mA
  static const String OXYGEN_SENSOR_5_C = "38";                 // 0x38 - ratio mA
  static const String OXYGEN_SENSOR_6_C = "39";                 // 0x39 - ratio mA
  static const String OXYGEN_SENSOR_7_C = "3A";                 // 0x3A - ratio mA
  static const String OXYGEN_SENSOR_8_C = "3B";                 // 0x3B - ratio mA
  static const String CATALYST_TEMP_BANK_1_SENSOR_1 = "3C";     // 0x3C - °C
  static const String CATALYST_TEMP_BANK_2_SENSOR_1 = "3D";     // 0x3D - °C
  static const String CATALYST_TEMP_BANK_1_SENSOR_2 = "3E";     // 0x3E - °C
  static const String CATALYST_TEMP_BANK_2_SENSOR_2 = "3F";     // 0x3F - °C

  // Service 01 PIDs (0x40-0x60)
  static const String SUPPORTED_PIDS_41_60 = "40";               // 0x40 - bit encoded
  static const String MONITOR_STATUS_THIS_DRIVE_CYCLE = "41";    // 0x41 - bit encoded
  static const String CONTROL_MODULE_VOLTAGE = "42";             // 0x42 - V
  static const String ABS_LOAD_VALUE = "43";                     // 0x43 - %
  static const String FUEL_AIR_COMMANDED_EQUIV_RATIO = "44";     // 0x44 - ratio
  static const String RELATIVE_THROTTLE_POSITION = "45";         // 0x45 - %
  static const String AMBIENT_AIR_TEMP = "46";                   // 0x46 - °C
  static const String ABS_THROTTLE_POSITION_B = "47";            // 0x47 - %
  static const String ABS_THROTTLE_POSITION_C = "48";            // 0x48 - %
  static const String ABS_THROTTLE_POSITION_D = "49";            // 0x49 - %
  static const String ABS_THROTTLE_POSITION_E = "4A";            // 0x4A - %
  static const String ABS_THROTTLE_POSITION_F = "4B";            // 0x4B - %
  static const String COMMANDED_THROTTLE_ACTUATOR = "4C";        // 0x4C - %
  static const String TIME_RUN_WITH_MIL_ON = "4D";               // 0x4D - min
  static const String TIME_SINCE_CODES_CLEARED = "4E";           // 0x4E - min
  static const String MAX_VALUES_EQUIV_V_I_PRESSURE = "4F";      // 0x4F - ratio V mA kPa
  static const String MAX_MAF_RATE = "50";                       // 0x50 - g/s
  static const String FUEL_TYPE = "51";                          // 0x51 - ref table
  static const String ETHANOL_FUEL_PERCENT = "52";               // 0x52 - %
  static const String ABS_EVAP_SYS_VAPOR_PRESSURE = "53";        // 0x53 - kPa
  static const String EVAP_SYS_VAPOR_PRESSURE = "54";           // 0x54 - Pa
  static const String SHORT_TERM_SEC_OXY_SENS_TRIM_1_3 = "55";   // 0x55 - %
  static const String LONG_TERM_SEC_OXY_SENS_TRIM_1_3 = "56";    // 0x56 - %
  static const String SHORT_TERM_SEC_OXY_SENS_TRIM_2_4 = "57";   // 0x57 - %
  static const String LONG_TERM_SEC_OXY_SENS_TRIM_2_4 = "58";    // 0x58 - %
  static const String FUEL_RAIL_ABS_PRESSURE = "59";             // 0x59 - kPa
  static const String RELATIVE_ACCELERATOR_PEDAL_POS = "5A";     // 0x5A - %
  static const String HYBRID_BATTERY_REMAINING_LIFE = "5B";      // 0x5B - %
  static const String ENGINE_OIL_TEMP = "5C";                    // 0x5C - °C
  static const String FUEL_INJECTION_TIMING = "5D";              // 0x5D - °
  static const String ENGINE_FUEL_RATE = "5E";                   // 0x5E - L/h
  static const String EMISSION_REQUIREMENTS = "5F";              // 0x5F - bit encoded

  // Service 01 PIDs (0x60-0x80)
  static const String SUPPORTED_PIDS_61_80 = "60";               // 0x60 - bit encoded
  static const String DEMANDED_ENGINE_PERCENT_TORQUE = "61";     // 0x61 - %
  static const String ACTUAL_ENGINE_TORQUE = "62";              // 0x62 - %
  static const String ENGINE_REFERENCE_TORQUE = "63";            // 0x63 - Nm
  static const String ENGINE_PERCENT_TORQUE_DATA = "64";         // 0x64 - %
  static const String AUX_INPUT_OUTPUT_SUPPORTED = "65";         // 0x65 - bit encoded

  // Extended PIDs
  static const String SUPPORTED_PIDS_81_A0 = "80";               // 0x80 - bit encoded
  static const String SUPPORTED_PIDS_A1_C0 = "A0";               // 0xA0 - bit encoded
  static const String SUPPORTED_PIDS_C1_E0 = "C0";               // 0xC0 - bit encoded

  // Other Services
  static const String SERVICE_02 = "02";
  static const String SERVICE_03 = "03";
  static const String SERVICE_04 = "04";
  static const String SERVICE_07 = "07";
  static const String SERVICE_0A = "0A";

  static const int PID_INTERVAL_OFFSET = 0x20;
}


/// AT commands (https://www.sparkfun.com/datasheets/Widgets/ELM327_AT_Commands.pdf)
class ATCommands {
  // General
  static const String DISP_DEVICE_DESCRIPT = "AT @1";
  static const String DISP_DEVICE_ID = "AT @2";
  static const String STORE_DEVICE_ID = "AT @3 %s"; // 注意：Dart 用 %s 代替 Swift 的 %@
  static const String REPEAT_LAST_COMMAND = "AT \r";
  static const String ALLOW_LONG_MESSAGES = "AT AL";
  
  // OBD
  static const String AUTOMATIC_RECEIVE = "AT AR";
  static const String ADAPTIVE_TIMING_OFF = "AT AT0";
  static const String ADAPTIVE_TIMING_AUTO_1 = "AT AT1";
  static const String ADAPTIVE_TIMING_AUTO_2 = "AT AT2";
  static const String DUMP_BUFFER = "AT BD";
  static const String BYPASS_INIT_SEQUENCE = "AT BI";
  static const String TRY_BAUD_DIVISOR = "AT BRD %02d";
  static const String SET_HANDSHAKE_TIMEOUT = "AT BRT %02d";
  
  // CAN
  static const String CAN_AUTO_FORMAT_OFF = "AT CAF0";
  static const String CAN_AUTO_FORMAT_ON = "AT CAF1";
  static const String CAN_EXTENDED_ADDRESS_OFF = "AT CEA";
  static const String USE_CAN_EXTENDED_ADDRESS = "AT CEA %02d";
  static const String SET_ID_FILTER = "AT CF %s";
  static const String CAN_FLOW_CONTROL_OFF = "AT CFC0";
  static const String CAN_FLOW_CONTROL_ON = "AT CFC1";
  static const String SET_ID_MASK = "AT CM %s";
  static const String SET_CAN_PRIORITY = "AT CP %02d";
  static const String SHOW_CAN_STATUS = "AT CS";
  static const String CAN_SILENT_MODE_OFF = "AT CSM0";
  static const String CAN_SILENT_MODE_ON = "AT CSM1";
  
  // Volts
  static const String CALIBRATE_VOLTAGE_CUSTOM = "AT CV %04d";
  static const String RESTORE_CV_TO_FACTORY = "AT CV 0000";
  
  // General
  static const String SET_ALL_TO_DEFAULTS = "AT D";
  
  // CAN
  static const String DISP_DLC_OFF = "AT D0";
  static const String DISP_DLC_ON = "AT D1";
  
  // J1939
  static const String MONITOR_FOR_DM1_MESSAGES = "AT DM1";
  
  // OBD
  static const String DISP_CURRENT_PROTOCOL = "AT DP";
  static const String DISP_CURRENT_PROTOCOL_NUM = "AT DPN";
  
  // General
  static const String ECHO_OFF = "AT E0";
  static const String ECHO_ON = "AT E1";
  
  // CAN
  static const String FLOW_CONTROL_SET_DATA_TO = "AT FC SD %s";
  static const String FLOW_CONTROL_SET_HEAD_TO = "AT FC SH %s";
  static const String FLOW_CONTROL_SET_MODE_TO = "AT FC SM %s";
  
  // General
  static const String FORGE_EVENTS = "AT FE";
  
  // ISO
  static const String PERFORM_FAST_INIT = "AT FI";
  
  // OBD
  static const String HEADERS_OFF = "AT H0";
  static const String HEADERS_ON = "AT H1";
  
  // General
  static const String DISP_ID = "AT I";
  
  // ISO
  static const String SET_ISO_BAUD_10400 = "AT IB 10";
  static const String SET_ISO_BAUD_4800 = "AT IB 48";
  static const String SET_ISO_BAUD_9600 = "AT IB 96";
  
  // J1850
  static const String IFR_VAL_FROM_HEADER = "AT IFR H";
  static const String IFR_VAL_FROM_SOURCE = "AT IFR S";
  static const String IFRS_OFF = "AT IFR0";
  static const String IFRS_AUTO = "AT IFR1";
  static const String IFRS_ON = "AT IFR2";
  
  // Other
  static const String IREAD_IGNMON_INPUT_LEVEL = "AT IGN";
  
  // ISO
  static const String SET_ISO_SLOW_INIT_ADDRESS = "AT IIA %02d";
  
  // J1850
  static const String USE_J1939_ELM_DATA_FORMAT = "AT JE";
  static const String J1939_HEAD_FORMAT_OFF = "AT JHF0";
  static const String J1939_HEAD_FORMAT_ON = "AT JHF1";
  static const String USE_J1939_SAE_DATA_FORMAT = "AT JS";
  static const String SET_J1939_TIMER_X_TO_1X = "AT JTM1";
  static const String SET_J1939_TIMER_X_TO_5X = "AT JTM5";
  
  // ISO
  static const String DISP_KEY_WORDS = "AT KW";
  static const String KEY_WORD_CHECKING_OFF = "AT KW0";
  static const String KEY_WORD_CHECKING_ON = "AT KW1";
  
  // General
  static const String LINEFEEDS_OFF = "AT L0";
  static const String LINEFEEDS_ON = "AT L1";
  static const String LOW_POWER_MODE = "AT LP";
  static const String MEMORY_OFF = "AT M0";
  static const String MEMORY_ON = "AT M1";
  
  // OBD
  static const String MONITOR_ALL = "AT MA";
  
  // J1939
  static const String MONITOR_FOR_PGN = "AT MP %s";
  
  // OBD
  static const String MONITOR_FOR_RECEIVER = "AT MR %02d";
  static const String MONITOR_FOR_TRANSMITTER = "AT MT %02d";
  
  // OBD
  static const String NORMAL_LENGTH_MESSAGES = "AT NL";
  
  // OBD
  static const String SET_PROTO_OPTIONS_AND_BAUD = "AT PB %s";
  static const String PROTOCOL_CLOSE = "AT PC";
  
  // PPs
  static const String ALL_PROG_PARAMS_OFF = "AT PP FF OFF";
  static const String ALL_PROG_PARAMS_ON = "AT PP FF ON";
  static const String SET_PROG_PARAM_OFF = "AT PP %s OFF";
  static const String SET_PROG_PARAM_ON = "AT PP %s ON";
  static const String SET_PROG_PARAM_VAL = "AT PP %s SV %s";
  static const String DISP_PP_SUMMARY = "AT PPS";
  
  // OBD
  static const String RESPONSES_OFF = "AT R0";
  static const String RESPONSES_ON = "AT R1";
  static const String SET_RECEIVE_ADDRESS_TO = "AT RA %02d";
  
  // General
  static const String READ_STORED_DATA = "AT RD";
  
  // CAN
  static const String SEND_RTR_MESSAGE = "AT RTR";
  
  // Volts
  static const String READ_VOLTAGE = "AT RV";
  
  // OBD
  static const String PRINTING_SPACES_OFF = "AT S0";
  static const String PRINTING_SPACES_ON = "AT S1";
  
  // General
  static const String STORE_DATA_BYTE = "AT SD ";
  
  // OBD
  static const String SET_HEADER = "AT SH %s";
  static const String PERFORM_SLOW_INIT = "AT SI";
  static const String SET_PROTOCOL_TO_AUTO_H_SAVE = "AT SP A%s";
  static const String SET_PROTOCOL_TO_H_SAVE = "AT SP %s";
  static const String SET_PROTOCOL_TO_AUTO_SAVE = "AT SP 00";
  static const String SET_REC_ADDRESS = "AT SR %02d";
  static const String SET_STANDARD_SEARCH_ORDER = "AT SS";
  static const String SET_TIMEOUT_TO_H_X_4MS = "AT ST %02d";
  
  // ISO
  static const String SET_WAKEUP_TO_H_X_20MS = "AT SW %02d";
  
  // OBD
  static const String SET_TESTER_ADDRESS_TO = "AT TA %02d";
  static const String TRY_PROT_H_AUTO_SEARCH = "AT TP A%s";
  static const String TRY_PROT_H = "AT TP %s";
  
  // CAN
  static const String VARIABLE_DLC_OFF = "AT V0";
  static const String VARIABLE_DLC_ON = "AT V1";
  
  // ISO
  static const String SET_WAKEUP_MESSAGE = "AT WM";
  
  // General
  static const String WARM_START = "AT WS";
  static const String RESET_ALL = "AT Z";
}

class OBDIIDTC {
  final String code;
  final Category category;
  var troubleCode = "";

  OBDIIDTC({required this.code, required this.category, required this.troubleCode});

  @override
  String toString() {
    return 'OBDII DTC { code: $code, category: $category, troubleCode: $troubleCode }';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is OBDIIDTC &&
        other.code == code &&
        other.category == category;
  }

  @override
  int get hashCode => code.hashCode ^ category.hashCode;

}

enum Category {
  current('03'),
  pedding('07'),
  permanent('0A');

  final String rawValue;

  const Category(this.rawValue);

  // 通过 rawValue 获取枚举实例，类似 Swift 的 init(rawValue:)
  static Category fromRawValue(String raw) {
    switch (raw) {
      case '03':
        return Category.current;
      case '07':
        return Category.pedding;
      case '0A':
        return Category.permanent;
      default:
        return Category.current;
    }
  }

  @override
  String toString() {
    switch (this) {
      case Category.current:
        return '当前';
      case Category.pedding:
        return '待定';
      case Category.permanent:
        return '历史';
    }
  }
}