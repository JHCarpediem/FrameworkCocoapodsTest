import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:flutter_elm/modules/Model/instrument_model.dart';
import 'package:flutter_elm/modules/Page/pick_item_page.dart';

class FreezeFramePage extends StatefulWidget {
  const FreezeFramePage({super.key});

  @override
  State<FreezeFramePage> createState() => _FreezeFramePageState();
}

class _FreezeFramePageState extends State<FreezeFramePage> {
  final ScrollController _scrollController = ScrollController();
  var sender = Sender();
  var allData = InstrumentModel.genarateData(isFreeze: true);

  bool _hasLoadedData = false; // 加载状态标记，避免重复请求

  @override
  void initState() {
    super.initState();
    // 页面加载后主动触发一次数据加载
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_hasLoadedData) {
        _loadAllData();
        _hasLoadedData = true;
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadAllData() async {
    for (var model in allData) {
      if (model.fetchCommand != null && model.selected) {
        try {
          var result = await model.fetchCommand!();
          setState(() {
            model.value = result is double
                ? result
                : double.tryParse(result.toString()) ?? 0.0;
          });
        } catch (e) {
          print('Failed to fetch data for ${model.name}: $e');
          setState(() {
            model.value = double.nan;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // 只显示选中的数据
    final visibleData = allData.where((e) => e.selected).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('冻结帧'),
        actions: [
          IconButton(
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PickItemPage(items: allData),
                ),
              );
              if (result != null && result is List<InstrumentModel>) {
                // 用 result 覆盖 allData 的顺序和 selected 状态
                for (int i = 0; i < result.length; i++) {
                  allData[i]
                    ..selected = result[i].selected
                    ..name = result[i].name
                    ..value = result[i].value
                    ..unit = result[i].unit
                    ..minimum = result[i].minimum
                    ..maximum = result[i].maximum
                    ..interval = result[i].interval
                    ..fetchCommand = result[i].fetchCommand;
                }
                // 如果顺序也要同步，可以直接 allData = result;
                allData = List<InstrumentModel>.from(result);
                setState(() {});
              }
            },
            icon: Icon(Icons.filter_alt, size: 30),
          ),
        ],
      ),
      body: NotificationListener(
        child: ListView.separated(
          controller: _scrollController,
          itemBuilder: (context, index) {
            return _buildCell(visibleData[index]);
          },
          separatorBuilder: (context, index) {
            return const Divider(height: 1, thickness: 1, color: Colors.grey);
          },
          itemCount: visibleData.length, // 固定高度，优化性能
        ),
      ),
    );
  }

  Widget _buildCell(InstrumentModel model) {
    // 计算当前值是否在范围内
    bool isInRange =
        model.value >= model.minimum && model.value <= model.maximum;

    String formatted;
    if (model.value.isNaN) {
      formatted = '-';
    } else {
      formatted = model.value.toStringAsFixed(2); // 保留两位小数
      if (formatted.endsWith('.00')) {
        formatted = formatted.substring(0, formatted.length - 3); // 去掉 ".00"
      }
    }
    return SizedBox(
      height: 70,
      child: Row(
        children: [
          // 左侧文本
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    model.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  Row(
                    children: [
                      // Icon(Icons.swap_horiz, color: Colors.grey, size: 15,),
                      Text(
                        "(${model.minimum} ~ ${model.maximum} ${model.unit})",
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // 右侧数值和单位
          Expanded(
            flex: 1,
            child: Padding(
              padding: EdgeInsetsGeometry.only(right: 16),
              child: Text(
                formatted == '-' ? formatted : '$formatted ${model.unit}',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isInRange ? Colors.black : Colors.red,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
