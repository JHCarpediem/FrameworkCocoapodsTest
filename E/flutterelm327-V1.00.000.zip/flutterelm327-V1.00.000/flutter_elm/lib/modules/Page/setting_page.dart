import 'package:flutter/material.dart';
import 'package:flutter_elm/main.dart';
import 'package:flutter_elm/manager/database_manager.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:flutter_elm/modules/Page/register_page.dart';

class SettingPage extends StatefulWidget {
  const SettingPage({super.key});

  @override
  State<StatefulWidget> createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> with RouteAware {
  UserModel? _model;

  @override
  initState() {
    super.initState();

    DatabaseManager().fetchUser().then((value) {
      setState(() {
        _model = value;
      });
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 订阅路由变化
    final route = ModalRoute.of(context);
    if (route is PageRoute<dynamic>) {
      routeObserver.subscribe(this, route);
    } else {
      // 如果不是 PageRoute，可以选择不订阅，或者打印警告
      debugPrint('当前路由不是 PageRoute，无法订阅 RouteObserver');
    }
  }

  @override
  void dispose() {
    // 取消订阅
    routeObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  void didPush() {
    print('MyPage: 页面被推入堆栈（进入）');
  }

  @override
  void didPopNext() async {
    print('MyPage: 从其他页面返回到此页面');
    DatabaseManager().fetchUser().then((value) {
      setState(() {
        _model = value;
      });
    });
  }

  @override
  void didPushNext() {
    print('MyPage: 跳转到其他页面');
  }

  @override
  void didPop() {
    print('MyPage: 页面被弹出（退出）');
  }

  // 登录处理函数
  void _feedback(BuildContext context) {
    Navigator.pushNamed(context, '/feedback');
  }

  // 退出登录
  void _logout(BuildContext context) {
    if (_model != null) {
      DatabaseManager().deleteUser();
      setState(() {
        _model = null;
      });
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('设置')),
      backgroundColor: Color.from(alpha: 1, red: 245, green: 245, blue: 245),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ListView(
              children: [
                ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('昵称'), Text(_model?.userName ?? 'TOPDON')],
                  ),
                ),
                Divider(
                  height: 1,
                  color: Colors.grey.shade300,
                  indent: 16,
                  endIndent: 16,
                ),
                ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('邮箱'), Text(_model?.email ?? '未设置')],
                  ),
                ),
                Divider(
                  height: 1,
                  color: Colors.grey.shade300,
                  indent: 16,
                  endIndent: 16,
                ),
                ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('TOPDON ID'),
                      Text(_model?.topdonId ?? '未设置'),
                    ],
                  ),
                ),
                Divider(
                  height: 1,
                  color: Colors.grey.shade300,
                  indent: 16,
                  endIndent: 16,
                ),
                ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('修改登录密码')],
                  ),
                  trailing: Icon(Icons.arrow_forward_ios, size: 18),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const RegisterPage(
                          pageType: PageType.updatePassword,
                        ),
                      ),
                    );
                  },
                ),
                Divider(
                  height: 1,
                  color: Colors.grey.shade300,
                  indent: 16,
                  endIndent: 16,
                ),
                ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [Text('反馈')],
                  ),
                  trailing: Icon(Icons.arrow_forward_ios, size: 18),
                  onTap: () => _feedback(context),
                ),
                Divider(
                  height: 1,
                  color: Colors.grey.shade300,
                  indent: 16,
                  endIndent: 16,
                ),
                SizedBox(height: 20),
                GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  child: ListTile(
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('退出登录', style: TextStyle(color: Colors.red, fontSize: 18, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  onTap: () => _logout(context),
                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
