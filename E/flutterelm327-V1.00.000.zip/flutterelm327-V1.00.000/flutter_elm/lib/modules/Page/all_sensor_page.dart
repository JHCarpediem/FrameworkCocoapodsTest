import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:flutter_elm/modules/Model/instrument_model.dart';
import 'package:flutter_elm/modules/Page/pick_item_page.dart';

class AllSensorPage extends StatefulWidget {
  const AllSensorPage({super.key});

  @override
  State<AllSensorPage> createState() => _AllSensorPageState();
}

class _AllSensorPageState extends State<AllSensorPage> {
  final ScrollController _scrollController = ScrollController();
  var sender = Sender();
  var allData = InstrumentModel.genarateData();

  Set<int> visibleIndexes = {}; // 当前可见item索引
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    // 页面加载后主动触发一次，获取第一页数据
    WidgetsBinding.instance.addPostFrameCallback((_) {
      print("-----第一次加载");
      _onScroll();
    });

    // 定时刷新可见区数据
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      _refreshVisibleItems();
    });
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  void _onScroll() async {
    double offset = _scrollController.offset;
    double itemExtent = 70.0; // ListTile高度
    int firstIndex = (offset / itemExtent).floor();
    int visibleCount = (MediaQuery.of(context).size.height / itemExtent).ceil();
    int lastIndex = (firstIndex + visibleCount).clamp(0, allData.length);

    // print(
    //   '------当前可见区: $firstIndex ~ $lastIndex, 偏移量: $offset, visibleCount: $visibleCount',
    // );
    // 更新可见item索引集合
    Set<int> newVisible = {};
    for (int i = firstIndex; i < lastIndex; i++) {
      newVisible.add(i);
    }
    // 计算滑入和滑出的索引
    Set<int> entered = newVisible.difference(visibleIndexes); // 新进入的
    Set<int> exited = visibleIndexes.difference(newVisible); // 滑出的

    // 加入新进入的
    visibleIndexes.addAll(entered);
    // 移除滑出的
    visibleIndexes.removeAll(exited);

    print('滑入: $entered, 滑出: $exited, 当前可见: $visibleIndexes');
  }

  void _refreshVisibleItems() async {
    for (var index in visibleIndexes) {
      var model = allData[index];
      if (model.fetchCommand != null && model.selected) {
        var result = await model.fetchCommand!();
        setState(() {
          model.value = result is double
              ? result
              : double.tryParse(result.toString()) ?? 0.0;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // 只显示选中的数据
    final visibleData = allData.where((e) => e.selected).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('所有传感器数据'),
        actions: [
          IconButton(
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PickItemPage(items: allData),
                ),
              );
              if (result != null && result is List<InstrumentModel>) {
                // 用 result 覆盖 allData 的顺序和 selected 状态
                for (int i = 0; i < result.length; i++) {
                  allData[i]
                    ..selected = result[i].selected
                    ..name = result[i].name
                    ..value = result[i].value
                    ..unit = result[i].unit
                    ..minimum = result[i].minimum
                    ..maximum = result[i].maximum
                    ..interval = result[i].interval
                    ..fetchCommand = result[i].fetchCommand;
                }
                // 如果顺序也要同步，可以直接 allData = result;
                allData = List<InstrumentModel>.from(result);
                setState(() {});
              }
            },
            icon: Icon(Icons.filter_alt, size: 30),
          ),
        ],
      ),
      body: NotificationListener(
        child: ListView.separated(
          controller: _scrollController,
          itemBuilder: (context, index) {
            return _buildCell(visibleData[index]);
          },
          separatorBuilder: (context, index) {
            return const Divider(height: 1, thickness: 1, color: Colors.grey);
          },
          itemCount: visibleData.length, // 固定高度，优化性能
        ),
      ),
    );
  }

  Widget _buildCell(InstrumentModel model) {
    // 计算当前值是否在范围内
    bool isInRange =
        model.value >= model.minimum && model.value <= model.maximum;

    String formatted = model.value.toStringAsFixed(2); // 保留两位小数
    if (formatted.endsWith('.00')) {
      formatted = formatted.substring(0, formatted.length - 3); // 去掉 ".00"
    }
    return SizedBox(
      height: 70,
      child: Row(
        children: [
          // 左侧文本
          Expanded(
            flex: 3,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    model.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  Row(
                    children: [
                      // Icon(Icons.swap_horiz, color: Colors.grey, size: 15,),
                      Text(
                        "(${model.minimum} ~ ${model.maximum} ${model.unit})",
                        style: TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // 右侧数值和单位
          Expanded(
            flex: 1,
            child: Padding(
              padding: EdgeInsetsGeometry.only(right: 16),
              child: Text(
                '$formatted ${model.unit}',
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: isInRange ? Colors.black : Colors.red,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
