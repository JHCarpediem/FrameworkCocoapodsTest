import 'package:flutter/material.dart';
import 'package:flutter_elm/command/elm_237.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:url_launcher/url_launcher.dart';

class DtcPage extends StatefulWidget {
  const DtcPage({super.key});

  @override
  State<StatefulWidget> createState() => _DtcPageState();
}

class _DtcPageState extends State<DtcPage> {
  var sender = Sender();
  var dtcCodes = <List<OBDIIDTC>>[];

  @override
  void initState() {
    super.initState();
    // 不要在initState中调用需要context的方法
    // 改为在下一帧渲染后调用
    WidgetsBinding.instance.addPostFrameCallback((_) {
      queryDtc();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('故障码'),
        actions: [
          IconButton(
            onPressed: () {
              clearDTC();
            },
            icon: Icon(Icons.delete),
          ),
        ],
      ),
      body: dtcCodes.isEmpty
          ? const Center(child: Text('暂无故障码'))
          : ListView.builder(
              itemCount: dtcCodes.length,
              itemBuilder: (context, index) {
                return _buildCell(dtcCodes[index]);
              },
            ),
    );
  }

  Widget _buildCell(List<OBDIIDTC> dtcs) {
    if (dtcs.isEmpty) {
      return const Center(child: Text(''));
    }
    var title = dtcs
        .map((dtc) => dtc.code)
        .where((code) => code.isNotEmpty)
        .join(', ');
    var category = dtcs.first.category;
    var troubleCode = dtcs.first.troubleCode;
    return Container(
      padding: EdgeInsets.all(15),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.grey.shade300, width: 0.5),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text(
                  category.toString(),
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () {
              openBaiduSearch(title);
            },
            icon: Icon(Icons.search),
          ),
          if (troubleCode.isNotEmpty && troubleCode.toLowerCase() != 'nodata')
            IconButton(
              icon: Icon(Icons.star),
              onPressed: () {
                print("点击当前码");
              },
            ),
        ],
      ),
    );
  }

  void queryDtc() async {
    TDLoadingView.show(context);
    // 发送查询 DTC 命令
    var dtcs1 = await sender.sendCurrentDTC();
    var dtcs2 = await sender.sendPendingDTC();
    var dtcs3 = await sender.sendPermanentDTC();
    // 合并三个数组
    dtcCodes = [dtcs1, dtcs2, dtcs3];
    if (dtcs1.isNotEmpty) {
      var freezeFrame = await sender.sendFreezeFrameWithDTC();
      dtcs1.first.troubleCode = freezeFrame;
    }
    if (dtcs1.isEmpty && dtcs2.isEmpty && dtcs3.isEmpty) {
      ToastAlert.show("没有查询到故障码");
      dtcCodes = [];
    }
    print("查询到的 DTC 码dtc1: $dtcs1 , dtcs2: $dtcs2, dtcs3: $dtcs3");
    setState(() {});

    TDLoadingView.hide(context);
  }

  void clearDTC() async {
    if (dtcCodes.isEmpty) {
      ToastAlert.show("当前没有故障码，无需清除");
      return;
    }
    TDLoadingView.show(context);
    // 发送清除 DTC 命令
    var value = await sender.sendClearDTC();
    if (value.contains('44')) {
      ToastAlert.show("清除故障码成功");
      dtcCodes = <List<OBDIIDTC>>[];
    } else {
      ToastAlert.show("清除故障码失败");
    }
    setState(() {});
    TDLoadingView.hide(context);
  }

  // Future<void> _launchInBrowser(Uri url) async {
  //   if (!await launchUrl(
  //     url,
  //     mode: LaunchMode.externalApplication,
  //   )) {
  //     throw Exception('Could not launch $url');
  //   }
  // }

  /// 打开百度搜索
  void openBaiduSearch(String keyword) async {
    // 1. 拼接 URL，keyword 是用户输入的要搜索的关键字
    String googleUrl = "https://www.google.com/search?q=OBD2 $keyword";
    // 2. 对 URL 进行编码（Dart 的 Uri 类会自动处理编码）
    Uri googleUri = Uri.parse(googleUrl);

    if (!await launchUrl(googleUri, mode: LaunchMode.externalApplication)) {
      debugPrint('打开谷歌链接异常: $googleUri');
      ToastAlert.show("打开谷歌链接失败，请检查网络");
      throw Exception('Could not launch $googleUri');
    }
  }
}
