import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_elm/modules/Model/instrument_model.dart';
import 'package:flutter_elm/modules/Page/live_date_pick_page.dart';
import '../../../main.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class LiveDatePage extends StatefulWidget {
  const LiveDatePage({super.key});

  @override
  State<StatefulWidget> createState() => _LiveDataPageState();
}

class _LiveDataPageState extends State<LiveDatePage> with RouteAware {
  late List<LiveData> chartData = [];
  List<ChartSeriesController> _controllers = [];
  late Timer timer;
  late DateTime _currentTime;
  List<InstrumentModel> selectedItems = [];
  var items = InstrumentModel.genarateStreamData(isAllSelected: false);

  @override
  void initState() {
    super.initState();
    // 初始化数据
    chartData = getChartData();
    _currentTime = DateTime.now();
    _controllers = [];
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    routeObserver.subscribe(this, ModalRoute.of(context)! as PageRoute);
  }

  @override
  void didPush() {
    super.didPush();
    startTimer(); // 页面进入时启动计时器
  }

  @override
  void didPop() {
    super.didPop();
    timer.cancel(); // 页面离开时停止计时器
  }

  @override
  didPushNext() {
    super.didPushNext();
    timer.cancel();
  }

  @override
  void didPopNext() {
    super.didPopNext();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('实时数据'),
        actions: [
          IconButton(
            icon: Icon(Icons.filter_alt, size: 30),
            onPressed: () async {
              var result = await Navigator.push<List<InstrumentModel>>(
                context,
                MaterialPageRoute(
                  builder: (context) => LiveDatePickPage(items: items),
                ),
              );

              final selectedResults = result
                  ?.where((item) => item.selected)
                  .toList();
              if (selectedResults != null) {
                setState(() {
                  // 更新原始items列表以保持选择状态同步
                  items = List<InstrumentModel>.from(result!);
                  // 从更新后的items中筛选选中项
                  selectedItems = items.where((item) => item.selected).toList();
                  _controllers.clear();
                });
              }
            },
          ),
        ],
      ),
      body: _newView(),
    );
  }

  Widget _newView() {
    if (selectedItems.isEmpty) {
      return const Center(child: Text('请选择要显示的传感器数据'));
    }

    return Column(
      children: List.generate(selectedItems.length, (index) {
        final item = selectedItems[index];
        // 根据选择数量动态调整图表高度
        final Widget chart = SfCartesianChart(
          legend: const Legend(isVisible: true),
          primaryXAxis: DateTimeAxis(
            title: const AxisTitle(text: '时间'),
            autoScrollingDelta: 10,
            autoScrollingMode: AutoScrollingMode.end,
          ),
          primaryYAxis: NumericAxis(
            title: AxisTitle(text: '${item.name} ${item.unit}'),
            minimum: item.minimum,
            maximum: item.maximum,
            interval: item.interval,
          ),
          series: <CartesianSeries<LiveData, DateTime>>[
            LineSeries<LiveData, DateTime>(
              onRendererCreated: (ChartSeriesController controller) {
                if (_controllers.length > index) {
                  _controllers[index] = controller;
                } else {
                  _controllers.add(controller);
                }
              },
              name: item.name,
              dataSource: chartData,
              xValueMapper: (LiveData d, _) => d.x,
              yValueMapper: (LiveData d, _) => [d.y1, d.y2, d.y3, d.y4][index],
              color: _getColor(index),
            ),
          ],
        );

        return selectedItems.length == 1
            ? SizedBox(
                height: MediaQuery.of(context).size.height / 2,
                child: chart,
              )
            : Expanded(child: chart);
      }),
    );
  }

  Color _getColor(int index) {
    const colors = [Colors.blue, Colors.red, Colors.green, Colors.orange];
    return colors[index % colors.length];
  }

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    timer.cancel();
    super.dispose();
  }

  startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), updateData);
  }

  // 更新数据
  Future<void> updateData(Timer timer) async {
    // 按顺序获取所有选中传感器的数据，避免蓝牙通信冲突
    final List<dynamic> values = [];
    for (var item in selectedItems) {
      try {
        if (item.fetchCommand != null) {
          final value = await item.fetchCommand!();
          values.add(value);
        } else {
          values.add(0);
        }
      } catch (e) {
        print('------获取传感器数据错误: $e');
        values.add(0);
      }
      // 短暂延迟确保蓝牙通信完成
      await Future.delayed(Duration(milliseconds: 100));
    }
    print('------values:$values');
    // 创建包含所有传感器当前值的单个数据点
    var y1 = 0.0;
    if (values.isNotEmpty) {
      if (values[0] is (double, double)) {
        var value = values[0] as (double, double);
        y1 = value.$1;
      } else {
        y1 = values[0].toDouble();
      }
    }

    var y2 = 0.0;
    if (values.length > 1) {
      if (values[1] is (double, double)) {
        var value = values[1] as (double, double);
        y2 = value.$1;
      } else {
        y2 = values[1].toDouble();
      }
    }
    
    var y3 = 0.0;
    if (values.length > 2) {
      if (values[2] is (double, double)) {
        var value = values[2] as (double, double);
        y3 = value.$1;
      } else {
        y3 = values[2].toDouble();
      }
    }
    
    var y4 = 0.0;
    if (values.length > 3) {
      if (values[3] is (double, double)) {
        var value = values[3] as (double, double);
        y4 = value.$1;
      } else {
        y4 = values[3].toDouble();
      }
    }

    final newData = LiveData(
      _currentTime,
      y1,
      y2,
      y3: y3,
      y4: y4,
    );
    _currentTime = _currentTime.add(Duration(seconds: 1));

    // 添加新数据点
    chartData.add(newData);

    // 保持固定数量的历史数据点
    if (chartData.length > 100) {
      chartData.removeAt(0);
    }

    // 更新所有图表
    for (var i = 0; i < _controllers.length; i++) {
      _controllers[i].updateDataSource(
        addedDataIndex: chartData.length - 1,
        removedDataIndex: chartData.length > 100 ? 0 : -1,
      );
    }

    // 触发UI刷新
    setState(() {});
  }

  // 获取初始数据
  List<LiveData> getChartData() {
    final List<LiveData> data = [];
    final now = DateTime.now();
    // 创建过去10秒的数据
    for (int i = 10; i >= 0; i--) {
      data.add(LiveData(now.add(Duration(seconds: -i)), 0.0, 0.0));
    }
    return data;
  }
}

// 数据模型
class LiveData {
  final DateTime x;
  final double y1;
  final double y2;
  final double y3;
  final double y4;

  LiveData(this.x, this.y1, this.y2, {this.y3 = 0, this.y4 = 0});
}
