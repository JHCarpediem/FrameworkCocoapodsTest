import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_elm/tools/string_extension.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/manager/database_manager.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:flutter_elm/network/network_api.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:flutter_elm/tools/configration.dart';
import 'package:flutter_elm/modules/View/td_loading_view';

// 页面类型枚举
enum PageType {
  register, // 注册
  forgotPassword, // 忘记密码
  updatePassword, // 修改登录密码
}

class RegisterPage extends StatefulWidget {
  final PageType pageType;

  const RegisterPage({super.key, this.pageType = PageType.register});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _verificationCodeController =
      TextEditingController();

  // 添加焦点节点
  final FocusNode _emailFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  final FocusNode _confirmPasswordFocusNode = FocusNode();
  final FocusNode _verificationCodeFocusNode = FocusNode();
  bool _isEmailValid = false;
  bool _isPasswordValid = true; // 密码校验状态
  bool _isConfirmPasswordValid = true; // 确认密码校验状态
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  bool _isCodeButtonEnabled = true;
  bool _isVerificationCodeValid = true; // 验证码验证状态
  int _countdown = 60;
  UserModel? _model;
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    DatabaseManager().fetchUser().then((value) {
      setState(() {
        _model = value;
        // 当页面类型为忘记密码且有邮箱信息时，自动填充邮箱输入框
        if (widget.pageType == PageType.updatePassword && _model?.email != null) {
          _emailController.text = _model?.email ?? '';
          _isEmailValid = true;
        }
      });
    });

    _emailController.addListener(() {
      setState(() {
        _isEmailValid = _emailController.text.isValidateEmail;
      });
    });

    // 添加密码输入监听器
    _passwordController.addListener(() {
      setState(() {
        // 校验密码是否符合规则
        _isPasswordValid =
            _passwordController.text.isValidCasePassword &&
            _passwordController.text.isValidLengthPassword;
        // 校验确认密码是否与密码一致
        _isConfirmPasswordValid =
            _passwordController.text == _confirmPasswordController.text;
      });
    });

    // 添加确认密码输入监听器
    _confirmPasswordController.addListener(() {
      setState(() {
        // 校验确认密码是否与密码一致
        _isConfirmPasswordValid =
            _passwordController.text == _confirmPasswordController.text;
      });
    });
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _verificationCodeController.dispose();
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    _confirmPasswordFocusNode.dispose();
    _verificationCodeFocusNode.dispose();
    _timer?.cancel();
    super.dispose();
  }

  // 统一焦点管理方法
  void _manageFocus() {
    _emailFocusNode.unfocus();
    _passwordFocusNode.unfocus();
    _confirmPasswordFocusNode.unfocus();
    _verificationCodeFocusNode.unfocus();
    FocusScope.of(context).unfocus();
    // 直接调用系统方法隐藏键盘
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  // 获取验证码
  void _getVerificationCode() {
    setState(() {
      _isCodeButtonEnabled = false;
      _countdown = 60;
    });

    _sendCaptchaRequest();

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_countdown > 0) {
          _countdown--;
        } else {
          _isCodeButtonEnabled = true;
          _timer?.cancel();
        }
      });
    });
  }

  // 忘记密码请求
  _forgotPasswordRequest() async {
    Map<String, dynamic> param = {
      'contactWay': _emailController.text,
      'password': _passwordController.text,
      'captcha': _verificationCodeController.text,
      'operationType': "1",
      'type': "0",
    };

    TDLoadingView.show(context);
    NetworkModel networkModel = await BatteryInfoApi.registerOrForgetPassword(
      param,
    );

    // 添加mounted检查以避免'BuildContext's across async gaps'警告
    if (!mounted) return;
    TDLoadingView.hide(context);

    if (networkModel.code == 2000) {
      ToastAlert.show('密码重置成功', duration: 3000);
    } else {
      ToastAlert.show(networkModel.msg ?? '密码重置失败，请检查网络连接', duration: 3000);
    }
  }

  // 修改登录密码请求
  _updatePasswordRequest() async {
    Map<String, dynamic> param = {
      'contactWay': _emailController.text,
      'password': _passwordController.text,
      'captchaFromSystem': _verificationCodeController.text,
      'operationType': "2",
      'type': "0",
    };

    TDLoadingView.show(context);
    NetworkModel networkModel = await BatteryInfoApi.updatePassword(
      param,
    );

    // 添加mounted检查以避免'BuildContext's across async gaps'警告
    if (!mounted) return;
    TDLoadingView.hide(context);

    if (networkModel.code == 2000) {
      ToastAlert.show('密码修改成功', duration: 3000);
    } else {
      ToastAlert.show(networkModel.msg ?? '密码修改失败，请检查网络连接', duration: 3000);
    }
  }

  // 注册请求
  _registerRequest() async {
    Map<String, dynamic> param = {
      'contactWay': _emailController.text,
      'password': _passwordController.text,
      'captcha': _verificationCodeController.text,
      'operationType': "0",
      'type': "0",
    };
    TDLoadingView.show(context);
    NetworkModel networkModel = await BatteryInfoApi.registerOrForgetPassword(
      param,
    );

    if (networkModel.code == 2000) {
      // 注册成功后，自动登录
      Map<String, dynamic> param = {
        'type': 0,
        'validateBindPhone': false,
        'userAccount': _emailController.text,
        'password': _passwordController.text,
      };
      NetworkModel networkModel = await BatteryInfoApi.login(param);

      if (networkModel.code == 2000) {
        if (networkModel.data != null) {
          _model = networkModel.data as UserModel;

          var prefs = await SharedPreferences.getInstance();
          prefs.setString(TDConfig.token, _model?.token ?? '');
          await DatabaseManager().saveUser(_model!);
          ToastAlert.show('登录成功', duration: 3000);
          if (!mounted) return;
          TDLoadingView.hide(context);
          Navigator.of(context).popUntil(ModalRoute.withName('/setting'));
        } else {
          ToastAlert.show("登录失败，服务器返回数据异常", duration: 3000);
        }
      } else {
        if (!mounted) return;
        TDLoadingView.hide(context);
        ToastAlert.show(networkModel.msg ?? '注册失败，请检查网络连接', duration: 3000);
      }
    } else {
      if (!mounted) return;
      TDLoadingView.hide(context);
      ToastAlert.show(networkModel.msg ?? '注册失败，请检查网络连接', duration: 3000);
    }
  }

  // 发送验证码请求
  _sendCaptchaRequest() async {
    var operationType = "1";
    if (widget.pageType == PageType.register) {
      operationType = "1";
    } else if (widget.pageType == PageType.forgotPassword) {
      operationType = "4";
    } else if (widget.pageType == PageType.updatePassword) {
      operationType = "2";
    }
    Map<String, dynamic> param = {
      'contactWay': _emailController.text,
      'operationType': operationType,
      'type': "0",
    };

    NetworkModel networkModel = await BatteryInfoApi.sendCaptch(param);

    if (networkModel.code == 2000) {
      ToastAlert.show('验证码发送成功', duration: 3000);
    } else {
      ToastAlert.show(networkModel.msg ?? '验证码发送失败，请检查网络连接', duration: 3000);
    }
  }

  @override
  Widget build(BuildContext context) {
    var title = '注册';
    var pageTitle = '欢迎注册TOPDON账号';
    if (widget.pageType == PageType.register) {
      title = '注册';
      pageTitle = '欢迎注册TOPDON账号';
    } else if (widget.pageType == PageType.forgotPassword) {
      title = '忘记密码';
      pageTitle = '重置密码';
    } else if (widget.pageType == PageType.updatePassword) {
      title = '修改密码';
      pageTitle = '修改密码';
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () => _manageFocus(),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 30),
              Text(
                pageTitle,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                widget.pageType == PageType.register
                    ? 'TOPDON账号适用于TOPDON旗下的所有APP'
                    : '请输入您的邮箱账号，系统将发送验证码到您的邮箱',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey, fontSize: 14),
              ),
              const SizedBox(height: 50),
              // Email Input
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade300, width: 1),
                ),
                child: TextField(
                  controller: _emailController,
                  focusNode: _emailFocusNode,
                  cursorColor: Colors.blue,
                  inputFormatters: [
                    FilteringTextInputFormatter.deny(RegExp(r'\s')),
                  ], // 禁止输入空格
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.email, color: Colors.blue),
                    suffixIcon: _emailController.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, color: Colors.grey),
                            onPressed: () {
                              _emailController.clear();
                              setState(() {
                                _isEmailValid = false;
                              });
                            },
                          )
                        : null,
                    hintText: '请输入邮箱',
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(15),
                  ),
                ),
              ),
              // Email validation error message
              if (!_isEmailValid && _emailController.text.isNotEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 5, left: 10, bottom: 5),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '请输入正确的邮箱账号',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              SizedBox(height: 20),
              // Password Input
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade300, width: 1),
                ),
                child: TextField(
                  controller: _passwordController,
                  focusNode: _passwordFocusNode,
                  cursorColor: Colors.blue,
                  obscureText: !_isPasswordVisible,
                  inputFormatters: [
                    FilteringTextInputFormatter.deny(RegExp(r'\s')),
                  ],
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.lock, color: Colors.blue),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          _isPasswordVisible = !_isPasswordVisible;
                        });
                      },
                    ),
                    hintText: widget.pageType == PageType.register
                        ? '请输入登录密码'
                        : '请输入新密码',
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(15),
                  ),
                ),
              ),
              // Password validation error message
              if (!_isPasswordValid && _passwordController.text.isNotEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 5, left: 10, bottom: 5),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '密码必须包含至少两种字符类型（大小写字母、数字、特殊字符）且长度为8-30位',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              // Confirm Password Input
              const SizedBox(height: 20),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade300, width: 1),
                ),
                child: TextField(
                  controller: _confirmPasswordController,
                  focusNode: _confirmPasswordFocusNode,
                  cursorColor: Colors.blue,
                  obscureText: !_isConfirmPasswordVisible,
                  inputFormatters: [
                    FilteringTextInputFormatter.deny(RegExp(r'\s')),
                  ],
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.lock, color: Colors.blue),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _isConfirmPasswordVisible
                            ? Icons.visibility
                            : Icons.visibility_off,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          _isConfirmPasswordVisible =
                              !_isConfirmPasswordVisible;
                        });
                      },
                    ),
                    hintText: '请再次输入密码',
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.all(15),
                  ),
                ),
              ),
              // Confirm Password validation error message
              if (!_isConfirmPasswordValid &&
                  _confirmPasswordController.text.isNotEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 5, left: 10, bottom: 5),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '两次输入的密码不一致',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              const SizedBox(height: 20),
              // Verification Code Input
              Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.grey.shade300,
                          width: 1,
                        ),
                      ),
                      child: TextField(
                        controller: _verificationCodeController,
                        focusNode: _verificationCodeFocusNode,
                        cursorColor: Colors.blue,
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.deny(RegExp(r'\s')),
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        decoration: InputDecoration(
                          prefixIcon: const Icon(
                            Icons.security,
                            color: Colors.blue,
                          ),
                          hintText: '请输入验证码',
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.all(15),
                        ),
                        onChanged: (value) {
                          // 实时验证验证码格式
                          if (value.isEmpty) {
                            setState(() {
                              _isVerificationCodeValid = true; // 不显示错误提示
                            });
                          } else if (RegExp(r'^\d{4}$').hasMatch(value)) {
                            setState(() {
                              _isVerificationCodeValid = true;
                            });
                          } else {
                            setState(() {
                              _isVerificationCodeValid = false;
                            });
                          }
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isCodeButtonEnabled
                          ? () {
                              if (_isEmailValid) {
                                _getVerificationCode();
                              } else {
                                ToastAlert.show('请输入正确的邮箱账号', duration: 3000);
                              }
                            }
                          : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _isCodeButtonEnabled
                            ? Colors.blue
                            : Colors.grey,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        splashFactory: NoSplash.splashFactory,
                      ),
                      child: Text(
                        _isCodeButtonEnabled ? '获取验证码' : '$_countdown秒后重试',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              // Verification code validation error message
              if (!_isVerificationCodeValid &&
                  _verificationCodeController.text.isNotEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 5, left: 10, bottom: 5),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '验证码错误',
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ),
                ),
              const SizedBox(height: 50),
              // Register Button
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed:
                      (_isEmailValid &&
                          _emailController.text.isNotEmpty &&
                          _passwordController.text.isNotEmpty &&
                          _isPasswordValid &&
                          _confirmPasswordController.text.isNotEmpty &&
                          _isConfirmPasswordValid &&
                          _verificationCodeController.text.isNotEmpty &&
                          _isVerificationCodeValid)
                      ? () {
                          _manageFocus();
                          if (widget.pageType == PageType.register) {
                            _registerRequest();
                          } else if (widget.pageType == PageType.forgotPassword) {
                            _forgotPasswordRequest();
                          } else if (widget.pageType == PageType.updatePassword) {
                            _updatePasswordRequest();
                          }
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        (_isEmailValid &&
                            _emailController.text.isNotEmpty &&
                            _passwordController.text.isNotEmpty &&
                            _isPasswordValid &&
                            _confirmPasswordController.text.isNotEmpty &&
                            _isConfirmPasswordValid &&
                            _verificationCodeController.text.isNotEmpty &&
                            _isVerificationCodeValid)
                        ? Colors.blue
                        : Colors.blue.withValues(alpha: 0.5),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    splashFactory: NoSplash.splashFactory,
                    disabledBackgroundColor: Colors.blue.withValues(alpha: 0.5),
                  ),
                  child: Text(
                    widget.pageType == PageType.register ? '注册' : '确定',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 34),
            ],
          ),
        ),
      ),
    );
  }
}
