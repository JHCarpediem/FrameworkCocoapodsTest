import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:flutter_elm/modules/Model/instrument_model.dart';
import 'package:flutter_elm/modules/Page/pick_item_page.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class InstrumentDashboardPage extends StatefulWidget {
  const InstrumentDashboardPage({super.key});

  @override
  State<InstrumentDashboardPage> createState() =>
      _InstrumentDashboardPageState();
}

class _InstrumentDashboardPageState extends State<InstrumentDashboardPage> {
  var sender = Sender();
  var allData = InstrumentModel.genarateData();

  // 在 StatefulWidget 的成员变量中添加：
  final ScrollController _indicatorScrollController = ScrollController();
  // 每页显示的仪表数量
  final int _itemsPerPage = 3; // 每“页”显示 3 个仪表盘

  // 定时刷新定时器
  Timer? _refreshTimer;

  // 当前页面索引（用于指示器）
  int _currentPageIndex = 0;
// 小圆点 + margin 的实际宽度
  final double _indicatorVisibleWidth = 200.0; // 指示器容器宽度，可调整

  @override
  void initState() {
    super.initState();

    // 页面加载后开始刷新
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _refreshCurrentPageData();
    });

    // 定时刷新（每秒一次）
    _refreshTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _refreshCurrentPageData();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  void _onPageChanged(int page) {
    if (page != _currentPageIndex) {
      setState(() {
        _currentPageIndex = page;
      });
      _refreshCurrentPageData();

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_indicatorScrollController.hasClients) {
          final itemWidth = 16.0; // 圆点8 + 左右margin各4 = 16
          final targetOffset =
              itemWidth * page.toDouble() -
              (_indicatorVisibleWidth / 2) +
              (itemWidth / 2);

          final maxScrollOffset =
              _indicatorScrollController.position.maxScrollExtent;
          final safeOffset = targetOffset.clamp(0.0, maxScrollOffset);

          _indicatorScrollController.animateTo(
            safeOffset,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    }
  }

  void _refreshCurrentPageData() async {
    // 只请求需要显示的数据
    var visibleData = allData.where((e) => e.selected).toList();
    int startIndex = _currentPageIndex * _itemsPerPage;
    int endIndex = (startIndex + _itemsPerPage).clamp(0, visibleData.length);
    print("------刷新当前页面数据 startindex:$startIndex endIndex:$endIndex");
    for (int i = startIndex; i < endIndex; i++) {
      if (i < visibleData.length) {
        var instrument = visibleData[i];
        if (instrument.fetchCommand != null) {
          try {
            var result = await instrument.fetchCommand!();
            if (mounted) {
              setState(() {
                instrument.value = result is double
                    ? result
                    : double.tryParse(result.toString()) ?? 0.0;
              });
            }
          } catch (e) {
            // 错误处理，保持原值
            if (mounted) {
              setState(() {});
            }
          }
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // 只显示勾选的数据
    var visibleData = allData.where((e) => e.selected).toList();
    // 总页数 = 总数据条目数 / 每页条目数，向上取整
    int pageCount = (visibleData.length / _itemsPerPage).ceil();

    return Scaffold(
      appBar: AppBar(
        title: const Text('仪表盘'),
        actions: [
          IconButton(
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PickItemPage(items: allData),
                ),
              );
              if (result != null && result is List<InstrumentModel>) {
                // 用 result 覆盖 allData 的顺序和 selected 状态
                for (int i = 0; i < result.length; i++) {
                  allData[i]
                    ..selected = result[i].selected
                    ..name = result[i].name
                    ..value = result[i].value
                    ..unit = result[i].unit
                    ..minimum = result[i].minimum
                    ..maximum = result[i].maximum
                    ..interval = result[i].interval
                    ..fetchCommand = result[i].fetchCommand;
                }
                // 如果顺序也要同步，可以直接 allData = result;
                allData = List<InstrumentModel>.from(result);
                setState(() {});
              }
            },
            icon: Icon(Icons.filter_alt, size: 30),
          ),
        ],
      ),
      body: Column(
        children: [
          // 横向滑动的页面容器（每页包含多个仪表盘）
          Expanded(
            child: PageView.builder(
              controller: PageController(),
              onPageChanged: _onPageChanged,
              itemCount: pageCount,
              itemBuilder: (context, pageIndex) {
                return _buildInstrumentPage(pageIndex);
              },
            ),
          ),

          // 页面指示器（小圆点）
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SizedBox(
                width: _indicatorVisibleWidth,
                height: 30,
                child: ListView.builder(
                  controller: _indicatorScrollController,
                  scrollDirection: Axis.horizontal,
                  physics: const NeverScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: pageCount,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        // 可选：点击跳转页面
                        // _pageController.animateToPage(index, ...);
                      },
                      child: Container(
                        width: 8,
                        height: 8,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: index == _currentPageIndex
                              ? Colors.blue
                              : Colors.grey,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),

          SizedBox(height: 10),
        ],
      ),
    );
  }

  Widget _buildInstrumentPage(int pageIndex) {
    // 只显示勾选的数据
    var visibleData = allData.where((e) => e.selected).toList();
    // 计算当前页显示哪些仪表盘
    int startIndex = pageIndex * _itemsPerPage;
    int endIndex = (startIndex + _itemsPerPage).clamp(0, visibleData.length);

    List<InstrumentModel> pageInstruments = visibleData.sublist(
      startIndex,
      endIndex,
    );

    return Container(
      color: Colors.grey[50],
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // 第一行：第一个仪表（大）
            if (pageInstruments.isNotEmpty)
              Expanded(flex: 2, child: _buildLargeGauge(pageInstruments[0])),
            if (pageInstruments.isNotEmpty) const SizedBox(height: 16),

            // 第二行：第2~3个仪表（小）
            if (pageInstruments.length > 1)
              Expanded(
                flex: 1,
                child: Row(
                  children: [
                    // 第二个仪表
                    Expanded(child: _buildSmallGauge(pageInstruments[1])),
                    const SizedBox(width: 16),
                    // 第三个仪表（如果有）
                    if (pageInstruments.length > 2)
                      Expanded(child: _buildSmallGauge(pageInstruments[2]))
                    else
                      const SizedBox(width: 16),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  // 大仪表盘（第一个）
  Widget _buildLargeGauge(InstrumentModel instrument) {
    return SfRadialGauge(
      axes: <RadialAxis>[
        RadialAxis(
          minimum: instrument.minimum,
          maximum: instrument.maximum,
          interval: (instrument.maximum - instrument.minimum) / 10,
          minorTicksPerInterval: 4,
          radiusFactor: 0.9,
          axisLineStyle: AxisLineStyle(
            thickness: 0.1,
            color: Colors.blue[200]!,
            thicknessUnit: GaugeSizeUnit.factor,
          ),
          majorTickStyle: MajorTickStyle(
            length: 5,
            thickness: 2,
            color: Colors.blue[200]!,
          ),
          minorTickStyle: MinorTickStyle(
            length: 3,
            thickness: 1,
            color: Colors.blue[200]!,
          ),
          axisLabelStyle: GaugeTextStyle(color: Colors.black, fontSize: 14),
          labelOffset: 25,
          showFirstLabel: true,
          showLastLabel: true,
          pointers: <GaugePointer>[
            NeedlePointer(
              value: instrument.value,
              enableAnimation: true,
              animationDuration: 1000,
              needleLength: 0.7,
              needleStartWidth: 1,
              needleEndWidth: 3,
              knobStyle: KnobStyle(
                knobRadius: 0.08,
                color: Colors.blue,
                borderWidth: 0.02,
                borderColor: Colors.white,
              ),
            ),
          ],
          annotations: <GaugeAnnotation>[
            GaugeAnnotation(
              widget: Text(
                "${instrument.value.toStringAsFixed(1)} \n ${instrument.name} \n ${instrument.unit}",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              angle: 90,
              positionFactor: 0.9,
            ),
          ],
        ),
      ],
    );
  }

  // 小仪表盘（第2~3个）
  Widget _buildSmallGauge(InstrumentModel instrument) {
    return SfRadialGauge(
      axes: <RadialAxis>[
        RadialAxis(
          minimum: instrument.minimum,
          maximum: instrument.maximum,
          interval: (instrument.maximum - instrument.minimum) / 10,
          minorTicksPerInterval: 1,
          radiusFactor: 0.9,
          axisLineStyle: AxisLineStyle(
            thickness: 0.1,
            color: Colors.blue[200]!,
            thicknessUnit: GaugeSizeUnit.factor,
          ),
          majorTickStyle: MajorTickStyle(
            length: 5,
            thickness: 2,
            color: Colors.blue[200]!,
          ),
          minorTickStyle: MinorTickStyle(
            length: 3,
            thickness: 1,
            color: Colors.blue[200]!,
          ),
          axisLabelStyle: GaugeTextStyle(color: Colors.black, fontSize: 10),
          labelOffset: 15,
          showFirstLabel: true,
          showLastLabel: true,
          pointers: <GaugePointer>[
            NeedlePointer(
              value: instrument.value,
              enableAnimation: true,
              animationDuration: 1000,
              needleLength: 0.7,
              needleStartWidth: 1,
              needleEndWidth: 3,
              knobStyle: KnobStyle(
                knobRadius: 0.08,
                color: Colors.blue,
                borderWidth: 0.02,
                borderColor: Colors.white,
              ),
            ),
          ],
          annotations: <GaugeAnnotation>[
            GaugeAnnotation(
              widget: Text(
                "${instrument.value.toStringAsFixed(1)} \n ${instrument.name} \n ${instrument.unit}",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue,
                ),
              ),
              angle: 90,
              positionFactor: 1.1,
            ),
          ],
        ),
      ],
    );
  }
}
