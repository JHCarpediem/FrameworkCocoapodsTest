import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class AccelerationTestPage extends StatefulWidget {
  const AccelerationTestPage({super.key});

  @override
  State<AccelerationTestPage> createState() => _AccelerationTestPageState();
}

class _AccelerationTestPageState extends State<AccelerationTestPage> {
  double currentSpeed = 0;
  double lastSpeed = 0;
  /// 速度是否0开始的，从0开始的才能开始计时
  bool _isStartZero = true;
  final Map<String, Duration> accelerationTimes = {
    '0-30': Duration.zero,
    '0-50': Duration.zero,
    '0-100': Duration.zero,
  };
  Timer? _timer;
  final Map<String, DateTime?> _milestoneStartTimes = {};
  var sender = Sender();

  String status = "请加速"; // 状态文字

  @override
  void initState() {
    super.initState();
    _startSpeedTest();
    // 假设第一次速度大于0
    if (currentSpeed > 0) {
      status = "请减速";
    }
  }

  void _startSpeedTest() {
    _timer = Timer.periodic(const Duration(milliseconds: 500), (timer) async {
      var speed = await sender.sendVehicleSpeed();
      updateSpeed(speed.toDouble());
    });
  }

  void updateSpeed(double speed) {
    setState(() {
      currentSpeed = speed;

      if (speed == 0) {
        status = "请加速";
        for (var k in accelerationTimes.keys) {
          accelerationTimes[k] = Duration.zero;
        }
        _isStartZero = true;
        _milestoneStartTimes.clear();
      } else if (lastSpeed == 0 && speed > 0) {
        // 只要从0开始加速，先设置为计时中
        status = "计时中";
        _isStartZero = true;
      } else if ((speed < lastSpeed && speed > 0) || speed >= 100) {
        status = "请减速";
        if (speed < lastSpeed && speed > 0) {
          _isStartZero = false;
        }
      }
      lastSpeed = speed;
    });
    _checkAccelerationMilestones();
  }

  void _checkAccelerationMilestones() {
    if (!_isStartZero) {
      return;
    }
    final now = DateTime.now();
    for (var milestone in accelerationTimes.keys) {
      final parts = milestone.split('-');
      if (parts.length != 2) continue;
      final targetSpeed = double.tryParse(parts[1]) ?? 0;
      Duration? currentTimeDuration = accelerationTimes[milestone];
      if (currentTimeDuration != Duration.zero) continue;
      if (currentSpeed >= targetSpeed) {
        if (_milestoneStartTimes.containsKey(milestone)) {
          final startTime = _milestoneStartTimes[milestone];
          if (startTime != null) {
            final duration = now.difference(startTime);
            setState(() {
              accelerationTimes[milestone] = duration;
            });
            _milestoneStartTimes.remove(milestone);
          }
        } else {
          setState(() {
            accelerationTimes[milestone] = Duration.zero;
          });
        }
      } else {
        if (!_milestoneStartTimes.containsKey(milestone)) {
          _milestoneStartTimes[milestone] = now;
        }
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _formatDuration(Duration duration) {
    if (duration == Duration.zero) return '0.000 s';
    String threeDigits(int n) => n.toString().padLeft(3, '0');
    final String seconds = duration.inSeconds.toString();
    final String milliseconds = threeDigits(
      duration.inMilliseconds.remainder(1000),
    );
    return '$seconds.$milliseconds s';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('百公里加速'),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.restore_outlined, color: Colors.white),
            onPressed: () {
              // 清除数据逻辑
              setState(() {
                for (var k in accelerationTimes.keys) {
                  accelerationTimes[k] = Duration.zero;
                }
                _milestoneStartTimes.clear();
                // currentSpeed = 0;
                if (currentSpeed > 0) {
                  status = "请减速";
                } else if (currentSpeed > 100) {
                  status = "请减速";
                } else {
                  status = "请加速";
                }
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // 状态栏
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            child: Row(
              children: [
                if (status == "请加速") ...[
                  Icon(
                    Icons.radio_button_checked,
                    color: Colors.black,
                    size: 18,
                  ),
                  const SizedBox(width: 4),
                  Text('请加速', style: const TextStyle(fontSize: 16)),
                ] else ...[
                  Text(
                    '请加速',
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
                const SizedBox(width: 12),
                Text('|', style: TextStyle(color: Colors.grey)),
                const SizedBox(width: 12),
                if (status == "计时中") ...[
                  Icon(
                    Icons.radio_button_checked,
                    color: Colors.black,
                    size: 18,
                  ),
                  const SizedBox(width: 4),
                  Text('计时中', style: const TextStyle(fontSize: 16)),
                ] else ...[
                  Text(
                    '计时中',
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
                const SizedBox(width: 12),
                Text('|', style: TextStyle(color: Colors.grey)),
                const SizedBox(width: 12),
                if (status == "请减速") ...[
                  Icon(
                    Icons.radio_button_checked,
                    color: Colors.black,
                    size: 18,
                  ),
                  const SizedBox(width: 4),
                  Text('请减速', style: const TextStyle(fontSize: 16)),
                ] else ...[
                  Text(
                    '请减速',
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ],
            ),
          ),
          // 车速仪表盘
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: _buildVehicleSpeedPanel(),
          ),
          // 说明
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              '速度为0时恢复准备状态，速度大于0时计时，达到或超过100显示结果。中途点击了清除图标，停止计时，直到速度为0再处于准备状态。',
              style: const TextStyle(fontSize: 13, color: Colors.black87),
              textAlign: TextAlign.center,
            ),
          ),
          // 加速时间列表
          _buildTimeView(),
        ],
      ),
    );
  }

  // 车速仪表盘
  Widget _buildVehicleSpeedPanel() {
    return SfRadialGauge(
      axes: <RadialAxis>[
        RadialAxis(
          minimum: 0,
          maximum: 220,
          interval: 20, // 每20一个主刻度r
          minorTicksPerInterval: 1, // 每个主刻度间1个小刻度
          radiusFactor: 0.9,
          axisLineStyle: AxisLineStyle(
            thickness: 0.1,
            color: Colors.blue[200],
            thicknessUnit: GaugeSizeUnit.factor,
          ),
          majorTickStyle: MajorTickStyle(
            length: 5,
            thickness: 2,
            color: Colors.blue[200],
          ),
          minorTickStyle: MinorTickStyle(
            length: 3,
            thickness: 1,
            color: Colors.blue[200],
          ),
          axisLabelStyle: GaugeTextStyle(color: Colors.black, fontSize: 12),
          labelOffset: 15,
          showFirstLabel: true,
          showLastLabel: true,
          pointers: <GaugePointer>[
            NeedlePointer(
              value: currentSpeed.toDouble(),
              enableAnimation: true,
              animationDuration: 1000,
              needleLength: 0.7,
              needleStartWidth: 1,
              needleEndWidth: 3,
              knobStyle: KnobStyle(
                knobRadius: 0.08,
                color: Colors.blue,
                borderWidth: 0.02,
                borderColor: Colors.white,
              ),
            ),
          ],
          annotations: <GaugeAnnotation>[
            GaugeAnnotation(
              widget: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "速度",
                    style: TextStyle(
                      fontSize: 15, // 小字体
                      color: Colors.blue,
                    ),
                  ),
                  Text(
                    "${currentSpeed.toInt()}",
                    style: TextStyle(
                      fontSize: 28, // 大字体
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                  const Text(
                    "km/h",
                    style: TextStyle(fontSize: 15, color: Colors.blue),
                  ),
                ],
              ),
              angle: 90,
              positionFactor: 0.8,
            ),
          ],
        ),
      ],
    );
  }

  // 加速时间列表
  Widget _buildTimeView() {
    return Expanded(
      child: ListView.separated(
        itemCount: accelerationTimes.length,
        itemBuilder: (context, index) {
          final milestone = accelerationTimes.keys.elementAt(index);
          final duration = accelerationTimes.values.elementAt(index);
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '$milestone KM',
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
                Text(
                  _formatDuration(duration),
                  style: const TextStyle(fontSize: 16, color: Colors.black),
                ),
              ],
            ),
          );
        },
        separatorBuilder: (context, index) =>
            const Divider(height: 1, thickness: 1),
      ),
    );
  }
}
