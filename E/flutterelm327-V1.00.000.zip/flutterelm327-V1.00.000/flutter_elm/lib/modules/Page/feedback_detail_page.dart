import 'package:flutter/material.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/Model/feedback_detail_model.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:flutter_elm/network/network_api.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:intl/intl.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class FeedbackDetailPage extends StatefulWidget {
  final int feedbackId;

  const FeedbackDetailPage({super.key, required this.feedbackId});

  @override
  State<FeedbackDetailPage> createState() => _FeedbackDetailPageState();
}

class _FeedbackDetailPageState extends State<FeedbackDetailPage> {
  bool _isLoading = false;
  FeedbackDetailModel? _feedbackDetail;
  List<VideoPlayerController> _videoControllers = [];
  List<ChewieController> _chewieControllers = [];

  @override
  void initState() {
    super.initState();
    _loadFeedbackDetail();
  }

  @override
  void dispose() {
    // 释放所有视频控制器资源
    for (var controller in _videoControllers) {
      controller.dispose();
    }
    for (var controller in _chewieControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  // 加载反馈详情
  Future<void> _loadFeedbackDetail() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    // 显示加载视图
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        TDLoadingView.show(context);
      }
    });

    try {
      NetworkModel model = await BatteryInfoApi.getFeedbackDetail(
        widget.feedbackId,
      );
      if (model.code == 2000 && model.data is FeedbackDetailModel) {
        setState(() {
          _feedbackDetail = model.data as FeedbackDetailModel;
        });
        
        // 异步初始化视频控制器
        await _initializeVideoControllers();
      } else {
        ToastAlert.show('获取反馈详情失败', duration: 3000);
      }
    } catch (e) {
      print('获取反馈详情异常: $e');
      ToastAlert.show('网络异常，请稍后重试', duration: 3000);
    } finally {
      setState(() {
        _isLoading = false;
      });
      // 隐藏加载视图
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          TDLoadingView.hide(context);
        }
      });
    }
  }

  // 初始化视频控制器
  Future<void> _initializeVideoControllers() async {
    if (_feedbackDetail?.enclosureOss == null) return;

    // 先释放之前的控制器
    for (var controller in _videoControllers) {
      controller.dispose();
    }
    for (var controller in _chewieControllers) {
      controller.dispose();
    }
    _videoControllers.clear();
    _chewieControllers.clear();

    // 为每个视频创建控制器
    for (var enclosure in _feedbackDetail!.enclosureOss!) {
      if (enclosure.isVideo && enclosure.url != null) {
        try {
          final videoController = VideoPlayerController.networkUrl(
            Uri.parse(enclosure.url!),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: false),
          );
          
          // 初始化视频控制器以生成缩略图
          await videoController.initialize();
          
          // 暂停在第一帧作为缩略图
          await videoController.pause();
          
          _videoControllers.add(videoController);

          final chewieController = ChewieController(
            videoPlayerController: videoController,
            autoPlay: false,
            looping: false,
            aspectRatio: 16 / 9,
            allowFullScreen: true,
            allowMuting: true,
            // 禁用内置控制器，使用自定义控制界面
            showControls: false,
            errorBuilder: (context, errorMessage) {
              return Center(
                child: Icon(Icons.error, color: Colors.white, size: 40),
              );
            },
            placeholder: Container(
              color: Colors.grey[800],
              child: Center(
                child: Icon(Icons.play_circle_outline, color: Colors.white, size: 40),
              ),
            ),
          );
          _chewieControllers.add(chewieController);
        } catch (e) {
          print('视频控制器初始化失败: $e');
          // 添加一个视频初始化占位符控制器，使用本地asset或默认黑色背景
          final videoController = VideoPlayerController.networkUrl(
            Uri.parse('https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'),
            videoPlayerOptions: VideoPlayerOptions(mixWithOthers: false),
          );
          _videoControllers.add(videoController);
          
          final chewieController = ChewieController(
            videoPlayerController: videoController,
            autoPlay: false,
            showControls: false,
            errorBuilder: (context, errorMessage) {
              return Container(
                color: Colors.grey[800],
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, color: Colors.white, size: 40),
                      SizedBox(height: 8),
                      Text('视频加载失败', style: TextStyle(color: Colors.white)),
                    ],
                  ),
                ),
              );
            },
            placeholder: Container(
              color: Colors.grey[800],
              child: Center(
                child: Icon(Icons.play_circle_outline, color: Colors.white, size: 40),
              ),
            ),
          );
          _chewieControllers.add(chewieController);
        }
      }
    }
    
    // 通知UI更新
    setState(() {});
  }

  // 格式化时间
  String _formatTime(int time) {
    if (time == 0) return '';
    return DateFormat(
      'yyyy-MM-dd HH:mm',
    ).format(DateTime.fromMillisecondsSinceEpoch(time));
  }

  // 获取反馈状态文本
  String _getStatusText(int status) {
    switch (status) {
      case 0:
        return '未回复';
      case 1:
        return '已回复';
      case 2:
        return '已解决';
      default:
        return '未知状态';
    }
  }

  // 构建附件网格
  Widget _buildAttachmentGrid() {
    if (_feedbackDetail?.enclosureOss == null ||
        _feedbackDetail!.enclosureOss!.isEmpty) {
      return Container();
    }

    return GridView.count(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      crossAxisCount: 3,
      childAspectRatio: 1,
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      padding: EdgeInsets.only(top: 16),
      children: _feedbackDetail!.enclosureOss!.map((enclosure) {
        if (enclosure.isImage && enclosure.url != null) {
          return _buildImageAttachment(enclosure.url!);
        } else if (enclosure.isVideo && enclosure.url != null) {
          int index = _feedbackDetail!.enclosureOss!.indexWhere(
            (e) => e.isVideo && e.url == enclosure.url,
          );
          return _buildVideoAttachment(index);
        }
        return Container();
      }).toList(),
    );
  }

  // 构建图片附件
  Widget _buildImageAttachment(String url) {
    return GestureDetector(
      onTap: () {
        _showFullScreenImage(url);
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          image: DecorationImage(image: NetworkImage(url), fit: BoxFit.cover),
        ),
      ),
    );
  }

  // 全屏显示图片
  void _showFullScreenImage(String imageUrl) {
    Navigator.push(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (context) => FullScreenImageViewer(
          imageUrl: imageUrl,
          onClose: () => Navigator.pop(context),
        ),
      ),
    );
  }

  // 构建视频附件
  Widget _buildVideoAttachment(int index) {
    if (index >= _chewieControllers.length) {
      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: Colors.grey[800],
        ),
        child: Center(
          child: Icon(Icons.play_circle_outline, color: Colors.white),
        ),
      );
    }

    final chewieController = _chewieControllers[index];
    final videoController = chewieController.videoPlayerController;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: Colors.black,
      ),
      width: double.infinity,
      height: 120, // 固定高度，确保不会溢出
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // 视频播放器
            Chewie(controller: chewieController),
            
            // 视频加载状态指示器
            if (!videoController.value.isInitialized) 
              Positioned.fill(
                child: Container(
                  color: Colors.black.withOpacity(0.6),
                  child: Center(
                    child: CircularProgressIndicator(color: Colors.white),
                  ),
                ),
              ),
            
            // 点击整个视频进入全屏
            Positioned.fill(
              child: GestureDetector(
                onTap: () {
                  _showFullScreenVideo(index);
                },
                child: Container(color: Colors.transparent),
              ),
            ),
            
            // 播放/暂停按钮覆盖层
            Positioned.fill(
              child: GestureDetector(
                onTap: () {
                  // 阻止事件冒泡到父级GestureDetector已不再需要，因为我们移除了参数
                  
                  if (videoController.value.isInitialized) {
                    if (chewieController.isPlaying) {
                      chewieController.pause();
                    } else {
                      chewieController.play();
                    }
                  }
                },
                child: Container(
                  color: Colors.transparent,
                  child: Center(
                    child: Icon(
                      videoController.value.isPlaying
                          ? Icons.pause
                          : Icons.play_arrow,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                ),
              ),
            ),
            
            // 全屏按钮
            Positioned(
              bottom: 8,
              right: 8,
              child: GestureDetector(
                onTap: () {
                  // 阻止事件冒泡已不再需要，因为我们移除了参数
                  
                  if (videoController.value.isInitialized) {
                    _showFullScreenVideo(index);
                  }
                },
                child: Icon(Icons.fullscreen, color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 全屏显示视频
  void _showFullScreenVideo(int index) {
    if (_feedbackDetail?.enclosureOss == null || 
        index >= _feedbackDetail!.enclosureOss!.length ||
        !_feedbackDetail!.enclosureOss![index].isVideo ||
        _feedbackDetail!.enclosureOss![index].url == null) {
      return;
    }

    final videoUrl = _feedbackDetail!.enclosureOss![index].url!;

    Navigator.push(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (context) => FullScreenVideoViewer(
          videoUrl: videoUrl,
          onClose: () => Navigator.pop(context),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('反馈内容'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: Colors.black87,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      body: _isLoading || _feedbackDetail == null
          ? Container()
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 反馈序号
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      '反馈序号: ${_feedbackDetail?.serialNumber ?? ''}',
                      style: TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                  ),

                  // 反馈信息卡片
                  Container(
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 1,
                          blurRadius: 2,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 用户头像和时间
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: Colors.blue.shade100,
                              child: Icon(Icons.person, color: Colors.blue),
                            ),
                            Text(
                              _formatTime(_feedbackDetail?.newCreateTime ?? 0),
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),

                        // 反馈内容
                        Padding(
                          padding: EdgeInsets.only(top: 16),
                          child: Text(
                            '反馈内容',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 8),
                          child: Text(
                            _feedbackDetail?.content ?? '',
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black87,
                              height: 1.5,
                            ),
                          ),
                        ),

                        // 附件网格
                        _buildAttachmentGrid(),
                      ],
                    ),
                  ),

                  // 客服处理状态
                  Container(
                    margin: EdgeInsets.only(top: 24),
                    alignment: Alignment.center,
                    child: Column(
                      children: [
                        // 咖啡图标
                        Container(
                          margin: EdgeInsets.only(bottom: 16),
                          child: Column(
                            children: [
                              SizedBox(
                                width: 80,
                                height: 80,
                                child: CustomPaint(painter: CoffeePainter()),
                              ),
                            ],
                          ),
                        ),

                        // 处理状态文本
                        Text(
                          '客服正在紧急处理中，请耐心等待~',
                          style: TextStyle(fontSize: 16, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      backgroundColor: Colors.grey.shade50,
    );
  }
}

// 咖啡图标自定义绘制
class CoffeePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.grey
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    // 绘制咖啡杯
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width / 2, size.height * 0.6),
        width: size.width * 0.6,
        height: size.height * 0.4,
      ),
      paint,
    );

    // 绘制咖啡杯把手
    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(size.width * 0.75, size.height * 0.6),
        width: size.width * 0.3,
        height: size.height * 0.3,
      ),
      0, // 开始角度
      3.14, // 结束角度
      false, // 是否使用中心点
      paint,
    );

    // 绘制咖啡杯底边
    canvas.drawLine(
      Offset(size.width * 0.2, size.height * 0.8),
      Offset(size.width * 0.8, size.height * 0.8),
      paint,
    );

    // 绘制咖啡蒸汽
    for (int i = 0; i < 3; i++) {
      canvas.drawLine(
        Offset(size.width * (0.35 + i * 0.1), size.height * 0.4),
        Offset(size.width * (0.37 + i * 0.1), size.height * 0.3),
        paint,
      );
      canvas.drawLine(
        Offset(size.width * (0.37 + i * 0.1), size.height * 0.3),
        Offset(size.width * (0.4 + i * 0.1), size.height * 0.25),
        paint,
      );
    }

    // 绘制饼干
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(size.width * 0.3, size.height * 0.85),
        width: size.width * 0.2,
        height: size.height * 0.1,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}

// 全屏图片查看器
class FullScreenImageViewer extends StatelessWidget {
  final String imageUrl;
  final VoidCallback onClose;

  const FullScreenImageViewer({
    super.key,
    required this.imageUrl,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 图片内容
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Center(
              child: InteractiveViewer(
                panEnabled: true,
                boundaryMargin: const EdgeInsets.all(20),
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.network(
                  imageUrl,
                  fit: BoxFit.contain,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                                  loadingProgress.expectedTotalBytes!
                            : null,
                        color: Colors.white,
                      ),
                    );
                  },
                  errorBuilder: (context, error, stackTrace) {
                    return const Center(
                      child: Icon(Icons.error, color: Colors.white, size: 50),
                    );
                  },
                ),
              ),
            ),
          ),
          // 关闭按钮
          Positioned(
            top: 40,
            left: 20,
            child: GestureDetector(
              onTap: onClose,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.close, color: Colors.white, size: 24),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// 全屏视频查看器
class FullScreenVideoViewer extends StatefulWidget {
  final String videoUrl;
  final VoidCallback onClose;

  const FullScreenVideoViewer({
    super.key,
    required this.videoUrl,
    required this.onClose,
  });

  @override
  State<FullScreenVideoViewer> createState() => _FullScreenVideoViewerState();
}

class _FullScreenVideoViewerState extends State<FullScreenVideoViewer> {
  late VideoPlayerController _videoPlayerController;
  late ChewieController _chewieController;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializeVideoPlayer();
  }

  Future<void> _initializeVideoPlayer() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });
      
      _videoPlayerController = VideoPlayerController.networkUrl(
        Uri.parse(widget.videoUrl),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: false),
      );
      
      await _videoPlayerController.initialize();
      
      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController,
        autoPlay: true,
        looping: false,
        aspectRatio: _videoPlayerController.value.aspectRatio > 0 
          ? _videoPlayerController.value.aspectRatio 
          : 16 / 9,
        allowFullScreen: true,
        allowMuting: true,
        showControls: true, // 在全屏模式下启用内置控制器
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Text(
              errorMessage, 
              style: TextStyle(color: Colors.white),
              textAlign: TextAlign.center,
            ),
          );
        },
        placeholder: Container(
          color: Colors.black,
          child: const Center(
            child: CircularProgressIndicator(color: Colors.white),
          ),
        ),
      );
      
      setState(() {
        _isLoading = false;
      });
      
      // 开始播放
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = '视频加载失败: ${e.toString()}';
      });
      print('视频加载错误: $e');
    }
  }

  @override
  void dispose() {
    _videoPlayerController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // 视频内容或加载/错误状态
          if (_isLoading) 
            Center(
              child: CircularProgressIndicator(color: Colors.white),
            )
          else if (_errorMessage != null)
            Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  _errorMessage!, 
                  style: TextStyle(color: Colors.white, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            Center(child: Chewie(controller: _chewieController)),
          
          // 关闭按钮
          Positioned(
            top: 40,
            left: 20,
            child: GestureDetector(
              onTap: widget.onClose,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.close, color: Colors.white, size: 24),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
