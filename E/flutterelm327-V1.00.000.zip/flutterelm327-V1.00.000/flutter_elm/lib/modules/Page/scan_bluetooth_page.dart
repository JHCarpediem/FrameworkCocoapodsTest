import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
// import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/Model/device_model.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:flutter_elm/command/bluetooth_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';

class ScanBLEPage extends StatefulWidget {
  const ScanBLEPage({super.key});

  @override
  State<StatefulWidget> createState() => _ScanBluetoothState();
}

class _ScanBluetoothState extends State<ScanBLEPage>
    with WidgetsBindingObserver {

  DeviceModel selModel = DeviceModel();
  bool isAuthorized = false;
  bool _isLocationPermissionDialogShowing = false;
  bool _isLocationServiceDialogShowing = false;

  late List<DeviceModel> tempItems;

  String searchText = '';
  List<DeviceModel> filteredItems = [];
  final TextEditingController _searchController = TextEditingController();

  late StreamSubscription<BluetoothAdapterState> _adapterSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    requestPermission();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    print('------应用状态: $state');
    // 应用从后台返回前台
    if (state == AppLifecycleState.resumed) {
      requestPermission();
    }
  }

  /// 申请权限
  void requestPermission() async {
      // 检查蓝牙状态
    var isSupported = await FlutterBluePlus.isSupported;
    print("------检测权限: $isSupported");
    _adapterSubscription = FlutterBluePlus.adapterState.listen((
      BluetoothAdapterState state,
    ) async {
      print("------蓝牙状态: $state");
      if (state == BluetoothAdapterState.on) {
        if (Platform.isAndroid) {
          final locationPermission = await Permission.locationWhenInUse.status;
          print("------位置权限: $locationPermission");
          if (locationPermission.isDenied) {
            if (!_isLocationPermissionDialogShowing) {
              _showLocationPermissionDialog();
              return;
            }
          } else if (locationPermission.isGranted) {
            // 检查位置服务是否开启
            final isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
            print("------位置服务状态: $isLocationServiceEnabled");
            if (!isLocationServiceEnabled && !_isLocationServiceDialogShowing) {
              _showLocationServiceDialog();
              return;
            }
          }
          FlutterBluePlus.startScan();
        } else {
          FlutterBluePlus.startScan();
        }
        setState(() {
          isAuthorized = true;
        });
      } else if (state == BluetoothAdapterState.off ||
          state == BluetoothAdapterState.unauthorized ||
          state == BluetoothAdapterState.unavailable) {
        ToastAlert.show('请开启蓝牙');
        setState(() {
          isAuthorized = false;
        });
        BLEManager().stopScan();
      }
    });

    if (Platform.isAndroid) {
      await FlutterBluePlus.turnOn();
    }
  }

  @override
  void dispose() {
    _adapterSubscription.cancel();
    BLEManager.instance.stopScan();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            BLEManager.instance.stopScan();
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline, size: 30),
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: const Text('没有搜到我的设备？', textAlign: TextAlign.center),
                    actionsAlignment: MainAxisAlignment.center,
                    content: const Text(
                      '1. 请确保设备已经正确供电，并且没有其他手机连接该设备\n\n2. 请在App内扫描并连接设备，而非【系统设置】内。\n如果已经在【系统设置】中连接了设备，请断开连接，并在App内重新搜索连接。\n\n3. 请确保打开了【位置】权限，蓝牙扫描需要依赖【位置权限】。',
                    ),
                    actions: <Widget>[
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        style: TextButton.styleFrom(
                          alignment: Alignment.center,
                        ),
                        child: const Text(
                          '确定',
                          style: TextStyle(color: Colors.blue, fontSize: 18),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.refresh, size: 30),
            onPressed: () {
              // 第二个按钮，重新开始扫码
              FlutterBluePlus.stopScan();
              FlutterBluePlus.startScan();
            },
          ),
        ],
        title: const Text('添加设备'),
      ),
      body: _setupUI(),
    );
  }

  Widget _setupUI() {
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: ValueListenableBuilder(
            valueListenable: _searchController,
            builder: (context, value, child) {
              return TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: '请输入关键字',
                  hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
                  prefixIcon: Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: EdgeInsets.symmetric(
                    vertical: 0,
                    horizontal: 12,
                  ),
                  suffixIcon: value.text.isNotEmpty
                      ? IconButton(
                          icon: Icon(Icons.clear),
                          onPressed: () {
                            _searchController.clear();
                            searchText = '';
                          },
                        )
                      : null,
                ),
                onChanged: (text) {
                  searchText = text;
                },
              );
            },
          ),
        ),
        Expanded(
          child: NotificationListener<ScrollNotification>(
            onNotification: (notification) {
              FocusScope.of(context).unfocus(); // 滚动时关闭键盘
              return false;
            },
            child: StreamBuilder<List<DeviceModel>>(
              stream: FlutterBluePlus.scanResults
                  .where((_) => isAuthorized)
                  .map((results) {
                    tempItems = results
                        .where((r) {
                          return r.device.platformName.isNotEmpty &&
                              isAuthorized;
                        })
                        .map((r) {
                          DeviceModel model = DeviceModel();
                          model.uuid = r.device.remoteId.str;
                          model.sn = r.device.remoteId.str;
                          model.name = r.device.platformName;

                          // print('------ name:${r.device.platformName}');

                          if (!BLEManager.devicesList.contains(r.device)) {
                            BLEManager.devicesList.add(r.device);
                          }
                          return model;
                        })
                        .toList();

                    // 更新过滤后的列表 (忽略大小写和前后空格)
                    if (searchText.isEmpty) {
                      filteredItems = List.from(tempItems);
                    } else {
                      final trimmedSearchText = searchText.trim().toLowerCase();
                      filteredItems = tempItems
                          .where(
                            (item) => item.name.toLowerCase().contains(
                              trimmedSearchText,
                            ),
                          )
                          .toList();
                    }

                    return filteredItems;
                  }),
              initialData: const [],
              builder: (c, snapshot) {
                if (!isAuthorized) {
                  return ListView();
                }
                return ListView(
                  children: snapshot.data!.map((device) {
                    return _buildCell(device);
                  }).toList(),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCell(DeviceModel device) {
    return GestureDetector(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 16),
        child: Container(
          height: 70,
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            border: Border.fromBorderSide(
              BorderSide(color: Colors.grey, width: 1),
            ),
          ),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5),
            child: Row(
              children: [
                // 蓝牙图标
                Icon(Icons.bluetooth, color: Colors.blue, size: 24),
                SizedBox(width: 5),
                // 蓝牙名字和uuid
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        device.name,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      Text(
                        Platform.isAndroid
                            ? "mac: ${device.uuid}"
                            : "uuid: ${device.uuid}",
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 5),
                // 箭头
                Icon(Icons.keyboard_arrow_right, color: Colors.grey, size: 30),
              ],
            ),
          ),
        ),
      ),
      onTap: () {
        connectToDevice(device);
      },
    );
  }

  /// 连接设备
  Future<void> connectToDevice(DeviceModel device) async {
    TDLoadingView.show(context);
    await BLEManager.instance.disconnectAll();
    BluetoothDevice? selDevice;
    try {
      selDevice = await BLEManager.instance.connectDevice(device.uuid);
      TDLoadingView.hide(context);
      if (selDevice == null) {
        ToastAlert.show('连接失败,请检查设备是否支持OBD');
        return;
      }
      BLEManager.instance.stopScan();
      print(
        '------连接成功: ${selDevice.remoteId.str} 名字: ${selDevice.platformName}',
      );
      // 确保这个状态仍然存在并且可以弹出
      if (mounted && Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      } else {
        print('没有页面可以弹出');
      }
    } catch (e) {
      print('------连接失败: ${e.toString()}');
      TDLoadingView.hide(context);
      ToastAlert.show('连接失败');
    }
  }

  /// 获取位置权限弹框
  void _showLocationPermissionDialog() {
    setState(() => _isLocationPermissionDialogShowing = true);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('需要位置权限'),
          content: const Text('蓝牙扫描需要位置权限，请开启位置访问权限以继续使用。'),
          actions: <Widget>[
            TextButton(
              child: const Text('取消'),
              onPressed: () {
                setState(() => _isLocationPermissionDialogShowing = false);
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('去开启'),
              onPressed: () async {
                setState(() => _isLocationPermissionDialogShowing = false);
                Navigator.of(context).pop();
                await openAppSettings();
              },
            ),
          ],
        );
      },
    );
  }

  void _showLocationServiceDialog() {
    setState(() => _isLocationServiceDialogShowing = true);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('位置服务未开启'),
          content: const Text('蓝牙扫描需要开启位置服务，请在设置中开启位置服务以继续使用。'),
          actions: <Widget>[
            TextButton(
              child: const Text('取消'),
              onPressed: () {
                setState(() => _isLocationServiceDialogShowing = false);
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('去开启'),
              onPressed: () async {
                setState(() => _isLocationServiceDialogShowing = false);
                Navigator.of(context).pop();
                await Geolocator.openLocationSettings();
              },
            ),
          ],
        );
      },
    );
  }
}
