import 'package:flutter/material.dart';
import 'package:flutter_elm/command/bluetooth_manager.dart';
import 'package:flutter_elm/command/sender.dart';
import 'package:flutter_elm/main.dart';
import 'package:flutter_elm/manager/database_manager.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:flutter_elm/modules/Page/acceleration_page.dart';
import 'package:flutter_elm/modules/Page/all_sensor_page.dart';
import 'package:flutter_elm/modules/Page/dtc_page.dart';
import 'package:flutter_elm/modules/Page/freeze_frame_page.dart';
import 'package:flutter_elm/modules/Page/instrument_dashboard_page.dart';
import 'package:flutter_elm/modules/Page/live_date_page.dart';
import 'package:flutter_elm/modules/Page/scan_bluetooth_page.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/src/rx_workers/rx_workers.dart';
import 'package:shared_preferences/shared_preferences.dart';

// 菜单项数据模型
class DashboardMenuItem {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;

  DashboardMenuItem({required this.icon, required this.title, this.onTap});
}

// 主页面
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<StatefulWidget> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver, RouteAware {
  var sender = Sender();
  UserModel? _model;

  // 动态菜单数据
  late final List<DashboardMenuItem> menuItems;

  // 动态车辆信息
  Map<String, String> carInfo = {};

  // 动态连接状态
  final bool elmConnected = true;
  final bool ecuConnected = true;
  bool isConnected = false;

  @override
  Widget build(BuildContext context) {
    return mainView();
  }

  @override
  initState() {
    super.initState();

    DatabaseManager().fetchUser().then((value) {
      setState(() {
        _model = value;
      });
    });

    menuItems = [
      DashboardMenuItem(
        icon: Icons.network_check,
        title: '仪表板',
        onTap: () => onMenuTap(0),
      ),
      DashboardMenuItem(
        icon: Icons.monitor_heart_outlined,
        title: '实时数据',
        onTap: () => onMenuTap(1),
      ),
      DashboardMenuItem(
        icon: Icons.list,
        title: '所有传感器',
        onTap: () => onMenuTap(2),
      ),
      DashboardMenuItem(
        icon: Icons.warning_amber_outlined,
        title: '故障码',
        onTap: () => onMenuTap(3),
      ),
      DashboardMenuItem(
        icon: Icons.save,
        title: '冻结帧',
        onTap: () => onMenuTap(4),
      ),
      DashboardMenuItem(
        icon: Icons.speed_outlined,
        title: '百公里加速',
        onTap: () => onMenuTap(5),
      ),
      DashboardMenuItem(
        icon: Icons.settings,
        title: '设置',
        onTap: () => onMenuTap(6),
      ),
    ];

    WidgetsBinding.instance.addObserver(this);
    notification();
    // BLEManager.instance.bluetoothLoop();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 订阅路由变化
    final route = ModalRoute.of(context);
    if (route is PageRoute<dynamic>) {
      routeObserver.subscribe(this, route);
    } else {
      // 如果不是 PageRoute，可以选择不订阅，或者打印警告
      debugPrint('当前路由不是 PageRoute，无法订阅 RouteObserver');
    }
  }

  @override
  void dispose() {
    // 取消订阅
    routeObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  void didPopNext() async {
    DatabaseManager().fetchUser().then((value) {
      setState(() {
        _model = value;
      });
    });
    
    if (carInfo['VIN'] == null && BLEManager.instance.selDevice != null) {
      var vin = await sender.sendVinCode();
      carInfo['VIN'] = vin;
      setState(() {});
    }
  }

  /// 监听蓝牙状态变化
  void notification() {
    ever(BLEManager.instance.status, (value) {
      print('------蓝牙状态变化: $value');
      if (value == TDBleState.findCharacteristic) {
        isConnected = true;
        // setupELM327();
        setState(() {});
      } else if (value == TDBleState.connected) {
        isConnected = true;
        setState(() {});
      } else if (value == TDBleState.disconnected) {
        isConnected = false;
        setState(() {});
      }
    });
  }

  Future<void> setupELM327() async {
    // List<String> initCommands = [
    //   Sender.initFirst,
    //   Sender.initSecond,
    //   Sender.initThird,
    //   Sender.initForth,
    //   Sender.initFifth,
    //   Sender.initSixth,
    //   Sender.initSeventh,
    //   Sender.initEighth,
    //   Sender.initNinth,
    // ];

    // for (var cmd in initCommands) {
    //   try {
    //     String response = await sender.sendCommand(cmd);
    //     await Future.delayed(const Duration(seconds: 1));
    //     print("------ELM327初始化命令: $cmd, 响应: $response");
    //   } catch (e) {
    //     print("------ELM327初始化失败: \$e");
    //     ToastAlert.show("这不是OBD设备蓝牙");
    //     return;
    //   }
    // }

    // var protocolType = await sender.sendProtocolType();
    // if (protocolType.isNotEmpty) {
    //   carInfo['OBD2协议'] = protocolType;
    // }
    // print("协议类型： $protocolType");

    // var ecuInfo = await sender.sendECUInfo();
    // if (ecuInfo.isNotEmpty) {
    //   carInfo['ECU信息'] = ecuInfo;
    // }
    // print("ECU信息： $ecuInfo");

    var vin = await sender.sendVinCode();
    if (vin.isNotEmpty) {
      carInfo['VIN'] = vin;
    }
    print("vin码： $vin");
    setState(() {});
  }

  Widget mainView() {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Topdon Car Scanner'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // 菜单网格
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: menuItems.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 24,
                crossAxisSpacing: 24,
                childAspectRatio: 0.9,
              ),
              itemBuilder: (context, index) {
                final item = menuItems[index];
                return GestureDetector(
                  onTap: item.onTap,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(item.icon, size: 48, color: Colors.blue),
                      const SizedBox(height: 8),
                      Text(item.title, style: const TextStyle(fontSize: 16)),
                    ],
                  ),
                );
              },
              // 只有在内容超出屏幕时才启用滚动
              physics: const ClampingScrollPhysics(),
            ),
          ),
          // 车辆信息
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: carInfo.entries.map((e) {
                return Row(
                  children: [
                    Text('${e.key}:', style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        e.value,
                        style: const TextStyle(fontSize: 14),
                      ),
                    ),
                  ],
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 8),
          const SizedBox(height: 12),
          blueStatusView(),
          const SizedBox(height: 34),
        ],
      ),
    );
  }

  // 断开按钮
  Widget blueStatusView() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: SizedBox(
        width: double.infinity,
        height: 56,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: isConnected ? Colors.red : Colors.blue,
          ),
          onPressed: () {
            pushScanBLEPage(context);
          },
          child: FutureBuilder(
            future: SharedPreferences.getInstance(),
            builder: (context, snapshot) {
              // 检查数据是否加载完成
              // if (snapshot.connectionState == ConnectionState.done) {
              //   final prefs = snapshot.data as SharedPreferences;
              //   final connectedID = prefs.getString(TDConfig.connectedID);
              //   var isConnected = connectedID != null && connectedID.isNotEmpty;
              //   print('------connectedID: $connectedID');
              //   return Text(
              //     isConnected ? '断开' : '连接蓝牙',
              //     style: const TextStyle(fontSize: 20, color: Colors.white),
              //   );
              // }
              return Text(
                isConnected ? '断开' : '连接蓝牙',
                style: const TextStyle(fontSize: 20, color: Colors.white),
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> pushScanBLEPage(BuildContext context) async {
    if (isConnected) {
      // 断开连接
      await BLEManager.instance.disconnect(manual: true);
      // carInfo['VIN'] = '';
      carInfo.remove('VIN');
    } else {
      // 如果没有连接设备，直接跳转到扫描页面
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => ScanBLEPage()),
      );

      // Navigator.push(context, MaterialPageRoute(builder: (context) => NativeBluetoothScanPage()));
    }
  }

  // 统一处理菜单点击事件的方法
  void onMenuTap(int index) {
    switch (index) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => InstrumentDashboardPage()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => LiveDatePage()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AllSensorPage()),
        );
        break;
      case 3:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DtcPage()),
        );
        break;
      case 4:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => FreezeFramePage()),
        );
        break;
      case 5:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AccelerationTestPage()),
        );
        break;
      case 6:
        if (_model != null) {
          Navigator.pushNamed(context, '/setting');
        } else {
          Navigator.pushNamed(context, '/login');
        }
        break;
      default:
        print('点击了：${menuItems[index].title}');
    }
  }
}
