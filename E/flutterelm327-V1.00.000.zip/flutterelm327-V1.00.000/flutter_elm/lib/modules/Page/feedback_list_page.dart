import 'package:flutter/material.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/Model/feedback_list_model.dart';
import 'package:flutter_elm/modules/Page/feedback_detail_page.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:flutter_elm/network/network_api.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:intl/intl.dart';

class FeedbackListPage extends StatefulWidget {
  const FeedbackListPage({super.key});

  @override
  State<FeedbackListPage> createState() => _FeedbackListPageState();
}

class _FeedbackListPageState extends State<FeedbackListPage> {
  bool _isLoading = false;
  List<FeedbackItemModel> _feedbackList = [];
  int _currentTab = 0; // 0表示进行中，1表示已完成
  bool _isRefreshing = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 在didChangeDependencies中加载数据，此时context已完全可用
    if (_feedbackList.isEmpty) {
      _loadFeedbackList();
    }
  }

  // 加载反馈列表
  Future<void> _loadFeedbackList() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    // 使用addPostFrameCallback确保在当前帧构建完成后再显示加载视图
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        TDLoadingView.show(context);
      }
    });

    try {
      NetworkModel model = await BatteryInfoApi.getFeedbackList(
        status: _currentTab,
      );
      if (model.code == 2000) {
        setState(() {
          _feedbackList = model.data is List
              ? (model.data as List).cast<FeedbackItemModel>()
              : [];

          if (_feedbackList.isEmpty) {}
        });
      } else {
        ToastAlert.show('获取反馈列表失败', duration: 3000);
      }
    } catch (e) {
      print('获取反馈列表异常: $e');
      ToastAlert.show('网络异常，请稍后重试', duration: 3000);
    } finally {
      setState(() {
        _isLoading = false;
        _isRefreshing = false;
      });
      // 使用addPostFrameCallback确保在当前帧构建完成后再隐藏加载视图
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          TDLoadingView.hide(context);
        }
      });
    }
  }

  // 切换标签
  void _switchTab(int tabIndex) {
    if (_currentTab == tabIndex) return;

    setState(() {
      _currentTab = tabIndex;
      _feedbackList = [];
    });
    _loadFeedbackList();
  }

  // 下拉刷新
  Future<void> _onRefresh() async {
    if (_isRefreshing) return;

    setState(() {
      _isRefreshing = true;
    });
    await _loadFeedbackList();
  }

  // 构建反馈列表项
  Widget _buildFeedbackItem(FeedbackItemModel item) {
    return GestureDetector(
      onTap: () {
        // 跳转到反馈详情页面
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => FeedbackDetailPage(feedbackId: item.id ?? 0),
          ),
        );
      },
      child: Container(
        padding: EdgeInsets.all(16),
        margin: EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withValues(alpha: 0.1),
              spreadRadius: 1,
              blurRadius: 2,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  item.content ?? '',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                if (_currentTab == 0) // 仅在进行中标签显示未回复状态
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: item.feedbackStatus == 0 ? Colors.red.withValues(alpha: 0.1) : 
                             item.feedbackStatus == 1 ? Colors.orange.withValues(alpha: 0.1) : 
                             Colors.green.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: item.feedbackStatus == 0 ? Colors.red : 
                               item.feedbackStatus == 1 ? Colors.orange : 
                               Colors.green,
                      ),
                    ),
                    child: Text(
                      item.feedbackStatus == 0 ? '未回复' : 
                      item.feedbackStatus == 1 ? '已回复' : '已解决',
                      style: TextStyle(
                        color: item.feedbackStatus == 0 ? Colors.red : 
                               item.feedbackStatus == 1 ? Colors.orange : 
                               Colors.green,
                        fontSize: 12,
                      ),
                    ),
                  ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              _formatTime(item.createTime ?? 0, newCreateTime: item.newCreateTime ?? 0),
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  // 格式化时间
  String _formatTime(int createTime, {int newCreateTime = 0}) {
    // 这里根据Swift代码逻辑实现时间格式化
    if (createTime == 0 && newCreateTime == 0) return '';
    
    if (newCreateTime > 0) {
      // 使用newCreateTime格式化时间
      return DateFormat(
        'yyyy-MM-dd HH:mm',
      ).format(DateTime.fromMillisecondsSinceEpoch(newCreateTime));
    } else {
      // 使用createTime，但加上8个小时(28800秒)
      // 注意：28800秒等于8小时
      final date = DateTime.fromMillisecondsSinceEpoch(createTime);
      final adjustedDate = date.add(Duration(seconds: 28800));
      return DateFormat(
        'yyyy-MM-dd HH:mm',
      ).format(adjustedDate);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('我的反馈'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        titleTextStyle: TextStyle(
          color: Colors.black87,
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      body: Column(
        children: [
          // 标签切换栏
          Container(
            color: Colors.white,
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _switchTab(0),
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '进行中',
                            style: TextStyle(
                              color: _currentTab == 0
                                  ? Colors.blue
                                  : Colors.grey,
                              fontWeight: _currentTab == 0
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              fontSize: 16,
                            ),
                          ),
                          if (_currentTab == 0)
                            Container(
                              margin: EdgeInsets.only(top: 4),
                              width: 20,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(1.5),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _switchTab(1),
                    child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '已完成',
                            style: TextStyle(
                              color: _currentTab == 1
                                  ? Colors.blue
                                  : Colors.grey,
                              fontWeight: _currentTab == 1
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              fontSize: 16,
                            ),
                          ),
                          if (_currentTab == 1)
                            Container(
                              margin: EdgeInsets.only(top: 4),
                              width: 20,
                              height: 3,
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(1.5),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Divider(height: 1, color: Colors.grey.shade100),

          // 反馈列表
          Expanded(
            child: RefreshIndicator(
              onRefresh: _onRefresh,
              child: _feedbackList.isEmpty && !_isLoading
                  ? Center(child: Text('暂无反馈记录'))
                  : ListView.builder(
                      padding: EdgeInsets.all(16),
                      itemCount: _feedbackList.length,
                      itemBuilder: (context, index) =>
                          _buildFeedbackItem(_feedbackList[index]),
                    ),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.grey.shade50,
    );
  }
}
