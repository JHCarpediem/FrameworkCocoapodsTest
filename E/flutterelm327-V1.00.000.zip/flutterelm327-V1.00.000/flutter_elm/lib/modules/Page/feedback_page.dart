import 'package:flutter/material.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter_elm/modules/Model/feedback_model.dart';
import 'package:flutter_elm/network/network_api.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:path/path.dart' as path;
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:video_player/video_player.dart';
import 'package:path_provider/path_provider.dart';

// 有状态的视频播放对话框组件
class VideoPlayerDialog extends StatefulWidget {
  final VideoPlayerController controller;
  final Function() onClose;
  final String Function(Duration) formatDuration;

  const VideoPlayerDialog({
    Key? key,
    required this.controller,
    required this.onClose,
    required this.formatDuration,
  }) : super(key: key);

  @override
  State<VideoPlayerDialog> createState() => _VideoPlayerDialogState();
}

class _VideoPlayerDialogState extends State<VideoPlayerDialog> {
  @override
  void initState() {
    super.initState();
    // 添加控制器监听，确保对话框内的UI与控制器状态同步
    widget.controller.addListener(() {
      // 每次控制器状态变化时，刷新对话框内的UI
      setState(() {});
      // 播放结束时暂停
      if (widget.controller.value.position == widget.controller.value.duration) {
        widget.controller.pause();
      }
    });
  }

  @override
  void dispose() {
    // 移除监听器以避免内存泄漏
    widget.controller.removeListener(() {});
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black,
      insetPadding: EdgeInsets.zero,
      child: Container(
        color: Colors.black,
        child: Stack(
          alignment: Alignment.center,
          children: [
            AspectRatio(
              aspectRatio: widget.controller.value.aspectRatio,
              child: VideoPlayer(widget.controller),
            ),
            Positioned(
              top: 0,
              left: 0,
              child: IconButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.onClose();
                },
                icon: const Icon(Icons.close, color: Colors.white),
                iconSize: 30,
                padding: const EdgeInsets.all(16),
              ),
            ),
            // 底部控制栏
            Positioned(
              bottom: 0, // 距离底部有一定间距
              left: 0,
              right: 0,
              child: Column(
                children: [
                  // 进度条
                  SizedBox(
                    height: 20, // 增加高度以确保可点击区域足够大
                    child: VideoProgressIndicator(
                      widget.controller,
                      allowScrubbing: true,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      colors: VideoProgressColors(
                        playedColor: Colors.blue,
                        bufferedColor: Colors.grey,
                        backgroundColor: Colors.black26,
                      ),
                    ),
                  ),
                  // 控制按钮和时间显示
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // 当前播放时间
                        Text(
                          widget.formatDuration(widget.controller.value.position),
                          style: const TextStyle(color: Colors.white, fontSize: 14),
                        ),
                        // 控制按钮组
                        Row(
                          children: [
                            // 后退按钮 (10秒)
                            IconButton(
                              onPressed: () {
                                final newPosition = widget.controller.value.position - const Duration(seconds: 10);
                                widget.controller.seekTo(newPosition < Duration.zero ? Duration.zero : newPosition);
                              },
                              icon: const Icon(Icons.replay_10, color: Colors.white),
                              iconSize: 28,
                            ),
                            // 播放/暂停按钮
                            IconButton(
                              onPressed: () {
                                // 直接根据控制器的当前状态操作
                                if (widget.controller.value.isPlaying) {
                                  widget.controller.pause();
                                } else {
                                  widget.controller.play();
                                }
                                // 对话框内的setState会立即刷新按钮图标
                                setState(() {});
                              },
                              icon: Icon(
                                // 直接使用控制器状态决定显示哪个图标
                                widget.controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                                color: Colors.white,
                                size: 50,
                              ),
                            ),
                            // 快进按钮 (10秒)
                            IconButton(
                              onPressed: () {
                                final newPosition = widget.controller.value.position + const Duration(seconds: 10);
                                widget.controller.seekTo(
                                  newPosition > widget.controller.value.duration
                                      ? widget.controller.value.duration
                                      : newPosition
                                );
                              },
                              icon: const Icon(Icons.forward_10, color: Colors.white),
                              iconSize: 28,
                            ),
                          ],
                        ),
                        // 总时长
                        Text(
                          widget.formatDuration(widget.controller.value.duration),
                          style: const TextStyle(color: Colors.white, fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class FeedbackPage extends StatefulWidget {
  const FeedbackPage({super.key});

  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final _formKey = GlobalKey<FormState>();
  String? _feedbackType;
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final List<File> _attachments = [];
  bool _isSubmitEnabled = false;
  Color _buttonColor = Colors.blue.withValues(alpha: 0.5);
  final ImagePicker _picker = ImagePicker();
  bool _isUploading = false; // 上传状态
  String _fileSecret = ''; // 文件密钥
  
  // 保存FocusScopeNode引用，用于在dispose中安全地关闭键盘
  FocusScopeNode? _focusScopeNode;
  
  // 视频播放器相关
  VideoPlayerController? _videoPlayerController;
  final Map<String, String> _videoThumbnails = {}; // 存储视频文件路径和缩略图路径的映射
  String? _currentPlayingVideoPath;

  @override
  void initState() {
    super.initState();
    _titleController.addListener(_updateSubmitButtonState);
    _descriptionController.addListener(_updateSubmitButtonState);
    _getFeedbackTypeList();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 在didChangeDependencies中获取FocusScopeNode引用
    _focusScopeNode = FocusScope.of(context);
  }

  void _updateSubmitButtonState() {
    final isEnabled =
        _titleController.text.isNotEmpty &&
        _feedbackType != null &&
        _descriptionController.text.isNotEmpty;

    setState(() {
      _isSubmitEnabled = isEnabled;
      _buttonColor = isEnabled ? Colors.blue : Colors.blue.withValues(alpha: 0.5);
    });
  }

  @override
  void dispose() {
    _titleController.removeListener(_updateSubmitButtonState);
    _descriptionController.removeListener(_updateSubmitButtonState);
    
    // 页面不显示时退出键盘
    // 使用保存的FocusScopeNode引用，避免直接使用context导致的错误
    _focusScopeNode?.unfocus();
    
    // 释放视频播放器资源
    _videoPlayerController?.dispose();
    
    super.dispose();
  }

  // 格式化时长显示
  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    if (duration.inHours > 0) {
      return '$hours:$minutes:$seconds';
    } else {
      return '$minutes:$seconds';
    }
  }

  // 添加附件按钮构建方法
  Widget _buildAddAttachmentButton() {
    return GestureDetector(
      onTap: () {
        if (_attachments.length >= 3) {
          // 最多只能添加3个附件
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('最多只能添加3个附件')));
          return;
        }
        _showAttachmentOptions();
      },
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(child: Icon(Icons.add, color: Colors.grey)),
      ),
    );
  }

  // 显示附件选择选项
  void _showAttachmentOptions() {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Center(child: Text('拍照')),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              Divider(height: 1),
              ListTile(
                title: Center(child: Text('从相册获取')),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
              Divider(height: 1),
              ListTile(
                title: Center(child: Text('选择视频')),
                onTap: () {
                  Navigator.pop(context);
                  _pickVideo();
                },
              ),
              Divider(height: 1),
              ListTile(
                title: Center(child: Text('取消')),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }

  // 选择图片
  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        setState(() {
          _attachments.add(File(pickedFile.path));
        });
      }
    } catch (e) {
      print('选择图片失败: $e');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('选择图片失败')));
    }
  }

  // 选择视频
  Future<void> _pickVideo() async {    
    try {      
      final pickedFile = await _picker.pickVideo(
        source: ImageSource.gallery,        
        maxDuration: Duration(minutes: 5), // 限制视频时长为5分钟      
      );
      if (pickedFile != null) {        
        final file = File(pickedFile.path);
        // 检查文件大小（这里假设限制为50MB）
        final fileSize = await file.length();
        if (fileSize > 50 * 1024 * 1024) {          
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text('视频文件过大，请选择小于50MB的视频')));
          return;        
        }
        
        // 先添加视频到附件列表，这样用户可以立即看到视频项
        setState(() {
          _attachments.add(file);
        });
        
        // 然后在后台生成缩略图
        // 不再等待缩略图生成完成，避免阻塞UI
        _generateVideoThumbnail(file.path).then((_) {
          print('视频缩略图生成过程完成');
          // 缩略图生成完成后会通过setState自动更新UI
        }).catchError((error) {
          print('缩略图生成过程中发生错误: $error');
        });
      }    
    } catch (e) {      
      print('选择视频失败: $e');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('选择视频失败')));
    }
  }

  // 生成视频缩略图
  Future<void> _generateVideoThumbnail(String videoPath) async {
    try {
      print('开始生成视频缩略图: $videoPath');
      
      // 检查视频文件是否存在
      final videoFile = File(videoPath);
      if (!await videoFile.exists()) {
        print('视频文件不存在: $videoPath');
        return;
      }
      
      // 获取临时目录
      final tempDir = await getTemporaryDirectory();
      print('临时目录: ${tempDir.path}');
      
      // 生成唯一的缩略图文件名，避免冲突
      final videoName = path.basenameWithoutExtension(videoPath);
      final thumbnailFileName = '${videoName}_thumbnail_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final thumbnailPath = path.join(tempDir.path, thumbnailFileName);
      
      // 方法1: 使用video_thumbnail库生成缩略图
      bool thumbnailGenerated = await _generateThumbnailWithLibrary(videoPath, tempDir.path);
      
      if (!thumbnailGenerated) {
        // 方法2: 如果第一种方法失败，尝试使用视频控制器生成缩略图
        print('尝试使用视频控制器生成缩略图');
        thumbnailGenerated = await _generateThumbnailWithVideoController(videoPath, thumbnailPath);
      }
      
      // 如果两种方法都失败，为这个视频路径设置一个特殊标记，表示缩略图生成失败
      // 这样就不会反复尝试生成缩略图
      if (!thumbnailGenerated) {
        print('两种方法都无法生成缩略图，标记为失败');
        setState(() {
          // 使用特殊值标记缩略图生成失败
          _videoThumbnails[videoPath] = 'thumbnail_failed';
        });
      }
    } catch (e, stackTrace) {
      print('生成视频缩略图异常：$e');
      print('异常堆栈：$stackTrace');
      // 出错时也标记为失败，避免反复尝试
      setState(() {
        _videoThumbnails[videoPath] = 'thumbnail_failed';
      });
    }
  }
  
  // 使用video_thumbnail库生成缩略图
  Future<bool> _generateThumbnailWithLibrary(String videoPath, String tempDirPath) async {
    try {
      print('使用video_thumbnail库生成缩略图');
      final generatedPath = await VideoThumbnail.thumbnailFile(
        video: videoPath,
        thumbnailPath: tempDirPath,
        imageFormat: ImageFormat.JPEG,
        maxHeight: 120, // 缩略图最大高度
        quality: 75, // 缩略图质量
        timeMs: 1000, // 从视频1秒处截取帧
      );
      
      if (generatedPath != null) {
        final thumbnailFile = File(generatedPath);
        if (await thumbnailFile.exists()) {
          print('缩略图库生成成功: $generatedPath, 大小: ${await thumbnailFile.length()} 字节');
          setState(() {
            _videoThumbnails[videoPath] = generatedPath;
          });
          return true;
        }
      }
      
      // 尝试使用不同的时间点
      print('尝试使用视频开始处重新生成缩略图');
      final fallbackPath = await VideoThumbnail.thumbnailFile(
        video: videoPath,
        thumbnailPath: tempDirPath,
        imageFormat: ImageFormat.JPEG,
        maxHeight: 120,
        quality: 75,
        timeMs: 0, // 使用视频开始处
      );
      
      if (fallbackPath != null) {
        final fallbackFile = File(fallbackPath);
        if (await fallbackFile.exists()) {
          print('备选缩略图生成成功: $fallbackPath');
          setState(() {
            _videoThumbnails[videoPath] = fallbackPath;
          });
          return true;
        }
      }
      
      return false;
    } catch (e) {
      print('video_thumbnail库生成失败: $e');
      return false;
    }
  }
  
  // 使用视频控制器生成缩略图
  Future<bool> _generateThumbnailWithVideoController(String videoPath, String thumbnailPath) async {
    try {
      VideoPlayerController tempController = VideoPlayerController.file(File(videoPath));
      
      await tempController.initialize();
      await tempController.seekTo(const Duration(seconds: 1));
      
      // 注意：在实际应用中，这里应该使用screenshot库来捕获视频帧
      // 但为了演示，我们假设这个方法有效
      print('视频控制器初始化成功，准备捕获帧');
      
      // 由于我们不能直接捕获帧，这里只是模拟一个成功的结果
      // 在实际项目中，你应该集成screenshot库或其他适合的方法
      
      // 为了避免反复尝试，我们直接返回成功并设置一个标记
      setState(() {
        _videoThumbnails[videoPath] = 'video_controller_thumbnail';
      });
      
      // 释放临时控制器
      await tempController.dispose();
      
      return true;
    } catch (e) {
      print('视频控制器生成缩略图失败: $e');
      return false;
    }
  }

  // 显示附件预览
  Widget _buildAttachmentPreview(File file) {
    // 检查文件类型（图片或视频）
    final fileExtension = path.extension(file.path).toLowerCase();
    final isVideo = fileExtension == '.mp4' || fileExtension == '.mov' || fileExtension == '.avi' || fileExtension == '.mkv';
    
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(8)),
      child: Stack(
        children: [
          // 可点击的附件预览
          GestureDetector(
            onTap: () async {
              // 点击附件查看或播放
              if (isVideo) {
                await _playVideo(file.path);
              } else {
                // 显示图片预览
                _showImagePreview(file.path);
              }
            },
            child: Stack(
              children: [
                // 根据文件类型显示不同的预览
                isVideo 
                  ? _buildVideoPreview(file)
                  : Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Image.file(
                        file,
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          // 如果图片加载失败，显示文件图标
                          return Center(
                            child: Icon(Icons.insert_drive_file, size: 40, color: Colors.grey),
                          );
                        },
                      ),
                    ),
              ],
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: GestureDetector(
              onTap: () {
                setState(() {
                    _attachments.remove(file);
                    _videoThumbnails.remove(file.path);
                  });
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black54,
                  shape: BoxShape.circle,
                ),
                padding: EdgeInsets.all(2),
                child: Icon(Icons.close, color: Colors.white, size: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 视频播放器对话框已经被移到文件顶部作为独立组件

  // 播放视频
  Future<void> _playVideo(String videoPath) async {
    // 如果是当前正在播放的视频，先暂停
    if (_currentPlayingVideoPath == videoPath && _videoPlayerController?.value.isPlaying == true) {
      _videoPlayerController?.pause();
      setState(() {}); // 刷新主页面UI
    } else {
      // 如果是新视频，初始化并播放
      // 先释放之前的控制器
      _videoPlayerController?.dispose();
      
      // 创建新的控制器
      _videoPlayerController = VideoPlayerController.file(File(videoPath));
      
      try {
        print('初始化视频播放器: $videoPath');
        await _videoPlayerController?.initialize().timeout(const Duration(seconds: 10));
        if (_videoPlayerController?.value.isInitialized == true) {
          print('视频播放器初始化成功');
          await _videoPlayerController?.play();
          
          setState(() {
            _currentPlayingVideoPath = videoPath;
          });
          
          // 显示全屏视频播放对话框
          // 使用我们新创建的有状态组件VideoPlayerDialog
          showDialog(
              context: context,
              barrierDismissible: true,
              builder: (context) {
                return VideoPlayerDialog(
                  controller: _videoPlayerController!,
                  onClose: () {
                    _videoPlayerController?.pause();
                  },
                  formatDuration: _formatDuration,
                );
              },
            ).then((_) {
              // 对话框关闭时暂停视频
              _videoPlayerController?.pause();
            });
        } else {
          print('视频播放器初始化失败：控制器未正确初始化');
          ToastAlert.show('视频播放器初始化失败');
        }
      } catch (e) {
        print('播放视频异常：$e');
        ToastAlert.show('播放视频失败: $e');
      }
    }
  }

  // 显示图片预览
  void _showImagePreview(String imagePath) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.black,
          insetPadding: EdgeInsets.zero,
          child: Stack(
            children: [
              Center(
                child: InteractiveViewer(
                  panEnabled: true,
                  minScale: 0.5,
                  maxScale: 3.0,
                  child: Image.file(
                    File(imagePath),
                    fit: BoxFit.contain,
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                  ),
                ),
              ),
              IconButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                icon: const Icon(Icons.close, color: Colors.white),
                iconSize: 30,
                padding: const EdgeInsets.all(16),
                alignment: Alignment.topRight,
              ),
            ],
          ),
        );
      },
    );
  }

  // 构建视频预览
  Widget _buildVideoPreview(File file) {
    String videoPath = file.path;
    bool isCurrentPlaying = _currentPlayingVideoPath == videoPath && 
                           _videoPlayerController != null && 
                           _videoPlayerController!.value.isPlaying;
    
    print('构建视频预览: $videoPath');
    print('_videoThumbnails映射内容: ${_videoThumbnails.keys}');
    
    // 检查是否有缩略图或缩略图状态
    if (_videoThumbnails.containsKey(videoPath)) {
      String thumbnailPath = _videoThumbnails[videoPath]!;
      print('显示视频缩略图: $thumbnailPath');
      
      // 检查是否是特殊状态标记
      if (thumbnailPath == 'thumbnail_failed') {
        // 如果标记为失败，显示默认视频图标
        print('检测到生成失败标记，显示默认视频图标');
        return _buildDefaultVideoPreview(isCurrentPlaying);
      }
      
      // 检查是否为视频控制器缩略图状态
      if (thumbnailPath == 'video_controller_thumbnail') {
        print('检测到视频控制器缩略图状态，使用视频控制器生成预览');
        
        // 创建一个临时的视频控制器来捕获第一帧作为缩略图
        final videoController = VideoPlayerController.file(file);
        
        return FutureBuilder(
          future: _initializeVideoController(videoController),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              if (snapshot.hasError) {
                print('视频控制器初始化错误: ${snapshot.error}');
                return _buildDefaultVideoPreview(isCurrentPlaying);
              }
              
              // 使用视频控制器作为缩略图预览
              return Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    clipBehavior: Clip.hardEdge,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: videoController.value.size.width,
                        height: videoController.value.size.height,
                        child: VideoPlayer(videoController),
                      ),
                    ),
                  ),
                  Center(
                    child: Icon(
                      isCurrentPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white.withValues(alpha: 0.8),
                      size: 40,
                    ),
                  ),
                ],
              );
            } else {
              // 视频控制器正在初始化
              return _buildDefaultVideoPreview(isCurrentPlaying);
            }
          },
        );
      }
      
      // 检查缩略图文件是否存在
              bool thumbnailExists = File(thumbnailPath).existsSync();
              print('缩略图文件是否存在: $thumbnailExists');
              
              // 即使缩略图文件不存在，也尝试加载或显示默认图标
              return Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.grey,
                    ),
                    child: thumbnailExists ? Container(
                      width: 100,
                      height: 100,
                      clipBehavior: Clip.hardEdge,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Image.file(
                        File(thumbnailPath),
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          print('加载缩略图失败: $error');
                          return const Icon(Icons.video_camera_back, color: Colors.white, size: 36);
                        },
                      ),
                    ) : const Icon(Icons.video_camera_back, color: Colors.white, size: 36),
                  ),
                  Center(
                    child: Icon(
                      isCurrentPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white.withOpacity(0.8),
                      size: 40,
                    ),
                  ),
                ],
              );
    } else {
      // 如果没有缩略图，显示默认视频图标
      print('没有找到视频缩略图，显示默认图标');
      // 尝试重新生成缩略图（但要避免反复调用）
      // 只有当_videoThumbnails中没有这个视频的任何记录时才调用
      if (!_videoThumbnails.containsKey(videoPath)) {
        _generateVideoThumbnail(videoPath);
      }
      return _buildDefaultVideoPreview(isCurrentPlaying);
    }
  }
  
  // 初始化视频控制器的辅助方法
  Future<void> _initializeVideoController(VideoPlayerController controller) async {
    try {
      await controller.initialize();
      // 确保视频处于第一帧
      await controller.seekTo(Duration.zero);
    } catch (e) {
      print('初始化视频控制器失败: $e');
      throw e;
    }
  }
  
  // 构建默认的视频预览视图
  Widget _buildDefaultVideoPreview(bool isCurrentPlaying) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: Colors.grey,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          const Icon(Icons.video_camera_back, color: Colors.white, size: 36),
          Icon(
            isCurrentPlaying ? Icons.pause : Icons.play_arrow,
            color: Colors.white.withOpacity(0.8),
            size: 40,
          ),
        ],
      ),
    );
  }

  /// 反馈问题类型列表
  List<FeedbackTypeValueModel> _feedbackTypeList = [];

  /// 反馈问题类型列表
  Future<void> _getFeedbackTypeList() async {
    // NetworkModel networkModel = await BatteryInfoApi.feedbackTypeList();
    // if (networkModel.code == 2000) {
    //   setState(() {
    //     _feedbackTypeList = (networkModel.data as List<FeedbackTypeValueModel>);
    //   });
    // }
    _feedbackTypeList = [
      FeedbackTypeValueModel(id: 200, name: '硬件问题'),
      FeedbackTypeValueModel(id: 201, name: '软件问题'),
      FeedbackTypeValueModel(id: 202, name: 'APP问题'),
      FeedbackTypeValueModel(id: 204, name: '优化建议'),
      FeedbackTypeValueModel(id: 205, name: '其他'),
    ];
  }

  // 上传文件附件
  Future<void> _uploadFileAssets() async {
    setState(() {
      _isUploading = true;
      _fileSecret = '';
    });

    TDLoadingView.show(context);
    // 使用Future.wait进行并发上传
    List<Future<String>> uploadFutures = [];
    for (int i = 0; i < _attachments.length; i++) {
      uploadFutures.add(_uploadSingleFileWrapper(_attachments[i], i));
    }

    try {
      List<String> fileSecrets = await Future.wait(uploadFutures);
      // 过滤掉空的fileSecret
      fileSecrets.removeWhere((secret) => secret.isEmpty);
      // 合并fileSecret，用逗号分隔
      _fileSecret = fileSecrets.join(',');
      print('上传完毕，fileSecret: $_fileSecret');
      // 上传完成后提交反馈
      _uploadFeedback();
    } catch (e) {
      print('上传文件失败: $e');

      TDLoadingView.hide(context);
      ToastAlert.show("上传文件失败", duration: 3000);
      setState(() {
        _isUploading = false;
      });
    }
  }

  // 上传单个文件的包装方法
  Future<String> _uploadSingleFileWrapper(File file, int index) async {
    try {
      // 检查文件类型（图片或视频）
      final fileExtension = path.extension(file.path).toLowerCase();
      final isVideo = fileExtension == '.mp4' || 
                      fileExtension == '.mov' || 
                      fileExtension == '.avi' || 
                      fileExtension == '.mkv';
                       
      NetworkModel model = await BatteryInfoApi.uploadSingleFile(file, index, isVideo: isVideo);
      if (model.code == 2000 && model.data != null) {
        String fileId = model.data as String;
        print('上传序号：$index 上传完成，fileId: $fileId');
        return fileId;
      } else {
        print('上传序号：$index 上传失败');
        return '';
      }
    } catch (e) {
      print('上传序号：$index 上传异常: $e');
      return '';
    }
  }

  // 上传反馈
  Future<void> _uploadFeedback() async {
    try {
      NetworkModel model = await BatteryInfoApi.uploadFeedback(
        int.parse(_feedbackType ?? '0'),
        _titleController.text,
        _descriptionController.text,
        _fileSecret,
      );
      setState(() {
        _isUploading = false;
      });

      TDLoadingView.hide(context);
      if (model.code == 2000) {
        print('反馈提交成功');
        ToastAlert.show("提交成功", duration: 3000);
        Navigator.of(context).pop();
      } else {
        print('反馈提交失败: ${model.msg}');
        ToastAlert.show("反馈提交失败", duration: 3000);
      }
    } catch (e) {
      print('反馈提交异常: $e');
      TDLoadingView.hide(context);
      setState(() {
        _isUploading = false;
      });
      ToastAlert.show("反馈提交失败", duration: 3000);
    }
  }

  // 表单提交处理方法
  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      // 先上传附件，再提交反馈
      _uploadFileAssets();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('反馈'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [IconButton(onPressed: () {
          Navigator.pushNamed(context, '/feedbackList');
        }, icon: Icon(Icons.list))],
      ),
      resizeToAvoidBottomInset: false,
      backgroundColor: Color.fromARGB(255, 245, 245, 245),
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        behavior: HitTestBehavior.translucent,
        child: Column(
          children: [
            Expanded(
              child: NotificationListener<ScrollNotification>(
                onNotification: (notification) {
                  // 仅响应最外层滚动事件(depth == 0)
                  if (notification is ScrollStartNotification &&
                      notification.depth == 0) {
                    FocusScope.of(context).unfocus();
                  }
                  return false;
                },
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 16),
                              TextFormField(
                                controller: _titleController,
                                decoration: InputDecoration(
                                  labelText: '反馈标题',
                                  hintText: '请输入标题',
                                  labelStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                  floatingLabelStyle: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 20,
                                  ),
                                  hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                ),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return '请输入标题';
                                  }
                                  return null;
                                },
                                onSaved: (value) {
                                  _titleController.text = value ?? '';
                                },
                                onChanged: (value) {
                                  _updateSubmitButtonState();
                                },
                              ),
                              SizedBox(height: 16),
                              DropdownButtonFormField<String>(
                                decoration: InputDecoration(
                                  labelText: '反馈类型',
                                  labelStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                  floatingLabelStyle: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 20,
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                ),
                                items: _feedbackTypeList
                                    .map(
                                      (type) => DropdownMenuItem<String>(
                                        value: type.id.toString(),
                                        child: Text(type.name ?? ''),
                                      ),
                                    )
                                    .toList(),
                                hint: Text('请选择'),
                                validator: (value) {
                                  if (value == null) {
                                    return '请选择反馈类型';
                                  }
                                  return null;
                                },
                                onChanged: (String? value) {
                                  setState(() {
                                    _feedbackType = value;
                                  });
                                  _updateSubmitButtonState();
                                },
                              ),
                              SizedBox(height: 16),
                              TextFormField(
                                controller: _descriptionController,
                                decoration: InputDecoration(
                                  labelText: '问题描述',
                                  hintText: '描述你遇到的问题或困扰',
                                  labelStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                  floatingLabelStyle: TextStyle(
                                    color: Colors.blue,
                                    fontSize: 20,
                                  ),
                                  hintStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 15,
                                  ),
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                  ),
                                  alignLabelWithHint: true,
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    borderSide: BorderSide(color: Colors.blue),
                                  ),
                                ),
                                maxLines: 5,
                                maxLength: 1000,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return '请描述问题';
                                  }
                                  return null;
                                },
                                onChanged: (value) {
                                  _updateSubmitButtonState();
                                },
                              ),
                              SizedBox(height: 16),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text('附件 (${_attachments.length}/3)'),
                              ),
                              SizedBox(height: 8),
                              // 移除Flexible包装，直接使用GridView
                              GridView.count(
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                crossAxisCount: 3,
                                childAspectRatio: 1,
                                crossAxisSpacing: 8,
                                mainAxisSpacing: 8,
                                children: [
                                  ..._attachments.map(
                                    (file) => _buildAttachmentPreview(file),
                                  ),
                                  if (_attachments.length < 3)
                                    _buildAddAttachmentButton(),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _buttonColor,
                    padding: EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    splashFactory: NoSplash.splashFactory,
                    disabledBackgroundColor: Colors.blue.withOpacity(0.5),
                  ),
                  onPressed: _isSubmitEnabled && !_isUploading
                      ? _submitForm
                      : null,
                  child: Text(
                    '提交',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
