import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:app_settings/app_settings.dart';
import 'package:flutter_elm/modules/Model/device_model.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';

class NativeBluetoothScanPage extends StatefulWidget {
  const NativeBluetoothScanPage({super.key});

  @override
  State<StatefulWidget> createState() => _NativeBluetoothScanState();
}

class _NativeBluetoothScanState extends State<NativeBluetoothScanPage>
    with WidgetsBindingObserver {
  // 用于与原生平台通信的通道
  static const MethodChannel _channel = MethodChannel('bluetooth_channel');
  // 用于接收蓝牙设备扫描结果的事件通道
  static const EventChannel _scanResultsChannel = EventChannel(
    'bluetooth_scan_results',
  );
  static const EventChannel _bluetoothStateChannel = EventChannel(
    'bluetooth_state',
  );

  List<DeviceModel> bluetoothDevices = [];
  bool isScanning = false;
  bool hasPermission = false;
  bool _isBluetoothEnabled = false;
  bool _locationServicesEnabled = false;

  bool _isPermissionDialogShowing = false;
  bool _isLocationDialogShowing = false;
  bool _isBluetoothDialogShowing = false;
  String searchText = '';
  List<DeviceModel> filteredDevices = [];
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isAndroid12Plus = false;

  StreamSubscription<dynamic>? _scanResultsSubscription;
  StreamSubscription<dynamic>? _bluetoothStateSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scrollController.addListener(() {
      // 滑动时隐藏键盘
      FocusManager.instance.primaryFocus?.unfocus();
    });
    _initDeviceInfo().then((_) {
      print('设备信息初始化完成，开始权限检查 - Android 12+: \$_isAndroid12Plus');
      _checkBluetoothState();
      _checkPermission();
    });
    _setupListeners();
  }

  Future<void> _initDeviceInfo() async {
    if (Platform.isAndroid) {
      try {
        final androidInfo = await DeviceInfoPlugin().androidInfo;
        final sdkInt = androidInfo.version.sdkInt;
        setState(() {
          _isAndroid12Plus = sdkInt >= 31;
        });
        print('设备信息初始化完成 - SDK版本: \$sdkInt, Android 12+: \$_isAndroid12Plus');
      } catch (e) {
        print('设备信息获取失败: \$e，默认使用位置权限检查');
        setState(() {
          _isAndroid12Plus = false;
        });
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stopScan();
    _scanResultsSubscription?.cancel();
    _bluetoothStateSubscription?.cancel();
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    // 应用从后台返回前台
    if (state == AppLifecycleState.resumed) {
      _checkLocationServiceAfterResume();
    }
  }

  // 应用恢复后检查位置服务状态
  Future<void> _checkLocationServiceAfterResume() async {
    if (Platform.isAndroid && hasPermission) {
      final bool locationEnabled = await _channel.invokeMethod(
        'isLocationServiceEnabled',
      );
      if (mounted) {
        setState(() {
          _locationServicesEnabled = locationEnabled;
        });
        // 如果位置服务已开启且蓝牙可用，自动开始扫描
        if (locationEnabled && _isBluetoothEnabled && !isScanning) {
          _startScan();
        } else if (!_isBluetoothEnabled) {
          _showBluetoothServiceDialog();
        } else if (!_locationServicesEnabled) {
          _showLocationServiceDialog();
        }
      }
    }
  }

  // 检查蓝牙状态
  Future<void> _checkBluetoothState() async {
    try {
      final bool enabled = await _channel.invokeMethod('enableBluetooth');
      setState(() {
        _isBluetoothEnabled = enabled;
      });

      // 检查位置服务是否启用
      if (hasPermission && Platform.isAndroid) {
        final bool locationEnabled = await _channel.invokeMethod(
          'isLocationServiceEnabled',
        );
        setState(() {
          _locationServicesEnabled = locationEnabled;
        });
        if (!locationEnabled) {
          // 添加位置服务状态日志
          print('位置服务未启用，显示位置服务对话框');
          _showLocationServiceDialog();
        }
      }
    } on PlatformException catch (e) {
      print('检查蓝牙状态失败: \$e');
      ToastAlert.show('检查蓝牙状态失败');
    }
  }

  // 检查权限
  // 权限检查主流程
  Future<void> _checkPermission() async {
    try {
      print('开始权限检查流程 - 平台: \${Platform.operatingSystem}');

      // 检查所需权限状态
      final PermissionCheckResult result = await _evaluatePermissions();

      // 更新权限状态
      setState(() => hasPermission = result.hasPermissions);
      print('更新后hasPermission值: \${hasPermission}');

      if (result.hasPermissions) {
        await _handlePermissionsGranted(result.isAndroid12Plus);
      } else {
        await _handlePermissionsDenied(result.isAndroid12Plus);
      }
    } on PlatformException catch (e) {
      print('检查权限失败: \$e');
      ToastAlert.show('检查权限失败');
    }
  }

  // 评估权限状态
  Future<PermissionCheckResult> _evaluatePermissions() async {
    final bool isAndroid12Plus = _isAndroid12Plus;

    if (isAndroid12Plus) {
      return await _checkBluetoothPermissions();
    } else {
      return await _checkLocationPermissions();
    }
  }

  // 检查Android 12+蓝牙权限
  Future<PermissionCheckResult> _checkBluetoothPermissions() async {
    final scanStatus = await Permission.bluetoothScan.status;
    final connectStatus = await Permission.bluetoothConnect.status;

    print('蓝牙权限状态 - 扫描: \$scanStatus, 连接: \$connectStatus');

    final hasPermissions = scanStatus.isGranted && connectStatus.isGranted;

    print('蓝牙权限检查结果: \$hasPermissions');
    return PermissionCheckResult(
      hasPermissions: hasPermissions,
      isAndroid12Plus: true,
      missingPermissions: _getMissingBluetoothPermissions(
        scanStatus,
        connectStatus,
      ),
    );
  }

  // 检查旧版Android位置权限
  Future<PermissionCheckResult> _checkLocationPermissions() async {
    final locationStatus = await Permission.location.status;
    print('位置权限状态: \$locationStatus');

    return PermissionCheckResult(
      hasPermissions: locationStatus.isGranted,
      isAndroid12Plus: false,
      missingPermissions: locationStatus.isGranted ? [] : [Permission.location],
    );
  }

  // 获取缺失的蓝牙权限
  List<Permission> _getMissingBluetoothPermissions(
    PermissionStatus scanStatus,
    PermissionStatus connectStatus,
  ) {
    final missing = <Permission>[];
    if (!scanStatus.isGranted) missing.add(Permission.bluetoothScan);
    if (!connectStatus.isGranted) missing.add(Permission.bluetoothConnect);
    return missing;
  }

  // 处理权限已授予情况
  Future<void> _handlePermissionsGranted(bool isAndroid12Plus) async {
    print('权限已授予，执行后续操作');

    // 旧版Android需要检查位置服务
    // if (!isAndroid12Plus) {
    //   await _checkAndRequestLocationServices();
    // }
    await _checkAndRequestLocationServices();

    _maybeStartScan();
  }

  // 处理权限被拒绝情况
  Future<void> _handlePermissionsDenied(bool isAndroid12Plus) async {
    print('权限未授予，进入权限申请流程');

    if (!Platform.isAndroid) {
      _maybeStartScan();
      return;
    }

    final PermissionStatus status = await _requestNecessaryPermissions(
      isAndroid12Plus,
    );

    setState(() => hasPermission = status.isGranted);

    if (!status.isGranted) {
      _handlePermissionRequestDenied(status, isAndroid12Plus);
    } else {
      await _handlePermissionsGranted(isAndroid12Plus);
    }

    _maybeStartScan();
  }

  // 请求必要的权限
  Future<PermissionStatus> _requestNecessaryPermissions(
    bool isAndroid12Plus,
  ) async {
    if (isAndroid12Plus) {
      return await _requestBluetoothPermissions();
    } else {
      return await Permission.location.request();
    }
  }

  // 请求Android 12+蓝牙权限
  Future<PermissionStatus> _requestBluetoothPermissions() async {
    final statuses = await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();

    final scanStatus = statuses[Permission.bluetoothScan]!;
    final connectStatus = statuses[Permission.bluetoothConnect]!;

    print('蓝牙扫描权限请求结果: \$scanStatus, 蓝牙连接权限请求结果: \$connectStatus');

    // 返回首先被拒绝的权限状态
    if (!scanStatus.isGranted) return scanStatus;
    if (!connectStatus.isGranted) return connectStatus;

    return PermissionStatus.granted;
  }

  // 处理权限请求被拒绝情况
  void _handlePermissionRequestDenied(
    PermissionStatus status,
    bool isAndroid12Plus,
  ) {
    print('权限未授予，状态: \$status');

    if (status.isPermanentlyDenied) {
      // 永久拒绝，引导至设置
      ToastAlert.show(
        isAndroid12Plus
            ? '需要蓝牙扫描和连接权限才能扫描设备，请在设置中开启'
            : '需要位置权限才能扫描蓝牙设备，请在设置中开启',
      );
      _showPermissionSettingDialog();
    } else {
      // 暂时拒绝，显示提示
      ToastAlert.show(isAndroid12Plus ? '需要授予蓝牙权限才能继续' : '需要授予位置权限才能继续');
    }
  }

  // 检查并请求位置服务
  Future<void> _checkAndRequestLocationServices() async {
    final bool locationEnabled = await _channel.invokeMethod(
      'isLocationServiceEnabled',
    );
    setState(() => _locationServicesEnabled = locationEnabled);
    if (!locationEnabled) {
      _showLocationServiceDialog();
    }
  }

  // 开启蓝牙
  Future<void> _enableBluetooth() async {
    try {
      final bool enabled = await _channel.invokeMethod('enableBluetooth');
      setState(() {
        _isBluetoothEnabled = enabled;
      });
      _maybeStartScan();
    } on PlatformException catch (e) {
      print('开启蓝牙失败: \$e');
      ToastAlert.show('开启蓝牙失败');
    }
  }

  // 显示权限设置对话框
  void _showPermissionSettingDialog() {
    if (_isPermissionDialogShowing) return;
    _isPermissionDialogShowing = true;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('权限缺失'),
        content: Text('扫描蓝牙设备需要位置权限，请前往设置开启'),
        actions: [
          TextButton(
            onPressed: () {
              // Navigator.pop(context);
              Navigator.of(context).pop();
              _isPermissionDialogShowing = false;
            },
            child: Text('取消'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              _isPermissionDialogShowing = false;
              // 根据Android版本打开相应的设置页面
              if (Platform.isAndroid) {
                final androidInfo = await DeviceInfoPlugin().androidInfo;
                final isAndroid12Plus = androidInfo.version.sdkInt >= 31;
                if (isAndroid12Plus) {
                  await AppSettings.openAppSettings(
                    type: AppSettingsType.bluetooth,
                  );
                } else {
                  await AppSettings.openAppSettings(
                    type: AppSettingsType.location,
                  );
                }
              } else {
                await AppSettings.openAppSettings();
              }
              // 添加延迟确保权限状态更新
              await Future.delayed(Duration(milliseconds: 500));
              // 返回后重新检查权限
              _checkPermission();
            },
            child: Text('设置'),
          ),
        ],
      ),
    ).then((_) => _isPermissionDialogShowing = false);
  }

  // 开始扫描
  Future<void> _startScan() async {
    if (!hasPermission) {
      _showPermissionSettingDialog();
      return;
    }

    if (!_isBluetoothEnabled) {
      _showBluetoothServiceDialog();
      return;
    }

    if (!_locationServicesEnabled) {
      _showLocationServiceDialog();
      return;
    }

    try {
      setState(() {
        isScanning = true;
        bluetoothDevices.clear();
        filteredDevices.clear();
      });

      await _channel.invokeMethod('startScan');
    } on PlatformException catch (e) {
      print('开始扫描失败: \$e');
      ToastAlert.show('开始扫描失败');
      setState(() {
        isScanning = false;
      });
    }
  }

  // 停止扫描
  Future<void> _stopScan() async {
    try {
      await _channel.invokeMethod('stopScan');
      setState(() {
        isScanning = false;
      });
    } on PlatformException catch (e) {
      print('停止扫描失败: \$e');
    }
  }

  // 设置监听器
  void _setupListeners() {
    // 监听扫描结果
    _scanResultsSubscription = _scanResultsChannel
        .receiveBroadcastStream()
        .listen(
          (dynamic result) {
            final Map<String, dynamic> deviceMap = Map<String, dynamic>.from(
              result,
            );
            final String name = deviceMap['name'] as String? ?? '未知设备';
            final String address = deviceMap['address'] as String? ?? '';

            // 检查设备是否已存在
            final bool isExists = bluetoothDevices.any(
              (device) => device.uuid == address,
            );

            if (!isExists) {
              final DeviceModel device = DeviceModel(
                name: name,
                uuid: address,
                mac: address,
                sn: address,
              );

              setState(() {
                bluetoothDevices.add(device);
                _filterDevices();
              });
            }
          },
          onError: (dynamic error) {
            print('接收扫描结果错误: \$error');
          },
        );

    // 监听蓝牙状态变化
    _bluetoothStateSubscription = _bluetoothStateChannel
        .receiveBroadcastStream()
        .listen(
          (dynamic state) {
            setState(() {
              _isBluetoothEnabled = state as bool;
              if (!_isBluetoothEnabled) {
                _stopScan();
              } else {
                _maybeStartScan();
              }
            });
          },
          onError: (dynamic error) {
            print('接收蓝牙状态错误: \$error');
          },
        );

    // 监听搜索文本变化
    _searchController.addListener(() {
      setState(() {
        searchText = _searchController.text;
        _filterDevices();
      });
    });
  }

  // 打开位置服务对话框
  Future<void> _showLocationServiceDialog() async {
    if (!_isLocationDialogShowing) {
      _isLocationDialogShowing = true;
      await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('位置服务未开启'),
          content: Text('蓝牙扫描需要开启位置服务，请在设置中开启'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _isLocationDialogShowing = false;
                });
              },
              child: Text('取消'),
            ),
            ElevatedButton(
              onPressed: () async {
                await _channel.invokeMethod('openLocationSettings');
                await Future.delayed(Duration(seconds: 2));
                final bool locationEnabled = await _channel.invokeMethod(
                  'isLocationServiceEnabled',
                );
                if (mounted) {
                  setState(() => _locationServicesEnabled = locationEnabled);
                  if (locationEnabled) {
                    _isLocationDialogShowing = false;
                    _startScan();
                    Navigator.pop(context);
                  }
                }
              },
              child: Text('设置'),
            ),
          ],
        ),
      ).then((_) => _isLocationDialogShowing = false);
    }
  }

  // 打开蓝牙服务对话框
  Future<void> _showBluetoothServiceDialog() async {
    if (!_isBluetoothDialogShowing) {
      _isBluetoothDialogShowing = true;
      await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('蓝牙服务未开启'),
          content: Text('请开启蓝牙以扫描设备'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  _isBluetoothDialogShowing = false;
                });
              },
              child: Text('取消'),
            ),
            ElevatedButton(
              onPressed: () async {
                _isBluetoothDialogShowing = false;
                final bool enabled = await _channel.invokeMethod(
                  'enableBluetooth',
                );
                if (mounted) {
                  setState(() => _isBluetoothEnabled = enabled);
                  if (enabled) Navigator.pop(context);
                }
              },
              child: Text('打开蓝牙'),
            ),
          ],
        ),
      ).then((_) => _isBluetoothDialogShowing = false);
    }
  }

  void _filterDevices() {
    if (searchText.isEmpty) {
      filteredDevices = List.from(bluetoothDevices);
    } else {
      final trimmedSearchText = searchText.trim().toLowerCase();
      filteredDevices = bluetoothDevices
          .where(
            (device) => device.name.toLowerCase().contains(trimmedSearchText),
          )
          .toList();
    }
  }

  // 连接设备
  Future<void> _connectToDevice(DeviceModel device) async {
    try {
      _stopScan();

      final bool connected = await _channel.invokeMethod('connectToDevice', {
        'address': device.uuid,
      });

      if (connected) {
        ToastAlert.show('连接成功');
        // 连接成功后返回上一页
        Navigator.of(context).pop(device);
      } else {
        ToastAlert.show('连接失败');
      }
    } on PlatformException catch (e) {
      print('连接设备失败: \$e');
      ToastAlert.show('连接设备失败');
    }
  }

  void _maybeStartScan() {
    if (hasPermission && _isBluetoothEnabled && !isScanning && mounted) {
      if (!_locationServicesEnabled) {
        _showLocationServiceDialog();
      } else {
        _startScan();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('原生蓝牙扫描'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            // _stopScan();
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              _startScan();
            },
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    return Column(
      children: [
        // 搜索框
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              hintText: '搜索设备',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              suffixIcon: searchText.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                      },
                    )
                  : null,
            ),
          ),
        ),

        // 蓝牙状态和控制按钮
        // Padding(
        //   padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
        //   child: Row(
        //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
        //     children: [
        //       Text(
        //         '蓝牙状态: ${_isBluetoothEnabled ? "已开启" : "已关闭"}',
        //         style: TextStyle(
        //           color: _isBluetoothEnabled ? Colors.green : Colors.red,
        //         ),
        //       ),
        //     ],
        //   ),
        // ),

        // 权限提示
        // if (!_locationServicesEnabled && Platform.isAndroid)
        //   Padding(
        //     padding: const EdgeInsets.symmetric(
        //       horizontal: 16.0,
        //       vertical: 8.0,
        //     ),
        //     child: Text(
        //       '需要位置权限才能扫描蓝牙设备',
        //       style: TextStyle(color: Colors.orange),
        //     ),
        //   ),

        // 位置服务开关提示
        if (!_locationServicesEnabled && Platform.isAndroid)
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: ElevatedButton(
              onPressed: () async {
                _isLocationDialogShowing = false;
                await _channel.invokeMethod('openLocationSettings');
              },
              child: const Text('开启位置服务'),
            ),
          ),

        // 蓝牙开关提示
        if (!_isBluetoothEnabled)
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: ElevatedButton(
              onPressed: _enableBluetooth,
              child: const Text('开启蓝牙'),
            ),
          ),

        // 设备列表
        Expanded(
          child: ListView.builder(
            controller: _scrollController,
            itemCount: filteredDevices.length,
            itemBuilder: (context, index) {
              final device = filteredDevices[index];
              return _buildDeviceItem(device);
            },
          ),
        ),
      ],
    );
  }

  // 构建设备列表项
  Widget _buildDeviceItem(DeviceModel device) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: ListTile(
        leading: const Icon(Icons.bluetooth, color: Colors.blue),
        title: Text(device.name),
        subtitle: Text(
          Platform.isAndroid ? 'MAC: ${device.mac}' : 'UUID: ${device.uuid}',
        ),
        trailing: const Icon(Icons.arrow_right),
        onTap: () => _connectToDevice(device),
      ),
    );
  }
}
