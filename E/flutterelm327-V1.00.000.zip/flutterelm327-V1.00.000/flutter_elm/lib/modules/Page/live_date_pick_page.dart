import 'package:flutter/material.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/modules/Model/instrument_model.dart';

class LiveDatePickPage extends StatefulWidget {
  final List<InstrumentModel> items;
  const LiveDatePickPage({super.key, required this.items});

  @override
  State<LiveDatePickPage> createState() => _LiveDatePickPageState();
}

class _LiveDatePickPageState extends State<LiveDatePickPage> {
  late List<InstrumentModel> tempItems;
  String searchText = '';
  List<InstrumentModel> filteredItems = [];
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    tempItems = widget.items
        .map(
          (e) => InstrumentModel(
            name: e.name,
            value: e.value,
            unit: e.unit,
            minimum: e.minimum,
            maximum: e.maximum,
            interval: e.interval,
            fetchCommand: e.fetchCommand,
            selected: e.selected,
          ),
        )
        .toList();
    filteredItems = List.from(tempItems);
    _searchController.addListener(() {
      setState(() {
        searchText = _searchController.text;
      });
    });
  }

  void _onItemSelect(int index, bool? value) {
    setState(() {
      final isSelected = value ?? false;
      final item = filteredItems[index];

      // 检查是否已选满4个
      if (isSelected) {
          final selectedItems = tempItems.where((item) => item.selected).toList();
          if (selectedItems.length >= 4) {
            // 显示提示
            ToastAlert.show("最多只能选4个");
            return;
          }
        }

      item.selected = isSelected;
    });
  }

  void _onReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex -= 1;
      final item = filteredItems.removeAt(oldIndex);
      filteredItems.insert(newIndex, item);

      // 同步到 tempItems 顺序
      tempItems
        ..clear()
        ..addAll(filteredItems);
    });
  }

  void _onSearch(String value) {
    setState(() {
      searchText = value;
      if (searchText.isEmpty) {
        filteredItems = List.from(tempItems);
      } else {
        filteredItems = tempItems
            .where((item) => item.name.contains(searchText))
            .toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
    title: const Text('选择传感器'),
    leading: const BackButton(),
  ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: ValueListenableBuilder(
              valueListenable: _searchController,
              builder: (context, value, child) {
                return TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: '请输入关键字',
                    hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.grey[200],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      vertical: 0,
                      horizontal: 12,
                    ),
                    suffixIcon: value.text.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              _onSearch('');
                            },
                          )
                        : null,
                  ),
                  onChanged: _onSearch,
                );
              },
            ),
          ),
          Expanded(
            child: NotificationListener<ScrollNotification>(
              onNotification: (notification) {
                FocusScope.of(context).unfocus(); // 滚动时关闭键盘
                return false;
              },
              child: ReorderableListView.builder(
                itemCount: filteredItems.length,
                onReorder: _onReorder,
                buildDefaultDragHandles: false,
                itemBuilder: (context, index) {
                  final item = filteredItems[index];
                  return Column(
                    key: ValueKey(item.name),
                    children: [
                      ListTile(
                        leading: Checkbox(
                          value: item.selected,
                          onChanged: (v) => _onItemSelect(index, v),
                          activeColor: Colors.blue, // 设置选中时的背景颜色
                          checkColor: Colors.white, // 设置选中时对勾的颜色
                        ),
                        title: Text(item.name),
                        trailing: ReorderableDragStartListener(
                          index: index,
                          child: const Icon(Icons.drag_handle),
                        ),
                      ),
                      const Divider(height: 1, thickness: 1),
                    ],
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 34, left: 50, right: 50),
            child: SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue, // 设置背景颜色
                    foregroundColor: Colors.white, // 设置文字颜色
                  ),
                  onPressed: () {
                    Navigator.pop(context, tempItems);
                  },
                  child: const Text('确定', style: TextStyle(fontSize: 20)),
                ),
              ),
          ),
        ],
      ),
    );
  }

  @override
  dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
