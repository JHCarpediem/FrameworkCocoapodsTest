import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_elm/command/td_toast.dart';
import 'package:flutter_elm/manager/database_manager.dart';
import 'package:flutter_elm/modules/Model/user_model.dart';
import 'package:flutter_elm/modules/View/td_loading_view';
import 'package:flutter_elm/network/network_api.dart';
import 'package:flutter_elm/network/network_model.dart';
import 'package:flutter_elm/tools/configration.dart';
import 'package:flutter_elm/tools/string_extension.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'register_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<StatefulWidget> createState() => LoginPageState();
}

class LoginPageState extends State<LoginPage> {
  UserModel? _model;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final FocusNode _emailFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();
  bool _isEmailValid = false;
  bool _isPasswordVisible = false;

  @override
  void initState() {
    super.initState();
    _emailController.addListener(() {
      setState(() {
        _isEmailValid = _emailController.text.isValidateEmail;
      });
    });
  }

  void _manageFocus() {
    // 统一管理焦点，确保键盘隐藏
    _emailFocusNode.unfocus();
    _passwordFocusNode.unfocus();
    FocusScope.of(context).unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        _manageFocus();
      },
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          shadowColor: Colors.transparent,
          leading: Container(
            margin: const EdgeInsets.only(left: 20),
            child: IconButton(
              icon: const Icon(Icons.arrow_back, color: Colors.blue, size: 30),
              onPressed: () {
                _manageFocus();
                Navigator.of(context).pop();
              },
            ),
          ),
        ),
        body: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.white,
          child: buildMain(),
        ),
      ),
    );
  }

  Widget buildMain() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo and Title
            const Center(
              child: Icon(Icons.account_circle, size: 100, color: Colors.blue),
            ),
            const SizedBox(height: 20),
            const Center(
              child: Text(
                '欢迎使用TOPDON',
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 10),
            const Center(
              child: Text(
                '请登录您的TOPDON账号,TOPDON账号适用于TOPDON旗下的所有APP',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey, fontSize: 14),
              ),
            ),
            const SizedBox(height: 50),
            // Email Input
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey.shade300, width: 1),
              ),
              child: TextField(
                controller: _emailController,
                focusNode: _emailFocusNode,
                cursorColor: Colors.blue,
                inputFormatters: [
                  FilteringTextInputFormatter.deny(RegExp(r'\s')),
                ], // 禁止输入空格
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.email, color: Colors.blue),
                  suffixIcon: _emailController.text.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear, color: Colors.grey),
                          onPressed: () {
                            _emailController.clear();
                            setState(() {
                              _isEmailValid = false;
                            });
                          },
                        )
                      : null,
                  hintText: '请输入邮箱',
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(15),
                ),
              ),
            ),
            // Email validation error message
            if (!_isEmailValid && _emailController.text.isNotEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 5, left: 10, bottom: 5),
                child: Text(
                  '请输入正确的邮箱账号',
                  style: TextStyle(color: Colors.red, fontSize: 12),
                  textAlign: TextAlign.left,
                ),
              ),
            const SizedBox(height: 20),
            // Password Input
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.grey.shade300, width: 1),
              ),
              child: TextField(
                controller: _passwordController,
                focusNode: _passwordFocusNode,
                cursorColor: Colors.blue,
                obscureText: !_isPasswordVisible,
                inputFormatters: [
                  FilteringTextInputFormatter.deny(RegExp(r'\s')),
                ],
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.lock, color: Colors.blue),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                      color: Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                  ),
                  hintText: '请输入登录密码',
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(15),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Remember me and Sign Up
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () {
                    _manageFocus();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            const RegisterPage(pageType: PageType.register),
                      ),
                    );
                  },
                  child: const Text(
                    '立即注册',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    _manageFocus();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const RegisterPage(
                          pageType: PageType.forgotPassword,
                        ),
                      ),
                    );
                  },
                  child: const Text(
                    '忘记密码',
                    style: TextStyle(color: Colors.blue),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 50),
            // Login Button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed:
                    (_isEmailValid &&
                        _emailController.text.isNotEmpty &&
                        _passwordController.text.isNotEmpty)
                    ? () {
                        _manageFocus();
                        _loginRequest();
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      (_isEmailValid &&
                          _emailController.text.isNotEmpty &&
                          _passwordController.text.isNotEmpty)
                      ? Colors.blue
                      : Colors.blue.withValues(alpha: 0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  splashFactory: NoSplash.splashFactory,
                  disabledBackgroundColor: Colors.blue.withValues(alpha: 0.5),
                ),
                child: const Text(
                  '登录',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 34),
          ],
        ),
      ),
    );
  }

  // 登录请求
  _loginRequest() async {
    Map<String, dynamic> param = {
      'type': 0,
      'validateBindPhone': false,
      'userAccount': _emailController.text,
      'password': _passwordController.text,
    };
    TDLoadingView.show(context);
    NetworkModel networkModel = await BatteryInfoApi.login(param);

    // 添加mounted检查以避免'BuildContext's across async gaps'警告

    if (networkModel.code == 2000) {
      if (networkModel.data != null) {
        _model = networkModel.data as UserModel;

        var prefs = await SharedPreferences.getInstance();
        prefs.setString(TDConfig.token, _model?.token ?? '');
        await DatabaseManager().saveUser(_model!);
        ToastAlert.show('登录成功', duration: 3000);
        if (!mounted) return;
        TDLoadingView.hide(context);
        Navigator.of(context).pop();
      } else {
        ToastAlert.show("登录失败，服务器返回数据异常", duration: 3000);
      }
    } else {
      if (!mounted) return;
      TDLoadingView.hide(context);
      ToastAlert.show(networkModel.msg ?? '登录失败，请检查网络连接', duration: 3000);
    }
  }
}
