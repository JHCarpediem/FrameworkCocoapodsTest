import 'package:flutter_elm/command/sender.dart';

class InstrumentModel {
  late String name = "";
  late double value = 0.0;
  late String unit = "";
  late double minimum = 0.0;
  late double maximum = 0.0;
  late double interval = 0.0;
  Future<dynamic> Function()? fetchCommand; // 新增字段
  late bool selected = true;

  InstrumentModel({
    required this.name,
    required this.value,
    required this.unit,
    required this.minimum,
    required this.maximum,
    required this.interval,
    this.fetchCommand,
    required this.selected,
  });

  @override
  String toString() {
    return 'InstrumentModel(name: $name, value: $value, unit: $unit, min: $minimum, max: $maximum, interval: $interval)';
  }

  // 获取所有数据
  static List<InstrumentModel> genarateData({bool isAllSelected = true, isFreeze = false}) {
    // ✅ 完整的 allData 列表，你提供的所有元素，一个不少，且已去掉所有 $变量（如 $engineSpeed）
    List<String> allData = [
      '发动机负荷:  %: 0: 100',
      '冷却液温度:  °C: -40: 150',
      '短期燃油修正1号气缸组 - 单元1:  %: -100: 99.2',
      '长期燃油修正1号气缸组 - 单元1:  %: -100: 99.2',
      '短期燃油修正2号气缸组 - 单元2:  %: -100: 99.2',
      '长期燃油修正2号气缸组 - 单元2:  %: -100: 99.2',
      '燃油压力:  kPa: 0: 765',
      '进气歧管绝对压力:  kPa: 0: 255',
      '转速:  rpm: 0: 16383',
      '车速:  km/h: 0: 255',
      '正时提前:  °: -64: 63.5',
      '进气温度:  °C: -40: 215',
      'MAF空气流量:  g/s: 0: 655.35',
      '节气门位置:  %: 0: 100',
      '氧传感器1 单元1电压:  V: 0: 1.275',
      '氧传感器1 单元1短期燃油修正:  %: -100: 99.2',
      '氧传感器2 单元1电压:  V: 0: 1.275',
      '氧传感器2 单元1短期燃油修正:  %: -100: 99.2',
      '氧传感器3 单元1电压:  V: 0: 1.275',
      '氧传感器3 单元1短期燃油修正:  %: -100: 99.2',
      '氧传感器4 单元1电压:  V: 0: 1.275',
      '氧传感器4 单元1短期燃油修正:  %: -100: 99.2',
      '氧传感器1 单元2电压:  V: 0: 1.275',
      '氧传感器1 单元2短期燃油修正:  %: -100: 99.2',
      '氧传感器2 单元2电压:  V: 0: 1.275',
      '氧传感器2 单元2短期燃油修正:  %: -100: 99.2',
      '氧传感器3 单元2电压:  V: 0: 1.275',
      '氧传感器3 单元2短期燃油修正:  %: -100: 99.2',
      '氧传感器4 单元2电压:  V: 0: 1.275',
      '氧传感器4 单元2短期燃油修正:  %: -100: 99.2',
      '发动机当前运行时间:  s: 0: 65535',
      '故障灯亮时行驶的距离(MIL):  km: 0: 65535',
      '燃油轨压力（相对于歧管真空）:  kPa: 0: 5177.265',
      '燃油轨压力:  kPa: 0: 655350',
      '氧传感器1 等价比:  %: 0: 2',
      '氧传感器1 电压:  V: 0: 8',
      '氧传感器2 等价比:  %: 0: 2',
      '氧传感器2 电压:  V: 0: 8',
      '氧传感器3 等价比:  %: 0: 2',
      '氧传感器3 电压:  V: 0: 8',
      '氧传感器4 等价比:  %: 0: 2',
      '氧传感器4 电压:  V: 0: 8',
      '氧传感器5 等价比:  %: 0: 2',
      '氧传感器5 电压:  V: 0: 8',
      '氧传感器6 等价比:  %: 0: 2',
      '氧传感器6 电压:  V: 0: 8',
      '氧传感器7 等价比:  %: 0: 2',
      '氧传感器7 电压:  V: 0: 8',
      '氧传感器8 等价比:  %: 0: 2',
      '氧传感器8 电压:  V: 0: 8',
      '命令EGR任务:  %: 0: 100',
      'EGR错误:  %: -100: 99.2',
      '命令蒸发排放清除:  %: 0: 100',
      '油箱液位输入:  %: 0: 100',
      '代码清除后的预热:  : 0: 255',
      '代码清除后的行驶距离:  km: 0: 65535',
      '蒸发系统蒸汽压力:  Pa: -8192: 8191.75',
      '气压:  kPa: 0: 255',
      '氧传感器1 电流:  mA: 0: 2',
      '氧传感器1 等价比:  : -128: 128',
      '氧传感器2 电流:  mA: 0: 2',
      '氧传感器2 等价比:  : -128: 128',
      '氧传感器3 电流:  mA: 0: 2',
      '氧传感器3 等价比:  : -128: 128',
      '氧传感器4 电流:  mA: 0: 2',
      '氧传感器4 等价比:  : -128: 128',
      '氧传感器5 电流:  mA: 0: 2',
      '氧传感器5 等价比:  : -128: 128',
      '氧传感器6 电流:  mA: 0: 2',
      '氧传感器6 等价比:  : -128: 128',
      '氧传感器7 电流:  mA: 0: 2',
      '氧传感器7 等价比:  : -128: 128',
      '氧传感器8 电流:  mA: 0: 2',
      '氧传感器8 等价比:  : -128: 128',
      '催化器温度传感器1:  °C: -40: 6513.5',
      '催化器温度传感器2:  °C: -40: 6513.5',
      '催化器温度传感器3:  °C: -40: 6513.5',
      '催化器温度传感器4:  °C: -40: 6513.5',
      '控制模块电压:  V: 0: 65.535',
      '绝对负载值:  %: 0: 25700',
      '指令空燃比:  : 0: 2',
      '相对节气门位置:  %: 0: 100',
      '环境温度:  °C: -40: 215',
      '绝对油门位置B:  %: 0: 100',
      '绝对油门位置C:  %: 0: 100',
      '油门踏板位置D:  %: 0: 100',
      '油门踏板位置E:  %: 0: 100',
      '油门踏板位置F:  %: 0: 100',
      '指令油门执行器:  %: 0: 100',
      'MIL运行时间:  min: 0: 65535',
      '故障码清除后运行时间:  min: 0: 65535',
      '空流计的最大流量值:  g/s: 0: 2550',
      '乙醇燃油比例:  %: 0: 100',
      'EVAP系统绝对蒸气压:  kPa: 0: 327.675',
      'EVAP系统蒸气压:  Pa: -32768: 32767',
      '短期二次氧传感修正 Bank1:  %: -100: 99.2',
      '短期二次氧传感修正 Bank3:  %: -100: 99.2',
      '长期二次氧传感修正 Bank1:  %: -100: 99.2',
      '长期二次氧传感修正 Bank3:  %: -100: 99.2',
      '短期二次氧传感修正 Bank2:  %: -100: 99.2',
      '短期二次氧传感修正 Bank4:  %: -100: 99.2',
      '长期二次氧传感修正 Bank2:  %: -100: 99.2',
      '长期二次氧传感修正 Bank4:  %: -100: 99.2',
      '燃油轨绝对压力值:  kPa: 0: 655350',
      '相对油门位置:  %: 0: 100',
      '混动/纯电 电池组剩余电量:  %: 0: 100',
      '发动机油温:  °C: -40: 210',
      '燃油喷射正时:  °: -210: 301.992',
      '发动机燃油率:  L/h: 0: 3212.75',
      '驾驶员的动力请求 - 扭矩百分比:  %: -125: 130',
    ];

    var sender = Sender();

    var commandList = [
      () async => await sender.sendCalculatedEngineLoad(isFreeze: isFreeze), // 发动机负载
      () async => await sender.sendEngineCoolantTemp(isFreeze: isFreeze), // 冷却液温度
      () async => await sender.sendShortTermFuelTrim1(isFreeze: isFreeze), // 短期燃油修正1号气缸组
      () async => await sender.sendLongTermFuelTrim1(isFreeze: isFreeze), // 长期燃油修正1号气缸组
      () async => await sender.sendShortTermFuelTrim2(isFreeze: isFreeze), // 短期燃油修正2号气缸组
      () async => await sender.sendLongTermFuelTrim2(isFreeze: isFreeze), // 长期燃油修正2号气缸组
      () async => await sender.sendFuelPressure(isFreeze: isFreeze), // 燃油压力
      () async => await sender.sendIntakManifoldABSPressure(isFreeze: isFreeze), // 进气歧管绝对压力
      () async => await sender.sendEngineRPM(isFreeze: isFreeze), // 发动机转速
      () async => await sender.sendVehicleSpeed(isFreeze: isFreeze), // 车速
      () async => await sender.sendTimingAdvance(isFreeze: isFreeze), // 正时提前
      () async => await sender.sendIntakeAirTemp(isFreeze: isFreeze), // 进气温度
      () async => await sender.sendMAFFlowRate(isFreeze: isFreeze), // MAF空气流量
      () async => await sender.sendThrottlePosition(isFreeze: isFreeze), // 节气门位置

      () async => await sender.sendOxygenSensor1(isFreeze: isFreeze), // 氧传感器1 单元1
      () async => await sender.sendOxygenSensor2(isFreeze: isFreeze), // 氧传感器2 单元1
      () async => await sender.sendOxygenSensor3(isFreeze: isFreeze), // 氧传感器3 单元1
      () async => await sender.sendOxygenSensor4(isFreeze: isFreeze), // 氧传感器4 单元1
      () async => await sender.sendOxygenSensor5(isFreeze: isFreeze), // 氧传感器5 单元2
      () async => await sender.sendOxygenSensor6(isFreeze: isFreeze), // 氧传感器6 单元2
      () async => await sender.sendOxygenSensor7(isFreeze: isFreeze), // 氧传感器7 单元2
      () async => await sender.sendOxygenSensor8(isFreeze: isFreeze), // 氧传感器8 单元2

      () async => await sender.sendRunTimeSinceEnginStart(isFreeze: isFreeze), // 发动机当前运行时间
      () async =>
          await sender.sendDistanceTraveledWithMilOn(isFreeze: isFreeze), // 故障灯亮时行驶的距离(MIL)
      () async => await sender.sendFuelRailPressure(isFreeze: isFreeze), // 燃油轨压力（相对于歧管真空）
      () async => await sender.sendFuelGaugePressure(isFreeze: isFreeze), // 燃油轨压力

      () async => await sender.sendOxygenSensorVoltage1(isFreeze: isFreeze), // 氧传感器1 电压
      () async => await sender.sendOxygenSensorVoltage2(isFreeze: isFreeze), // 氧传感器2 电压
      () async => await sender.sendOxygenSensorVoltage3(isFreeze: isFreeze), // 氧传感器3 电压
      () async => await sender.sendOxygenSensorVoltage4(isFreeze: isFreeze), // 氧传感器4 电压
      () async => await sender.sendOxygenSensorVoltage5(isFreeze: isFreeze), // 氧传感器5 电压
      () async => await sender.sendOxygenSensorVoltage6(isFreeze: isFreeze), // 氧传感器6 电压
      () async => await sender.sendOxygenSensorVoltage7(isFreeze: isFreeze), // 氧传感器7 电压
      () async => await sender.sendOxygenSensorVoltage8(isFreeze: isFreeze), // 氧传感器8 电压

      () async => await sender.sendCommandEGR(isFreeze: isFreeze), // 命令EGR任务
      () async => await sender.sendErrorEGR(isFreeze: isFreeze), // EGR错误
      () async => await sender.sendCommandEvaporativePurge(isFreeze: isFreeze), // 命令蒸发排放清除
      () async => await sender.sendFuelTankLevelInput(isFreeze: isFreeze), // 油箱液位输入
      () async => await sender.sendWarmUpsSinceCodesCleared(isFreeze: isFreeze), // 代码清除后的预热
      () async =>
          await sender.sendDistanceTraveledSinceCodesCleared(isFreeze: isFreeze), // 代码清除后的行驶距离
      () async => await sender.sendSystemVaporPressure(isFreeze: isFreeze), // 蒸发系统蒸汽压力
      () async => await sender.sendABSBarometricPressure(isFreeze: isFreeze), // 气压

      () async => await sender.sendOxygenSensorCurrent1(isFreeze: isFreeze), // 氧传感器1 电流
      () async => await sender.sendOxygenSensorCurrent2(isFreeze: isFreeze), // 氧传感器2 电流
      () async => await sender.sendOxygenSensorCurrent3(isFreeze: isFreeze), // 氧传感器3 电流
      () async => await sender.sendOxygenSensorCurrent4(isFreeze: isFreeze), // 氧传感器4 电流
      () async => await sender.sendOxygenSensorCurrent5(isFreeze: isFreeze), // 氧传感器5 电流
      () async => await sender.sendOxygenSensorCurrent6(isFreeze: isFreeze), // 氧传感器6 电流
      () async => await sender.sendOxygenSensorCurrent7(isFreeze: isFreeze), // 氧传感器7 电流
      () async => await sender.sendOxygenSensorCurrent8(isFreeze: isFreeze), // 氧传感器8 电流

      () async => await sender.sendCatalystTempBankSensor1(isFreeze: isFreeze), // 催化器温度传感器1
      () async => await sender.sendCatalystTempBankSensor2(isFreeze: isFreeze), // 催化器温度传感器2
      () async => await sender.sendCatalystTempBankSensor3(isFreeze: isFreeze), // 催化器温度传感器3
      () async => await sender.sendCatalystTempBankSensor4(isFreeze: isFreeze), // 催化器温度传感器4
      () async => await sender.sendControlModuleVoltage(isFreeze: isFreeze), // 控制模块电压
      () async => await sender.sendAbsoluteLoadValue(isFreeze: isFreeze), // 绝对负载值
      () async => await sender.sendFuelEquivalenceRatio(isFreeze: isFreeze), // 指令空燃比
      () async => await sender.sendRelativeThrottlePostion(isFreeze: isFreeze), // 相对节气门位置
      () async => await sender.sendAmbientAirTemp(isFreeze: isFreeze), // 环境温度

      () async => await sender.sendAbsoluteThrottlePostion1(isFreeze: isFreeze), // 绝对油门位置B
      () async => await sender.sendABSThrottlePostion2(isFreeze: isFreeze), // 绝对油门位置C
      () async => await sender.sendABSThrottlePostion3(isFreeze: isFreeze), // 油门踏板位置D
      () async => await sender.sendABSThrottlePostion4(isFreeze: isFreeze), // 油门踏板位置E
      () async => await sender.sendABSThrottlePostion5(isFreeze: isFreeze), // 油门踏板位置F
      () async => await sender.sendABSThrottlePostion6(isFreeze: isFreeze), // 指令油门执行器
      () async => await sender.sendTimeRunWithMilOn(isFreeze: isFreeze), // MIL运行时间
      () async => await sender.sendTimeSinceCodesCleared(isFreeze: isFreeze), // 故障码清除后运行时间

      () async => await sender.sendMaxMAFRate(isFreeze: isFreeze), // 空流计的最大流量值
      () async => await sender.sendEthanolFuelPercent(isFreeze: isFreeze), // 乙醇燃油比例
      () async =>
          await sender.sendAbsoluteEvapSystemVaporPressure(isFreeze: isFreeze), // EVAP系统绝对蒸气压
      () async => await sender.sendEvapSystemVaporPressure(isFreeze: isFreeze), // EVAP系统蒸气压
      () async => await sender.sendShortTermSecondOxygenBank1(isFreeze: isFreeze), // 短期二次氧传感修正1
      () async => await sender.sendLongTermSecondOxygenBank2(isFreeze: isFreeze), // 长期二次氧传感修正2
      () async => await sender.sendShortTermSecondOxygenBank3(isFreeze: isFreeze), // 短期二次氧传感修正3
      () async => await sender.sendLongTermSecondOxygenBank4(isFreeze: isFreeze), // 长期二次氧传感修正4
      () async => await sender.sendFuelRailAbsolutePressure(isFreeze: isFreeze), // 燃油轨绝对压力值
      () async => await sender.sendRelativeAcceleratorPedalPosition(isFreeze: isFreeze), // 相对油门位置
      () async => await sender.sendHybridBatteryRemaingLift(isFreeze: isFreeze), // 混动/纯电 电池组剩余电量

      () async => await sender.sendEngineOilTemperature(isFreeze: isFreeze), // 发动机油温
      () async => await sender.sendFuelInjectionTiming(isFreeze: isFreeze), // 燃油喷射正时
      () async => await sender.sendEngineFuelRate(isFreeze: isFreeze), // 发动机燃油率
      () async => await sender.sendTimeSinceCodesCleared(isFreeze: isFreeze), // 驾驶员的动力请求
    ];

    List<InstrumentModel> models = [];
    for (int i = 0; i < allData.length; i++) {
      List<String> parts = allData[i].split(':');
      if (parts.length < 4) continue;
      String name = parts[0].trim();
      String unit = parts[1].trim();
      double min = double.parse(parts[2].trim());
      double max = double.parse(parts[3].trim());
      var interval = (max - min) / 10;

      models.add(
        InstrumentModel(
          name: name,
          value: 0.0,
          unit: unit,
          minimum: min,
          maximum: max,
          interval: interval,
          selected: isAllSelected,
          fetchCommand: commandList.length > i ? commandList[i] : null,
        ),
      );
    }

    return models;
  }

  // 获取数据流数据
  static List<InstrumentModel> genarateStreamData({bool isAllSelected = true, isFreeze = false}) {
    List<String> allData = [
      '冷却液温度:  °C: -40: 150',
      '进气歧管绝对压力:  kPa: 0: 255',
      '转速:  rpm: 0: 16383',
      '车速:  km/h: 0: 255',
      '进气温度:  °C: -40: 215',
      '氧传感器1 电压:  V: 0: 8',
      '催化器温度传感器1:  °C: -40: 6513.5',
      '控制模块电压:  V: 0: 65.535',
      '燃油轨绝对压力值:  kPa: 0: 655350',
    ];

    var sender = Sender();

    var commandList = [
      () async => await sender.sendEngineCoolantTemp(isFreeze: isFreeze), // 冷却液温度
      () async => await sender.sendIntakManifoldABSPressure(isFreeze: isFreeze), // 进气歧管绝对压力
      () async => await sender.sendEngineRPM(isFreeze: isFreeze), // 发动机转速
      () async => await sender.sendVehicleSpeed(isFreeze: isFreeze), // 车速
      () async => await sender.sendIntakeAirTemp(isFreeze: isFreeze), // 进气温度
      () async => await sender.sendOxygenSensorVoltage1(isFreeze: isFreeze), // 氧传感器1 电压
      () async => await sender.sendCatalystTempBankSensor1(isFreeze: isFreeze), // 催化器温度传感器1
      () async => await sender.sendControlModuleVoltage(isFreeze: isFreeze), // 控制模块电压
      () async => await sender.sendFuelRailAbsolutePressure(isFreeze: isFreeze), // 燃油轨绝对压力值
    ];

    List<InstrumentModel> models = [];
    for (int i = 0; i < allData.length; i++) {
      List<String> parts = allData[i].split(':');
      if (parts.length < 4) continue;
      String name = parts[0].trim();
      String unit = parts[1].trim();
      double min = double.parse(parts[2].trim());
      double max = double.parse(parts[3].trim());
      var interval = (max - min) / 10;

      models.add(
        InstrumentModel(
          name: name,
          value: 0.0,
          unit: unit,
          minimum: min,
          maximum: max,
          interval: interval,
          selected: isAllSelected,
          fetchCommand: commandList.length > i ? commandList[i] : null,
        ),
      );
    }

    return models;
  }
}
