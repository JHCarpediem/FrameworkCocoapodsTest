class FeedbackTypeValueModel {
  int? id;

  /// 反馈类型 1反馈2投诉3咨询
  int? feedbackType;

  /// 产品型号id
  int? productId;

  /// 配置分类id 0通用，1诊断软件内，2防盗软件内，3APP个人中心
  int? configClass;

  /// 系统名称
  String? systemName;

  /// 问题类型名称
  String? name;

  /// languageId
  int? languageId;

  /// 内容id
  int? contentId;

  /// 自定义
  bool selected = false;

  FeedbackTypeValueModel({
    this.id,
    this.feedbackType,
    this.productId,
    this.configClass,
    this.systemName,
    this.name,
    this.languageId,
    this.contentId,
    this.selected = false,
  });

  factory FeedbackTypeValueModel.fromJson(Map<String, dynamic> json) =>
      FeedbackTypeValueModel(
        id: json["id"],
        feedbackType: json["feedbackType"],
        productId: json["productId"],
        configClass: json["configClass"],
        systemName: json["systemName"],
        name: json["name"],
        languageId: json["languageId"],
        contentId: json["contentId"],
      );

  Map<String, dynamic> toJson() => {
    "id": id,
    "feedbackType": feedbackType,
    "productId": productId,
    "configClass": configClass,
    "systemName": systemName,
    "name": name,
    "languageId": languageId,
    "contentId": contentId,
  };

  @override
  String toString() {
    return 'FeedbackTypeValueModel{id: $id, feedbackType: $feedbackType, productId: $productId, configClass: $configClass, systemName: $systemName, name: $name, languageId: $languageId, contentId: $contentId}';
  }
}
