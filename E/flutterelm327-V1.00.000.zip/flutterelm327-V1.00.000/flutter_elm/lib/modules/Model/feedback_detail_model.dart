class FeedbackReplyModel {
  /// 交互类型  0回复 1追加反馈
  int? interactionType;
  
  /// 内容
  String? content;
  
  /// 交互时间戳
  int? createTime;
  
  /// 原来的创建时间的时间戳加上了后台减去的偏移量
  int? newCreateTime;
  
  /// 回复 - 附件信息
  List<EnclosureOssModel>? ossFiles;

  FeedbackReplyModel({
    this.interactionType,
    this.content,
    this.createTime,
    this.newCreateTime,
    this.ossFiles,
  });

  factory FeedbackReplyModel.fromJson(Map<String, dynamic> json) {
    var model = FeedbackReplyModel(
      interactionType: json["interactionType"],
      content: json["content"],
      createTime: json["createTime"],
      newCreateTime: json["newCreateTime"],
    );
    
    // 解析附件列表
    if (json["ossFiles"] != null && json["ossFiles"] is List) {
      model.ossFiles = (json["ossFiles"] as List)
          .map((e) => EnclosureOssModel.fromJson(e))
          .toList();
    }
    
    return model;
  }

  Map<String, dynamic> toJson() => {
        "interactionType": interactionType,
        "content": content,
        "createTime": createTime,
        "newCreateTime": newCreateTime,
        "ossFiles": ossFiles?.map((e) => e.toJson()).toList(),
      };

  @override
  String toString() {
    return 'FeedbackReplyModel{interactionType: $interactionType, content: $content, createTime: $createTime, ossFiles: $ossFiles}';
  }
}

class FeedbackDetailModel {
  /// 反馈序号
  String? serialNumber;
  
  /// 反馈内容
  String? content;
  
  /// 反馈状态 0未回复 1已回复 2已解决
  int? feedbackStatus;
  
  /// 主键id
  int? id;
  
  /// 互动列表
  List<FeedbackReplyModel>? interactions;
  
  /// 附件列表
  List<EnclosureOssModel>? enclosureOss;
  
  /// 未读回复数
  int? unReadReply;
  
  /// 引用项
  String? quoteItem;
  
  /// 联系方式
  String? contact;
  
  /// 创建时间(时间戳)
  int? createTime;
  
  /// 新的创建时间(时间戳)
  int? newCreateTime;

  FeedbackDetailModel({
    this.serialNumber,
    this.content,
    this.feedbackStatus,
    this.id,
    this.interactions,
    this.enclosureOss,
    this.unReadReply,
    this.quoteItem,
    this.contact,
    this.createTime,
    this.newCreateTime,
  });

  factory FeedbackDetailModel.fromJson(Map<String, dynamic> json) {
    var model = FeedbackDetailModel(
      serialNumber: json["serialNumber"],
      content: json["content"],
      feedbackStatus: json["feedbackStatus"],
      id: json["id"],
      unReadReply: json["unReadReply"],
      quoteItem: json["quoteItem"],
      contact: json["contact"],
      createTime: json["createTime"],
      newCreateTime: json["newCreateTime"],
    );
    
    // 解析互动列表
    if (json["interactions"] != null && json["interactions"] is List) {
      model.interactions = (json["interactions"] as List)
          .map((e) => FeedbackReplyModel.fromJson(e))
          .toList();
    }
    
    // 解析附件列表
    if (json["enclosureOss"] != null && json["enclosureOss"] is List) {
      model.enclosureOss = (json["enclosureOss"] as List)
          .map((e) => EnclosureOssModel.fromJson(e))
          .toList();
    }
    
    return model;
  }

  Map<String, dynamic> toJson() => {
        "serialNumber": serialNumber,
        "content": content,
        "feedbackStatus": feedbackStatus,
        "id": id,
        "interactions": interactions?.map((e) => e.toJson()).toList(),
        "enclosureOss": enclosureOss?.map((e) => e.toJson()).toList(),
        "unReadReply": unReadReply,
        "quoteItem": quoteItem,
        "contact": contact,
        "createTime": createTime,
        "newCreateTime": newCreateTime,
      };

  @override
  String toString() {
    return 'FeedbackDetailModel{id: $id, serialNumber: $serialNumber, content: $content, feedbackStatus: $feedbackStatus, enclosureOss: $enclosureOss}';
  }
}

class EnclosureOssModel {
  /// 主键id
  int? id;
  
  /// 文件密钥
  String? fileSecret;
  
  /// 文件名
  String? fileName;
  
  /// 文件url
  String? url;
  
  /// 文件类型
  String? fileType;

  EnclosureOssModel({
    this.id,
    this.fileSecret,
    this.fileName,
    this.url,
    this.fileType,
  });

  factory EnclosureOssModel.fromJson(Map<String, dynamic> json) =>
      EnclosureOssModel(
        id: json["id"],
        fileSecret: json["fileSecret"],
        fileName: json["fileName"],
        url: json["url"],
        fileType: json["fileType"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "fileSecret": fileSecret,
        "fileName": fileName,
        "url": url,
        "fileType": fileType,
      };

  @override
  String toString() {
    return 'EnclosureOssModel{id: $id, fileName: $fileName, fileType: $fileType, url: $url}';
  }

  /// 判断是否为图片文件
  bool get isImage => fileType != null && ['jpg', 'jpeg', 'png', 'gif', 'bmp'].contains(fileType!.toLowerCase());
  
  /// 判断是否为视频文件
  bool get isVideo => fileType != null && ['mp4', 'mov', 'avi', 'wmv', 'flv'].contains(fileType!.toLowerCase());
}