import 'package:permission_handler/permission_handler.dart';

class DeviceModel {
  late String name = '';

  /// 序列号
  late String uuid = '';

  /// 序列号
  late String sn = '';

  /// mac
  late String mac = '';

  /// 是否连接(不存数据库)
  late bool isConnect = false;

  DeviceModel({
    this.name = '',
    this.uuid = '',
    this.isConnect = false,
    this.sn = '',
    this.mac = '',
  });

  Map<String, Object?> toMap() {
    return {'name': name, 'mac': mac, 'sn': sn};
  }

  factory DeviceModel.fromJson(Map<String, dynamic> json) {
    return DeviceModel(
      name: json['name'] as String? ?? '',
      mac: json['mac'] as String? ?? '',
      sn: json['sn'] as String? ?? '',
    );
  }

  @override
  String toString() {
    return toMap().toString();
  }
}

// 权限检查结果数据类
class PermissionCheckResult {
  final bool hasPermissions;
  final bool isAndroid12Plus;
  final List<Permission> missingPermissions;

  PermissionCheckResult({
    required this.hasPermissions,
    required this.isAndroid12Plus,
    required this.missingPermissions,
  });
}
