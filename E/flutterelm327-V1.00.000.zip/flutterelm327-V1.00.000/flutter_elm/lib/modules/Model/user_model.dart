

/// 用户模型
class UserModel {
  final int? userId;
  final String? topdonId;
  final String? token;
  final String? refreshToken;
  final String? userName;
  final String? email;
  final String? avatar;
  final String? phone;

  UserModel(
    this.userId,
    this.topdonId,
    this.token,
    this.refreshToken,
    this.userName,
    this.email,
    this.avatar,
    this.phone,
  );

  Map<String, Object?> toMap() {
    return {
      'userId': userId,
      'topdonId': topdonId,
      'token': token,
      'refreshToken': refreshToken,
      'userName': userName,
      'email': email,
      'avatar': avatar,
      'phone': phone,
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
        json['userId'] as int? ?? -1,
        json['topdonId'] as String? ?? '',
        json['token'] as String? ?? '',
        json['refreshToken'] as String? ?? '',
        json['userName'] as String? ?? '',
        json['email'] as String? ?? '',
        json['avatar'] as String? ?? '',
        json['phone'] as String? ?? '',
      );
  }

  @override
  String toString() {
    super.toString();
    var json = 'userId = $userId, topdonId = $topdonId, token = $token, refreshToken = $refreshToken, userName = $userName, email = $email, avatar = $avatar, phone = $phone';
    return json;
  }
}