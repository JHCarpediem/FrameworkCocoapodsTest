import 'package:dart_json_mapper/dart_json_mapper.dart';

class FeedbackItemModel {
  /// 主键id
  int? id;
  /// 0未回复 1已回复 2已解决
  int? feedbackStatus;
  /// 问题标题
  String? content;
  /// 创建时间(时间戳)
  int? createTime;
  /// 原来的创建时间的时间戳加上了后台减去的偏移量
  int? newCreateTime;
  int? unReadReply;

  /// 是否选中
  bool? isSelected;
  /// 是否已读 (当unReadReply为0时表示已读)
  bool get isReaded => unReadReply == 0;

  FeedbackItemModel({
    this.id,
    this.feedbackStatus,
    this.content,
    this.createTime,
    this.newCreateTime,
    this.unReadReply,
    this.isSelected,
  });

  factory FeedbackItemModel.fromJson(Map<String, dynamic> json) =>
      FeedbackItemModel(
        id: json["id"],
        feedbackStatus: json["feedbackStatus"],
        content: json["content"],
        createTime: json["createTime"],
        newCreateTime: json["newCreateTime"],
        unReadReply: json["unReadReply"],
        isSelected: json["isSelected"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "feedbackStatus": feedbackStatus,
        "content": content,
        "createTime": createTime,
        "newCreateTime": newCreateTime,
        "unReadReply": unReadReply,
        "isSelected": isSelected,
      };

  @override
  String toString() {
    return 'FeedbackItemModel{id: $id, feedbackStatus: $feedbackStatus, content: $content, createTime: $createTime, newCreateTime: $newCreateTime, unReadReply: $unReadReply, isSelected: $isSelected, isReaded: $isReaded}';
  }
}