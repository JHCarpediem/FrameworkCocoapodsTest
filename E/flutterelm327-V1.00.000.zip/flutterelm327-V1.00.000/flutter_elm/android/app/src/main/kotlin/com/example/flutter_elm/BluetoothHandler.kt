package com.example.flutter_elm

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.*
import kotlin.collections.ArrayList
import android.location.LocationManager

import kotlin.io.path.name

class BluetoothHandler(private val activity: Activity, private val context: Context) {
    private val TAG = "BluetoothHandler"
    private val CHANNEL_NAME = "bluetooth_channel"
    private val SCAN_RESULTS_CHANNEL = "bluetooth_scan_results"
    private val BLUETOOTH_STATE_CHANNEL = "bluetooth_state"
    
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var isScanning = false
    private val scanResults = ArrayList<BluetoothDevice>()

    private fun getDeviceNameFromScanRecord(scanRecord: ByteArray?): String? {
        scanRecord?.let {
            var index = 0
            while (index < it.size) {
                val length = it[index].toInt() and 0xFF
                if (length == 0 || index + length > it.size) break
                
                val type = it[index + 1].toInt() and 0xFF
                if (type == 0x09 || type == 0x08) { // 完整本地名称(0x09)或简称本地名称(0x08)
                    try {
                        return String(it, index + 2, length - 1, Charsets.UTF_8)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to parse device name from scan record: ${e.message}")
                    }
                }
                
                index += length + 1
            }
        }
        return null
    }

    // 获取设备的显示名称，综合多种方式
    private fun getDeviceDisplayName(device: BluetoothDevice, scanRecord: android.bluetooth.le.ScanRecord?): String {
        // 1. 首先尝试从ScanRecord获取名称（不依赖权限）
        val nameFromScanRecord = scanRecord?.deviceName
        if (!nameFromScanRecord.isNullOrEmpty()) {
            return nameFromScanRecord
        }

        // 2. 尝试从原始扫描记录解析名称
        val nameFromRawRecord = getDeviceNameFromScanRecord(scanRecord?.bytes)
        if (!nameFromRawRecord.isNullOrEmpty()) {
            return nameFromRawRecord
        }

        // 3. 尝试获取device.name（Android 12+需要BLUETOOTH_CONNECT权限）
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
            if (!device.name.isNullOrEmpty()) {
                return device.name
            }
        }

        // 4. 如果所有方法都失败，使用MAC地址的一部分作为标识名称
        val macSuffix = device.address?.takeLast(5)?.replace(":", "")
        return if (macSuffix != null) "设备-$macSuffix" else "未知设备"
    }

    // 扫描回调
    private val scanCallback = object : ScanCallback() { // 确保 ScanCallback 能被正确解析
        @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT) // 注意：onScanResult 内部可能不需要 BLUETOOTH_CONNECT，而是设备本身连接时
        override fun onScanResult(callbackType: Int, result: ScanResult) { // 确保 ScanResult 能被正确解析
            val device = result.device
            // 确保 BLUETOOTH_CONNECT 权限在实际获取 device.name 前已检查 (Android 12+)
            // 虽然你这里主要关注地址，但如果尝试获取 name 而无权限会出问题
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    // 如果没有 BLUETOOTH_CONNECT 权限，device.name 可能会返回 null 或抛出安全异常
                    // 在这种情况下，你的 getDeviceNameFromScanRecord 可能是更好的选择，因为它不直接依赖 device.name
                }
            }

            if (!scanResults.any { it.address == device.address }) { // 使用 any 和 address 比较更安全
                scanResults.add(device)
                val deviceMap = HashMap<String, Any>()
                val scanRecord = result.scanRecord
                
                // 使用新的综合方法获取设备名称
                val finalDeviceName = getDeviceDisplayName(device, scanRecord)

                deviceMap["name"] = finalDeviceName
            deviceMap["address"] = (device.address?.takeIf { it.isNotEmpty() } ?: "未知地址")
            deviceMap["rssi"] = result.rssi

                // 发送设备信息到Flutter端
                scanResultsSink?.success(deviceMap)
            }
        }

        @androidx.annotation.RequiresPermission(android.Manifest.permission.BLUETOOTH_CONNECT)
        override fun onBatchScanResults(results: MutableList<ScanResult>?) { // 显式声明类型
            super.onBatchScanResults(results)
            results?.forEach { result ->
                onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, result) // 可以复用单个结果的处理逻辑
            }
        }

        override fun onScanFailed(errorCode: Int) {
            super.onScanFailed(errorCode)
            Log.e(TAG, "Bluetooth LE Scan Failed with error code: $errorCode")
            // 你可以在这里通过 EventChannel 将错误信息发送到 Flutter 端
            // scanResultsSink?.error("SCAN_FAILED", "Bluetooth LE Scan Failed: $errorCode", null)
        }
    }
    
    // 蓝牙状态变化广播接收器
    private val bluetoothStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
                val isEnabled = state == BluetoothAdapter.STATE_ON
                bluetoothStateSink?.success(isEnabled)
            }
        }
    }
    
    // EventChannel的事件接收器
    private var scanResultsSink: EventChannel.EventSink? = null
    private var bluetoothStateSink: EventChannel.EventSink? = null
    
    @RequiresApi(Build.VERSION_CODES.M)
    fun registerWith(flutterEngine: FlutterEngine) {
        // 获取蓝牙适配器
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        
        // 注册MethodChannel
        val methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_NAME)
        methodChannel.setMethodCallHandler { call, result ->
            handleMethodCall(call, result)
        }
        
        // 注册扫描结果EventChannel
        val scanResultsChannel = EventChannel(flutterEngine.dartExecutor.binaryMessenger, SCAN_RESULTS_CHANNEL)
        scanResultsChannel.setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink) {
                    scanResultsSink = sink
                    // 发送当前蓝牙状态
                    bluetoothStateSink?.success(isBluetoothEnabled())
                }
                
                override fun onCancel(arguments: Any?) {
                    scanResultsSink = null
                }
            }
        )
        
        // 注册蓝牙状态EventChannel
        val bluetoothStateChannel = EventChannel(flutterEngine.dartExecutor.binaryMessenger, BLUETOOTH_STATE_CHANNEL)
        bluetoothStateChannel.setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, sink: EventChannel.EventSink) {
                    bluetoothStateSink = sink
                    // 发送当前蓝牙状态
                    sink.success(isBluetoothEnabled())
                }
                
                override fun onCancel(arguments: Any?) {
                    bluetoothStateSink = null
                }
            }
        )
        
        // 注册蓝牙状态变化广播接收器
        val filter = IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)
        context.registerReceiver(bluetoothStateReceiver, filter)
    }
    
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun unregister() {
        // 取消注册广播接收器
        context.unregisterReceiver(bluetoothStateReceiver)
        // 停止扫描
        stopScan()
    }
    
    @RequiresApi(Build.VERSION_CODES.M)
    private fun handleMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "isBluetoothEnabled" -> {
                result.success(isBluetoothEnabled())
            }
            "enableBluetooth" -> {
                result.success(enableBluetooth())
            }
            "checkPermission" -> {
                result.success(checkPermission())
            }
            "requestPermission" -> {
                result.success(requestPermission())
            }
            "startScan" -> {
                startScan()
                result.success(null)
            }
            "stopScan" -> {
                stopScan()
                result.success(null)
            }
            "connectToDevice" -> {
                val address = call.argument<String>("address")
                if (address != null) {
                    result.success(connectToDevice(address))
                } else {
                    result.error("INVALID_ADDRESS", "设备地址不能为空", null)
                }
            }
            "isLocationServiceEnabled" -> {
                result.success(isLocationServiceEnabled())
            }
            "openLocationSettings" -> {
                openLocationSettings()
                result.success(null)
            }
            else -> {
                result.notImplemented()
            }
        }
    }
    
    // 检查蓝牙是否开启
    private fun isBluetoothEnabled(): Boolean {
        return bluetoothAdapter.isEnabled
    }
    
    // 开启蓝牙
    private fun enableBluetooth(): Boolean {
        return if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return false
            }
            activity.startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
            true
        } else {
            true
        }
    }
    
    // 检查权限
    private fun checkPermission(): Boolean {
        val bluetoothPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        
        val locationPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        
        return bluetoothPermission && locationPermission
    }
    
    // 打开位置服务设置
    private fun openLocationSettings() {
        val intent = Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        activity.startActivity(intent)
    }

    // 检查位置服务是否启用
    private fun isLocationServiceEnabled(): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    // 请求权限
    private fun requestPermission(): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }
        
        ActivityCompat.requestPermissions(activity, permissions, REQUEST_PERMISSIONS)
        
        // 这里返回true，但实际权限授予状态需要在onRequestPermissionsResult中处理
        // 由于MethodChannel的限制，我们无法等待用户响应
        return true
    }

    // 开始扫描
    @RequiresApi(Build.VERSION_CODES.M)
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION]) // 明确标出 startScan 所需的权限
    private fun startScan() {
        if (isScanning) {
            Log.d(TAG, "Scan is already in progress.")
            return
        }
        if (!checkPermission()) { // checkPermission 应该包含 BLUETOOTH_SCAN
            Log.e(TAG, "Missing necessary Bluetooth permissions to start scan.")
            // 可以考虑通过 MethodChannel 反馈给 Flutter 端权限不足
            return
        }

        if (!bluetoothAdapter.isEnabled) {
            Log.e(TAG, "Bluetooth is not enabled.")
            // 可以考虑通过 MethodChannel 反馈给 Flutter 端蓝牙未开启
            return
        }

        scanResults.clear()
        // 发送空列表或特定信号到 Flutter，告知扫描已开始且列表已清空
        // scanResultsSink?.success(emptyList<Map<String, Any>>())


        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            Log.e(TAG, "BluetoothLeScanner not available.")
            // 可能设备不支持 BLE，或者蓝牙适配器有问题
            return
        }

//        val settings = ScanSettings.Builder()
//            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
//            .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES) // 确保这个回调类型与你的 onScanResult 期望一致
//            .build()
//        val filters = mutableListOf<androidx.bluetooth.ScanFilter>() // 如果不需要特定过滤，可以传空列表
//
//        // 确保在调用 startScan 之前 BLUETOOTH_SCAN 权限已经被授予
//        // 虽然 checkPermission() 做了检查，但在调用处再次确认或使用 lint/IDE 的权限检查是个好习惯
//        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
//            Log.e(TAG, "BLUETOOTH_SCAN permission not granted before calling startScan.")
//            return
//        }
        val settings = android.bluetooth.le.ScanSettings.Builder() // 明确使用 android.bluetooth.le 包
            .setScanMode(android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setCallbackType(android.bluetooth.le.ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
            .build()

        // 重要：确保使用 android.bluetooth.le.ScanFilter
        val filters = mutableListOf<android.bluetooth.le.ScanFilter>()
        // 如果你需要添加过滤器，可以这样做：
        // val filter = android.bluetooth.le.ScanFilter.Builder()
        //    .setServiceUuid(ParcelUuid.fromString("YOUR_SERVICE_UUID_STRING")) // 示例
        //    .build()
        // filters.add(filter)


        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "BLUETOOTH_SCAN permission not granted before calling startScan.")
            return
        }

        scanner.startScan(filters, settings, scanCallback)
        isScanning = true
        Log.d(TAG, "Started Bluetooth LE scan.")

        // 考虑使用 Handler().postDelayed 代替 Timer，因为 Timer 会创建新线程，
        // 而更新 UI 或与蓝牙相关的操作很多时候需要在主线程或特定 Handler 线程。
        // 不过你这里的 stopScan 内部似乎是线程安全的。
        Timer().schedule(object : TimerTask() {
            @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
            override fun run() {
                if (isScanning) { // 再次检查 isScanning 状态，避免不必要的 stopScan 调用
                    Log.d(TAG, "Scan timeout, stopping scan.")
                    stopScan()
                }
            }
        }, 10000) // 10秒扫描超时
    }

    // 停止扫描
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN) // 明确标出 stopScan 所需的权限
    private fun stopScan() {
        if (!isScanning) {
            Log.d(TAG, "Scan is not in progress, no need to stop.")
            return
        }

        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (scanner == null) {
            Log.e(TAG, "BluetoothLeScanner not available for stopping scan.")
            isScanning = false // 即使 scanner 为 null，也应该更新扫描状态
            return
        }

        // 确保在调用 stopScan 之前 BLUETOOTH_SCAN 权限已经被授予
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "BLUETOOTH_SCAN permission not granted before calling stopScan.")
            // 即使没有权限，也应该尝试更新 isScanning 状态，尽管实际的停止操作可能失败
            isScanning = false
            return
        }
        scanner.stopScan(scanCallback)
        isScanning = false
        Log.d(TAG, "Stopped Bluetooth LE scan.")
    }
    
    // 连接设备
    private fun connectToDevice(address: String): Boolean {
        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                return false
            }
            
            val device = bluetoothAdapter.getRemoteDevice(address)
            // 这里只是简单示例，实际连接需要更复杂的逻辑
            // 包括建立GATT连接、发现服务等
            Log.d(TAG, "尝试连接设备: ${device.name} (${device.address})")
            
            // 返回连接成功（实际应该根据真实连接结果返回）
            return true
        } catch (e: Exception) {
            Log.e(TAG, "连接设备失败: ${e.message}")
            return false
        }
    }
    
    companion object {
        private const val REQUEST_ENABLE_BT = 1
        private const val REQUEST_PERMISSIONS = 2
    }
}