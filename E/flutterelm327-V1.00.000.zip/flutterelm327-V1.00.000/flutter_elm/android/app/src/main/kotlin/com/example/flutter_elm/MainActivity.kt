package com.example.flutter_elm

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    private lateinit var bluetoothHandler: BluetoothHandler

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // 初始化蓝牙处理器
        bluetoothHandler = BluetoothHandler(this, this)
        // 注册蓝牙处理器
        bluetoothHandler.registerWith(flutterEngine)
    }

    override fun onDestroy() {
        super.onDestroy()
        // 取消注册蓝牙处理器
        bluetoothHandler.unregister()
    }
}
